import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './DebtPage.module.scss';
import { createDebt, getDebts, updateDebtStatus, deleteDebt } from '../../api';
import { showSuccess, showError, showWarning } from '../../utils/toast';
import ConfirmModal from '../Modal/ConfirmModal';
import { useModal } from '../Modal/ModalContext';

const cx = classNames.bind(styles);

export default function DebtPage() {
    const [debts, setDebts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const { openModal, closeModal } = useModal();
    const [formData, setFormData] = useState({ amount: '', note: '', dueDate: '' });

    const handleOpenDetail = (debt) => {
        const isOverdue = new Date(debt.dueDate) < new Date() && debt.status === 'pending';
        openModal(
            <div className={cx('detail-modal')}>
                <div className={cx('modal-header')}>
                    <div className={cx('icon-wrapper', debt.status)}><i className="fas fa-file-invoice-dollar"></i></div>
                    <h3>Chi Tiết Khoản Nợ</h3>
                </div>
                <div className={cx('modal-body')}>
                    <div className={cx('info-row')}>
                        <span>Trạng thái:</span>
                        <span className={cx('status-badge', debt.status)}>
                            {debt.status === 'pending' ? 'Chưa trả' : 'Đã trả'}
                        </span>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Số tiền:</span>
                        <strong className={cx('amount')}>{debt.amount.toLocaleString('vi-VN')} đ</strong>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Ngày tạo:</span>
                        <strong>{new Date(debt.createdAt).toLocaleDateString('vi-VN')}</strong>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Đến hạn:</span>
                        <strong className={cx({ 'text-danger': isOverdue })}>
                            {new Date(debt.dueDate).toLocaleDateString('vi-VN')}
                        </strong>
                    </div>
                    <div className={cx('info-box')}>
                        <span className={cx('box-title')}>Ghi chú:</span>
                        <p>{debt.note || 'Không có ghi chú'}</p>
                    </div>
                </div>
                <div className={cx('modal-footer')}>
                    <button className={cx('btn-cancel')} onClick={() => closeModal()}>Đóng</button>
                    <button
                        className={cx('btn-status', debt.status === 'pending' ? 'mark-paid' : 'mark-pending')}
                        onClick={() => {
                            handleUpdateStatus(debt._id, debt.status);
                            closeModal();
                        }}
                    >
                        <i className={`fas ${debt.status === 'pending' ? 'fa-check' : 'fa-undo'}`}></i>
                        {debt.status === 'pending' ? 'Đánh dấu Đã Trả' : 'Đánh dấu Chưa Trả'}
                    </button>
                    <button className={cx('btn-del-modal')} onClick={() => {
                        closeModal();
                        handleDelete(debt._id);
                    }}>
                        <i className="fas fa-trash"></i> Xóa
                    </button>
                </div>
            </div>
        );
    };

    const loadDebts = async () => {
        setLoading(true);
        try {
            const res = await getDebts();
            if (res) setDebts(res);
        } catch (error) {
            showError("Lỗi tải danh sách nợ");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { loadDebts(); }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.amount || !formData.dueDate) return showWarning("Vui lòng nhập tiền và ngày hạn");
        try {
            await createDebt(formData);
            showSuccess("Ghi nợ thành công");
            setFormData({ amount: '', note: '', dueDate: '' });
            setShowForm(false);
            loadDebts();
        } catch (err) {
            showError(err.message);
        }
    };

    const handleUpdateStatus = async (id, currentStatus) => {
        const newStatus = currentStatus === 'pending' ? 'paid' : 'pending';
        try {
            await updateDebtStatus(id, { status: newStatus });
            showSuccess("Đã cập nhật trạng thái");
            loadDebts();
        } catch (err) {
            showError("Lỗi cập nhật");
        }
    };

    const handleDelete = (id) => {
        openModal(
            <ConfirmModal
                title="Xóa khoản nợ"
                message="Bạn có chắc muốn xóa khoản nợ này không?"
                onConfirm={async () => {
                    try {
                        await deleteDebt(id);
                        showSuccess("Đã xóa khoản nợ");
                        loadDebts();
                    } catch (err) {
                        showError("Lỗi xóa");
                    }
                }}
            />
        );
    };

    return (
        <div className={cx('debt-page')}>
            <div className={cx('header')}>
                <h2>Ghi nợ & Nhắc nợ</h2>
                <button className={cx('btn-add')} onClick={() => setShowForm(!showForm)}>
                    <i className="fas fa-plus"></i> {showForm ? "Đóng Form" : "Ghi Nợ Mới"}
                </button>
            </div>

            {showForm && (
                <form className={cx('debt-form')} onSubmit={handleSubmit}>
                    <div className={cx('form-grid')}>
                        <div className={cx('form-group')}>
                            <label>Số tiền (VNĐ) *</label>
                            <input type="number" value={formData.amount} onChange={e => setFormData({ ...formData, amount: e.target.value })} required />
                        </div>
                        <div className={cx('form-group')}>
                            <label>Ngày đến hạn *</label>
                            <input type="date" value={formData.dueDate} onChange={e => setFormData({ ...formData, dueDate: e.target.value })} required />
                        </div>
                        <div className={cx('form-group', 'full')}>
                            <label>Ghi chú</label>
                            <input type="text" placeholder="Ghi chú người nợ, phòng, sđt..." value={formData.note} onChange={e => setFormData({ ...formData, note: e.target.value })} />
                        </div>
                    </div>
                    <button type="submit" className={cx('btn-submit')}>Lưu Ghi Nợ</button>
                </form>
            )}

            <div className={cx('debt-grid-container')}>
                {loading ? <div className={cx('loading-state')}><i className="fas fa-spinner fa-spin"></i> Đang tải...</div> : (
                    debts.length === 0 ? <div className={cx('empty-state')}><i className="fas fa-box-open"></i><p>Không có khoản nợ nào.</p></div> :
                        <div className={cx('debt-grid')}>
                            {debts.map(d => {
                                const isOverdue = new Date(d.dueDate) < new Date() && d.status === 'pending';
                                return (
                                    <div key={d._id} className={cx('debt-card', { overdue: isOverdue, paid: d.status === 'paid' })} onClick={() => handleOpenDetail(d)}>
                                        <div className={cx('card-left')}>
                                            <div className={cx('icon-container')}>
                                                <i className={`fas ${d.status === 'paid' ? 'fa-check-circle' : (isOverdue ? 'fa-exclamation-circle' : 'fa-clock')}`}></i>
                                            </div>
                                            <div className={cx('card-info')}>
                                                <h4>{d.note || 'Không ghi chú'}</h4>
                                                <span className={cx('date')}><i className="far fa-calendar-alt"></i> Hạn: {new Date(d.dueDate).toLocaleDateString('vi-VN')}</span>
                                            </div>
                                        </div>
                                        <div className={cx('card-right')}>
                                            <strong className={cx('amount')}>{d.amount.toLocaleString('vi-VN')} đ</strong>
                                            <span className={cx('status-badge-small', d.status)}>
                                                {d.status === 'pending' ? 'Chưa trả' : 'Đã trả'}
                                            </span>
                                        </div>
                                        {/* Action dropdown or quick action can go here if needed, but clicking the card opens modal */}
                                    </div>
                                )
                            })}
                        </div>
                )}
            </div>
        </div>
    );
}
