import React from "react";
import classNames from "classnames/bind";
import styles from "./PayMentInfo.module.scss";
const cx = classNames.bind(styles);

function ChoiceCheckbox({ choice, setChoice }) {
  return (
    <div className={cx("choice")}>
      <label>
        <input
          type="checkbox"
          checked={choice === 1}
          onChange={() => setChoice(1)}
        />
        In phiếu nội bộ<br />
        (Sẽ hiển thị tất cả các thông số các phòng nhằm mục đích quản lý)<br />
        (Có thể tạo phiếu cho từng phòng)
      </label>
      <label>
        <input
          type="checkbox"
          checked={choice === 2}
          onChange={() => setChoice(2)}
        />
        In phiếu cho Khách hàng<br />
        (Chỉ có các phòng có khách sẽ được tạo phiếu)<br />
        (Không thể tạo phiếu cho từng phòng riêng lẽ)<br />
        (Nhấn Enter Để Download Tất Cả)
      </label>
    </div>
  );
}

export default ChoiceCheckbox;
