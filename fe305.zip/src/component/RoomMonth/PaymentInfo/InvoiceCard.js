import React from "react";
import { FaPrint } from 'react-icons/fa';
import Bill from "component/Bill/Bill";
import classNames from "classnames/bind";
import styles from "./PayMentInfo.module.scss";
const cx = classNames.bind(styles);

function InvoiceCard({ item, openModal }) {
  const dientieuthu = item.chisodienmoi - item.chisodiencu;
  const nuoctieuthu = item.chisonuoclanhmoi - item.chisonuoclanhcu + item.chisonuocnongmoi - item.chisonuocnongcu;
  const coastNuoc = nuoctieuthu > 0 ? nuoctieuthu * 20000 : 0;
  const coastDien = dientieuthu > 0 ? dientieuthu * 4000 : 0;
  const total = coastNuoc + coastDien + item.sinhhoatchung + item.GiaPhong;

  return (
    <div className={cx("invoice-card")}>
      <div className={cx("print")} onClick={() => openModal(<Bill props={item.SoPhong} />)}><FaPrint /></div>
      <h3 className={cx("customer-name")}>{item.hovaten} - {item.SoPhong}</h3>
      <div className={cx("invoice-info")}>
        <span className={cx("divider")}>-----------------------------------------------</span>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>Điện mới: {item.chisodienmoi} kWh</div>
          <div className={cx("info-line")}>Điện cũ: {item.chisodiencu} kWh</div>
        </div>
        <span className={cx("divider")}>--------------------------------------------------</span>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>Nước lạnh mới: {item.chisonuoclanhmoi} m³</div>
          <div className={cx("info-line")}>Nước lạnh cũ: {item.chisonuoclanhcu} m³</div>
        </div>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>Nước nóng mới: {item.chisonuocnongmoi} m³</div>
          <div className={cx("info-line")}>Nước nóng cũ: {item.chisonuocnongcu} m³</div>
        </div>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>Tổng nước mới: {item.chisonuoclanhmoi + item.chisonuocnongmoi} m³</div>
          <div className={cx("info-line")}>Tổng nước cũ: {item.chisonuoclanhcu + item.chisonuocnongcu} m³</div>
        </div>
        <span className={cx("divider")}>--------------------------------------------------</span>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>Giá phòng: {item.GiaPhong.toLocaleString()}đ</div>
          <div className={cx("info-line")}>Phí Sinh hoạt: {item.sinhhoatchung.toLocaleString()}đ</div>
        </div>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>Điện tiêu thụ: {dientieuthu >= 0 ? dientieuthu : 0} kWh</div>
          <div className={cx("info-line")}>Nước tiêu thụ: {nuoctieuthu >= 0 ? nuoctieuthu : 0} m³</div>
        </div>
        <span className={cx("divider")}>--------------------------------------------------</span>
        <div className={cx("invoice-info-item")}>
          <div className={cx("info-line")}>
            Tiền điện: {coastDien.toLocaleString()}đ<br />
            Giá điện: {dientieuthu >= 0 ? `${dientieuthu} x 4.000đ` : "0"}đ
          </div>
          <div className={cx("info-line")}>
            Tiền nước: {coastNuoc.toLocaleString()}đ<br />
            Giá nước: {nuoctieuthu >= 0 ? `${nuoctieuthu} x 20.000đ` : "0"}đ
          </div>
        </div>
        <span className={cx("divider")}>--------------------------------------------------</span>
        <span className={cx("total-amount")}>
          Tổng thanh toán: {total.toLocaleString()}
        </span>
      </div>
    </div>
  );
}

export default InvoiceCard;
