import classNames from "classnames/bind";
import styles from "./PayMentInfo.module.scss";

import ListRoom from "../Room";
import TotalPaymentInfo from "./TotalPaymentInfo";
import { GetUpdateRoom, GetAllRoomsMonth } from "api";
import { saveRoomMonth } from "api/googleSheet";
import { useModal } from "component/Modal/ModalContext";
import { VNDFormatter } from "component/VNDFormatter";
import { useLoading } from "hooks/useLoading";
import Loading from "component/Loading";
import AddDataRoom from "../AddDataRoom";
import { showSuccess, showError, showWarning } from "utils/toast";
const cx = classNames.bind(styles);

function Menu({ props }) {
  const { openModal } = useModal();
  const { loading, withLoading } = useLoading();

  const HandleRefresh = async () => {
    const confirmRefresh = window.confirm(
      "Khi làm mới hóa đơn, số liệu nước mới và điện mới sẽ được chuyển thành số liệu cũ.các thông số sẽ được lưu vào googlesheet. Bạn có chắc chắn muốn làm mới hóa đơn không?"
    );
    if (!confirmRefresh) {
      showWarning("Đã hủy thao tác làm mới hóa đơn");
      return;
    }

    const password = prompt("Nhập mật khẩu để làm mới hóa đơn");
    if (password !== "0786566176") {
      showError("Mật khẩu không đúng, không thể làm mới hóa đơn");
      return;
    }

    const getallroom = await withLoading(GetAllRoomsMonth());
    if (getallroom) {
      const rooms = getallroom.data; // mảng 100 phòng

      const formattedData = rooms
        .map((item) => ({
          "Họ và tên": item.hovaten,
          "Số Phòng": item.SoPhong,
          "Giá Phòng": VNDFormatter(item.GiaPhong),
          "Chỉ số điện cũ": item.chisodiencu,
          "Chỉ số điện mới": item.chisodienmoi,
          "Chỉ số nước cũ": `${item.chisonuoclanhcu}\n${item.chisonuocnongcu}`,
          "Chỉ số nước mới": `${item.chisonuoclanhmoi}\n${item.chisonuocnongmoi}`,
          "Phí cố định": VNDFormatter(item.sinhhoatchung),
          "Khoáng nước": VNDFormatter(item.giakhoangnuoc),
          "Số người khoáng": item.songuoikhoang,
        }))
        .sort((a, b) => {
          const checkName = (name) => name && name.includes("CHƯA CÓ");

          const aHasUnwanted = checkName(a["Họ và tên"]);
          const bHasUnwanted = checkName(b["Họ và tên"]);

          if (aHasUnwanted && !bHasUnwanted) return 1; // a chứa "CHƯA CÓ KHÔNG" -> xếp sau
          if (!aHasUnwanted && bHasUnwanted) return -1; // b chứa "CHƯA CÓ KHÔNG" -> xếp sau
          return 0; // Giữ nguyên vị trí nếu cả hai đều có hoặc đều không chứa "CHƯA CÓ KHÔNG"
        });

      await withLoading(saveRoomMonth(formattedData));
      let position = 0;

      // Dùng for...of để xử lý async tuần tự
      for (const item of rooms) {
        position++;

        const object = {
          hovaten: item.hovaten,
          GiaPhong: item.GiaPhong,
          chisodiencu: item.chisodienmoi, // Gán giá trị chỉ số điện mới cho chỉ số điện cũ
          chisodienmoi: 0, // Đặt lại chỉ số điện mới về 0
          chisonuoclanhcu: item.chisonuoclanhmoi, // Gán giá trị chỉ số nước lạnh mới cho chỉ số nước lạnh cũ
          chisonuocnongcu: item.chisonuocnongmoi, // Đặt lại chỉ số nước lạnh mới về 0
          chisonuoclanhmoi: 0, // Đặt lại chỉ số nước lạnh mới về 0
          chisonuocnongmoi: 0, // Đặt lại chỉ số nước lạnh mới về 0
          sinhhoatchung: item.sinhhoatchung,
          ghichu: item.ghichu,
        };

        const response = await withLoading(GetUpdateRoom(item._id, object));

        if (response && position >= props.length) {
          openModal(<ListRoom />);
        }
      }
    }
  };

  const handleBack = () => {
    openModal(<ListRoom />);
  };

  const Total = async () => {
    const response = await withLoading(GetAllRoomsMonth());
    const data = response.data;
    if (response) {
      openModal(<TotalPaymentInfo props={data} only={3} />);
    }
  };

  if (loading) {
    return <Loading text="Đang tải dữ liệu phòng..." />;
  }

  const handleOpenAddDataRoom = () => {
    openModal(<AddDataRoom />);
  };
  return (
    <div className={cx("invoice-summary")}>
      <div className={cx("summary-item")}>
        <button
          onClick={() => handleOpenAddDataRoom()}
          className={cx("btn-summary", "btn-total")}
        >
          Nạp dữ liệu
        </button>
      </div>
      <div className={cx("summary-item")}>
        <button
          onClick={() => Total()}
          className={cx("btn-summary", "btn-total")}
        >
          Tổng kết
        </button>
      </div>
      <div className={cx("summary-item")}>
        <button
          onClick={() => HandleRefresh()}
          className={cx("btn-summary", "btn-refresh")}
        >
          Làm mới
        </button>
      </div>
      <div className={cx("summary-item")}>
        <button onClick={handleBack} className={cx("btn-summary", "btn-back")}>
          Quay lại
        </button>
      </div>
    </div>
  );
}

export default Menu;
