import React from "react";
import classNames from "classnames/bind";
import styles from "./PayMentInfo.module.scss";
import InvoiceCard from "./InvoiceCard";
const cx = classNames.bind(styles);

function InvoiceList({ props, openModal }) {
  return (
    <div className={cx("invoice-list")}>
      {props
        .filter((item) => item.GiaPhong >= 0)
        .map((item) => (
          <InvoiceCard key={item.SoPhong} item={item} openModal={openModal} />
        ))}
    </div>
  );
}

export default InvoiceList;
