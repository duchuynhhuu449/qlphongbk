import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./PayMentInfo.module.scss";
import classNames from "classnames/bind";
import { useModal } from "component/Modal/ModalContext";
import Loading from "../../Loading";
import { useLoading } from "../../../hooks/useLoading";
import { GetAllRoomsMonth } from "api";

import Bill from "component/Bill/Bill";
import Menu from "./Menu";
import ChoiceCheckbox from "./ChoiceCheckbox";
import InvoiceList from "./InvoiceList";

const cx = classNames.bind(styles);

function PayMentInfo({ props }) {
  const { openModal, closeModal } = useModal();
  const navigate = useNavigate();
  const [choice, setChoice] = useState(0);
  const [data, setData] = useState(props || []);
  const { loading, withLoading } = useLoading();

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!props) {
          const response = await withLoading(GetAllRoomsMonth());
          if (response) {
            setData(response.data);
          }
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
      }
    };
    fetchData();
  }, [props]);

  useEffect(() => {
    if (choice === 2) {
      openModal(<Bill />);
    }
  }, [choice]);

  useEffect(() => {
    if (choice === 2) {
      closeModal(); // Close modal
      navigate('/hata/all');
    }
  }, [choice, navigate, openModal]);

  if (loading) {
    return <Loading text="Đang tải thông tin thanh toán..." />;
  }

  return (
    <div className={cx("invoice-container")}>
      <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
        <i className="fas fa-times"></i>
      </button>
      <h2 className={cx("invoice-title")}>Danh sách hóa đơn thanh toán</h2>
      <Menu props={props} />
      {choice === 0 && <ChoiceCheckbox setChoice={setChoice} choice={choice} />}
      {choice === 1 && <InvoiceList props={props} openModal={openModal} />}
    </div>
  );
}

export default PayMentInfo;
