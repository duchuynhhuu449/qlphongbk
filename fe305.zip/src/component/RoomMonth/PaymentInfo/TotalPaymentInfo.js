import React, { useEffect, useState } from "react";
import styles from "./TotalPaymentInfo.module.scss";
import classNames from "classnames/bind";
import { useModal } from "component/Modal/ModalContext";
import Room from "component/RoomMonth/Room";

const cx = classNames.bind(styles);

function TotalPaymentInfo({ props}) {

  const [data, setData] = useState({});

  const [onlyPrice, setOnlyPrice] = useState(3)
  const {openModal} = useModal()

  useEffect(() => {
    let totalRoom = 0;
    let totalElectric = 0;
    let totalWater = 0;
    let totalElectricUsed = 0;
    let totalWaterUsed = 0;
    let total = 0;
    let roomCount = [];
    let filteredRooms;
  
    // Lọc các phòng có giá lớn hơn 0 khi onlyPrice === 2
    if (onlyPrice === 1) {
      filteredRooms = props.filter((item) => item.GiaPhong > 0);
    } else {
     
      filteredRooms = props.filter((item) => item.GiaPhong < 1);
      
    }
  
    filteredRooms.forEach((item) => {
   
      roomCount.push(item.SoPhong);
      
      const totalElectricCount = item.chisodienmoi - item.chisodiencu < 0 ? 0 : item.chisodienmoi - item.chisodiencu;
      
      const totalWaterCount = item.loainuoc === "chiso" &&
        (item.chisonuoclanhmoi + item.chisonuocnongmoi) - 
        (item.chisonuocnongcu + item.chisonuoclanhcu);
  
      totalElectric += totalElectricCount;
      
      totalElectricUsed += totalElectricCount * 4000;
  
      totalWater += totalWaterCount;
      totalWaterUsed += item.loainuoc === "chiso" ? totalWaterCount * 20000 : item.giakhoangnuoc * item.songuoikhoang;

      total += item.GiaPhong + totalElectricUsed + totalWaterUsed + item.sinhhoatchung + item.giakhoangnuoc;
    });
  
    if (roomCount.length) {
      setData({
        totalRoom: totalRoom.toLocaleString(),
        totalElectric: totalElectric > 0 ? totalElectric : 0,
        totalWater: totalWater > 0 ? totalWater : 0,
        totalElectricUsed:
          totalElectricUsed > 0 ? totalElectricUsed.toLocaleString() : 0,
        totalWaterUsed:
          totalWaterUsed > 0 ? totalWaterUsed.toLocaleString() : 0,
        roomCount: roomCount.length
          ? roomCount.join(", ")
          : "Không có phòng nào phù hợp",
        total: total > 0 ? total.toLocaleString() : 0,
      });
      
    } else {
      setOnlyPrice(3);  // Reset lại giá trị chỉ khi không tìm thấy phòng
    }
  
  }, [onlyPrice, props]); // Thêm props vào dependency list

  return (
    <div className={cx("container")}>
      <div className={cx("summary-item")}>
        <button onClick={(e) => setOnlyPrice(2)} className={cx("btn-summary")}>
          Tổng kết hóa đơn phòng trống
        </button>
        <button onClick={(e) => setOnlyPrice(1)}  className={cx("btn-summary", "btn-total")}>
          Tổng kết hóa đơn phòng hiện có
        </button>
      </div>
      {onlyPrice == 3 && <div className={cx("center")}><span>Hiện chưa có dữ liệu được nạp vui lòng thử lại sau khi nạp dữ liệu</span></div>}

{(onlyPrice === 1 || onlyPrice === 2) && (
  <div className={cx("result")}>
    <div className={cx("result-item")}>
      <strong>Phân loại</strong> {onlyPrice === 2 ? "Các phòng chưa có khách" : "Các phòng có khách"}
    </div>
    <div className={cx("result-item")}>
      <strong>Tổng số phòng đã tính:</strong> Phòng: {data.roomCount}
    </div>

    <div className={cx("result-item")}>
      <strong>Tổng lượng điện sử dụng:</strong> {data.totalElectric} kWh
    </div>

    <div className={cx("result-item")}>
      <strong>Tổng tiền điện:</strong> {data.totalElectricUsed} đồng
    </div>

    <div className={cx("result-item")}>
      <strong>Tổng lượng nước sử dụng:</strong> {data.totalWater} m³
    </div>

    <div className={cx("result-item")}>
      <strong>Tổng tiền nước:</strong> {data.totalWaterUsed} đồng
    </div>

    <div className={cx("result-item")}>
      <strong>Tổng tiền phòng:</strong> {data.total} đồng
    </div>

    <div className={cx("result-item")}>
      <button onClick={(e) => openModal(<Room />)} className={cx("button")}>⬅️ Quay lại</button>
    </div>
  </div>
)}

    </div>
  );
}

export default TotalPaymentInfo;
