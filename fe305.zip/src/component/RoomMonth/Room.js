import React, { useEffect, useState } from "react";
import { GetAllRoomsMonth, GetUpdateRoom, deleteRoomV2 } from "api";
import { useModal } from "component/Modal/ModalContext";
import classNames from "classnames/bind";
import styles from "./Room.module.scss";
import AddRoomMonth from "./AddRoomMonth/AddRoomMonth";
import { FaTrash, FaEdit, FaSearch } from "react-icons/fa";
import AdjustRoomMonth from "./AdjustRoom/AdjustRoom";
import PayMentInfo from "./PaymentInfo/PaymentInfo";

import { useParams } from "react-router";
import Loading from "../Loading";
import { useLoading } from "../../hooks/useLoading";
import { showSuccess, showError, showWarning } from "utils/toast";

const cx = classNames.bind(styles);

function Room({ props }) {
  const { room } = useParams();
  const [ListRoom, setListRoom] = useState([]);
  const [saveListRoom, setSaveListRoom] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const { openModal } = useModal();
  const { loading, withLoading } = useLoading();

  useEffect(() => {
    const GetRoom = async () => {
      try {
        const response = await withLoading(GetAllRoomsMonth());
        if (response) {
          const filtered = response.data.filter(
            (item) => item.SoPhong === Number(room) || item.SoPhong === Number(props)
          );
          setListRoom(filtered.length > 0 ? filtered : response.data.filter((item) => item.GiaPhong > 0));
          setSaveListRoom(response.data)
        }
      } catch (error) {
        console.error("Error fetching rooms:", error);
      }
    };
    GetRoom();
  }, [room, props]);

  const filteredRooms = ListRoom.filter(room =>
    room.SoPhong.toString().includes(searchTerm)
  );

  const handleOpenAddRoom = () => {
    openModal(<AddRoomMonth list={ListRoom} />);
  };

  const handleDeleteRoom = async (id) => {
    const password = prompt("Bạn hãy nhập mật khẩu để xóa phòng?");
    if (password !== "0786566176") {
      showWarning("Mật khẩu không đúng!");
      return;
    }

    const response = await deleteRoomV2(id);
    if (response) {
      showSuccess("Xóa phòng thành công!");
      setListRoom(response.data);
    }
  };

  const handlePaymentInfo = () => {
    openModal(<PayMentInfo props={saveListRoom} />);
  };


  const handleOpenAjust = (item) => {
    openModal(<AdjustRoomMonth props={item} />);
  }



  if (loading) {
    return <Loading text="Đang tải dữ liệu phòng..." />;
  }


  const handleSelect = (type) => {
    let filter
    if (type == 1) {
      filter = saveListRoom.filter((item) => item.GiaPhong > 0)
    } else {
      filter = saveListRoom.filter((item) => !item.GiaPhong)
    }

    setListRoom(filter)
  }

  return (
    <>
      <div>
        <div className={cx("search")}>
          <div className={cx("search-input-container")}>
            <input
              type="text"
              placeholder="Tìm kiếm số phòng..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={cx("search-input")}
            />
            <FaSearch className={cx("search-icon")} />
          </div>
          <button
            onClick={(e) => handleOpenAddRoom()}
            className={cx("search-button")}
          >
            Tạo hợp đồng
          </button>
          <button
            onClick={(e) => handlePaymentInfo()}
            className={cx("search-button")}
          >
            Tạo Hóa Đơn
          </button>

        </div>
        <div className={cx("controller-tab")}>
          <select onChange={(e) => handleSelect(e.target.value)} className={cx("selection")}>
            <option value="1">Các phòng đã có khách</option>
            <option value="2">Các phòng chưa nhận khách</option>
          </select>
        </div>
        <div className={cx("roomGrid")}>
          {filteredRooms.length > 0 ? (
            filteredRooms.map((item) => (
              <div key={item._id} className={cx("roomCard")}>
                <div className={cx("roomHeader")}>
                  <div className={cx("roomTitleContainer")}>
                    <span className={cx("roomNumberBadge")}>Phòng {String(item.SoPhong).padStart(3, '0')}</span>
                    {item.GiaPhong > 0 && <span className={cx("statusBadge", "occupied")}>Đã thuê</span>}
                    {!item.GiaPhong && <span className={cx("statusBadge", "empty")}>Phòng trống</span>}
                  </div>
                  <div className={cx("roomActions")}>
                    <button
                      onClick={(e) => handleOpenAjust(item)}
                      className={cx("iconBtn", "editBtn")}
                      title="Sửa phòng"
                    >
                      <FaEdit />
                    </button>
                    <button
                      onClick={(e) => handleDeleteRoom(item._id)}
                      className={cx("iconBtn", "deleteBtn")}
                      title="Xóa phòng"
                    >
                      <i className="fas fa-trash-alt"></i>
                    </button>
                  </div>
                </div>

                <div className={cx("roomDetails")}>
                  <div className={cx("detailRow")}>
                    <span className={cx("label")}><i className="fas fa-money-bill-wave"></i> Giá phòng:</span>
                    <span className={cx("value", "priceHighlight")}>{item.GiaPhong.toLocaleString()} VNĐ</span>
                  </div>
                  <div className={cx("detailRow")}>
                    <span className={cx("label")}><i className="fas fa-bolt"></i> Điện mới:</span>
                    <span className={cx("value")}>{item.chisodienmoi}</span>
                  </div>

                  {item.loainuoc === "chiso" ? (
                    <div className={cx("detailRow")}>
                      <span className={cx("label")}><i className="fas fa-tint"></i> Nước mới:</span>
                      <span className={cx("value")}>Nóng {item.chisonuocnongmoi} | Lạnh {item.chisonuoclanhmoi}</span>
                    </div>
                  ) : (
                    <div className={cx("detailRow")}>
                      <span className={cx("label")}><i className="fas fa-users"></i> Gói khoáng:</span>
                      <span className={cx("value")}>{item.songuoikhoang} N x {item.giakhoangnuoc.toLocaleString()}đ</span>
                    </div>
                  )}

                  <div className={cx("detailRow")}>
                    <span className={cx("label")}><i className="fas fa-hands-helping"></i> Sinh hoạt:</span>
                    <span className={cx("value")}>{item.sinhhoatchung.toLocaleString()} VNĐ</span>
                  </div>
                </div>

              </div>
            ))
          ) : (
            <div className={cx("noDataState")}>
              <i className="fas fa-box-open"></i>
              <p>Không tìm thấy phòng nào phù hợp.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Room;
