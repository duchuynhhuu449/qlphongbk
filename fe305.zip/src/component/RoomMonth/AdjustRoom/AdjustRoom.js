import React, { useState, useEffect } from "react";
import classNames from "classnames/bind";
import styles from "./AdjustRoom.module.scss";
import { GetUpdateRoom } from "api";
import { useModal } from "component/Modal/ModalContext";
import ListRoom from "component/RoomMonth/Room";
import { VNDFormatter } from "component/VNDFormatter";
import Loading from "../../Loading";
import { useLoading } from "../../../hooks/useLoading";

const cx = classNames.bind(styles);

function AdjustRoom({ props }) {
  const [data, setData] = useState({});
  const [deposit, setDeposit] = useState({});
  const [message, setMessage] = useState("");
  const { loading, withLoading } = useLoading();

  const { openModal, closeModal } = useModal();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await withLoading(GetUpdateRoom(props._id, data));
      setTimeout(() => {
        setMessage("");
      }, 3000);
      setMessage("Cập nhật phòng thành công!");
    } catch (error) {
      console.error("Error updating room:", error);
      setMessage(error.message);
    }
  };

  const handleDeposit = (value) => {
    const rawValue = value.replace(/\./g, "");
    const numberValue = parseInt(rawValue, 10) || 0;
    return numberValue.toLocaleString();
  };
  useEffect(() => {
    // Cập nhật `data`
    setData({
      hovaten: props.hovaten,
      GiaPhong: props.GiaPhong,
      chisodiencu: props.chisodiencu,
      chisodienmoi: props.chisodienmoi,
      chisonuoclanhcu: props.chisonuoclanhcu,
      chisonuoclanhmoi: props.chisonuoclanhmoi,
      chisonuocnongcu: props.chisonuocnongcu,
      chisonuocnongmoi: props.chisonuocnongmoi,
      sinhhoatchung: props.sinhhoatchung,
      ghichu: props.ghichu,
      loainuoc: props.loainuoc || "chiso",
      giakhoangnuoc: props.giakhoangnuoc,
      songuoikhoang: props.songuoikhoang,
      NgayLap: props.NgayLap || "",
      NgayHetHan: props.NgayHetHan || "",
    });
    setDeposit({
      giakhoangnuoc: props.giakhoangnuoc,
      GiaPhong: props.GiaPhong,
      sinhhoatchung: props.sinhhoatchung,
    });
  }, [props]);

  useEffect(() => {
    // Chạy lại khi `data` thay đổi
    ["GiaPhong", "sinhhoatchung"].forEach((key) => {
      if (data[key]) {
        const formattedValue = handleDeposit(data[key]);
        setDeposit((prev) => ({ ...prev, [key]: formattedValue }));
      }
    });
  }, [props]); // Theo dõi sự thay đổi của `data`

  const handleBackAgian = () => {
    return openModal(<ListRoom />);
  };

  if (loading) {
    return <Loading text="Đang cập nhật thông tin phòng..." />;
  }

  return (
    <>
      <div className={cx("container")}>
        <div className={cx("invoice-header")}>
          <h2 className={cx("title")}>Cập nhật phòng - {props.SoPhong}</h2>
          <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
            <i className="fas fa-times"></i>
          </button>
        </div>
        <form className={cx("form")} id="roomForm" onSubmit={handleSubmit}>
          {/* Nhóm thông tin số phòng và giá phòng */}
          <div className={cx("formGroup")}>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Họ và tên</label>
              <input
                value={data.hovaten || ""}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    hovaten: e.target.value,
                  }))
                }
                type="text"
                id="hovaten"
                required
                className={cx("input")}
              />
            </div>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Số Phòng</label>
              <input
                value={props.SoPhong}
                type="number"
                id="SoPhong"
                disabled
                className={cx("input")}
              />
            </div>
          </div>

          {/* Nhóm thông tin sinh hoạt chung */}
          <div className={cx("formGroup")}>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Giá phòng tháng</label>
              <input
                value={data.GiaPhong || ""}
                onChange={(e) => {
                  setData((prev) => ({ ...prev, GiaPhong: e.target.value }));
                  setDeposit((prev) => ({
                    ...prev,
                    GiaPhong: e.target.value,
                  }));
                }}
                type="number"
                id="GiaPhong"
                required
                className={cx("input")}
              />
              <span>{VNDFormatter(deposit.GiaPhong) || ""}</span>
            </div>

            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Phí sinh hoạt</label>
              <input
                value={data.sinhhoatchung || ""}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    sinhhoatchung: e.target.value,
                  }))
                }
                type="number"
                id="sinhhoatchung"
                required
                className={cx("input")}
              />
              <span>
                {VNDFormatter(data.sinhhoatchung) || ""}
              </span>
            </div>
          </div>

          {/* Nhóm thông tin thời gian hợp đồng */}
          <div className={cx("formGroup")}>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Ngày lập</label>
              <input
                value={data.NgayLap || ""}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, NgayLap: e.target.value }))
                }
                type="date"
                id="NgayLap"
                className={cx("input")}
              />
            </div>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Ngày hết hạn</label>
              <input
                value={data.NgayHetHan || ""}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, NgayHetHan: e.target.value }))
                }
                type="date"
                id="NgayHetHan"
                className={cx("input")}
              />
            </div>
          </div>

          {/* Nhóm chỉ số điện và nước */}
          <div className={cx("formGroup")}>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Chỉ số điện cũ</label>
              <input
                value={data.chisodiencu || ""}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, chisodiencu: e.target.value }))
                }
                type="number"
                id="chisodien"
                required
                className={cx("input")}
              />
            </div>
            <div className={cx("inputGroup")}>
              <label className={cx("label")}>Chỉ số điện mới</label>
              <input
                value={data.chisodienmoi || ""}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, chisodienmoi: e.target.value }))
                }
                type="number"
                id="chisodien"
                required
                className={cx("input")}
              />
            </div>
          </div>

          {/* Sự lựa chọn */}
          <div className={cx("formGroup", "w-100")}>
            <div className={cx("section")}>
              <label className={cx("label", "w-100")}>Loại sử dụng nước</label>
              <select
                value={data.loainuoc || "0"}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    loainuoc: e.target.value,
                  }))
                }
                id="loainuoc"
                className={cx("input", "selection")}
              >
                <option value="0">Lựa chọn phù hợp</option>
                <option value="chiso">Dùng nước tính theo chỉ số</option>
                <option value="khoang">
                  Dùng nước khoáng (
                  {VNDFormatter(data.giakhoangnuoc)}/người)
                </option>
              </select>
            </div>
          </div>

          {/* Nhóm chỉ số nước nóng và nước lạnh */}

          {/* Nhóm chỉ số nước lạnh cũ và mới */}

          {data.loainuoc == "chiso" && (
            <>
              <div className={cx("formGroup")}>
                <div className={cx("inputGroup")}>
                  <label className={cx("label")}>Chỉ số nước nóng cũ</label>
                  <input
                    value={data.chisonuocnongcu || ""}
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        chisonuocnongcu: e.target.value,
                      }))
                    }
                    type="number"
                    id="chisodien"
                    required
                    className={cx("input")}
                  />
                </div>
                <div className={cx("inputGroup")}>
                  <label className={cx("label")}>Chỉ số nước nóng mới</label>
                  <input
                    value={data.chisonuocnongmoi || ""}
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        chisonuocnongmoi: e.target.value,
                      }))
                    }
                    type="number"
                    id="chisodien"
                    required
                    className={cx("input")}
                  />
                </div>
              </div>
              <div className={cx("formGroup")}>
                <div className={cx("inputGroup")}>
                  <label className={cx("label")}>Chỉ số nước lạnh cũ</label>
                  <input
                    value={data.chisonuoclanhcu || ""}
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        chisonuoclanhcu: e.target.value,
                      }))
                    }
                    type="number"
                    id="chisonuoclanh"
                    required
                    className={cx("input")}
                  />
                </div>
                <div className={cx("inputGroup")}>
                  <label className={cx("label")}>Chỉ số nước lạnh mới</label>
                  <input
                    value={data.chisonuoclanhmoi || ""}
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        chisonuoclanhmoi: e.target.value,
                      }))
                    }
                    type="number"
                    id="chisonuoclanh"
                    required
                    className={cx("input")}
                  />
                </div>
              </div>
            </>
          )}

          {data.loainuoc == "khoang" && (
            <>
              <div className={cx("formGroup")}>
                <div className={cx("inputGroup")}>
                  <label className={cx("label")}>Số lượng người ở</label>
                  <input
                    value={data.songuoikhoang || ""}
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        songuoikhoang: Number(e.target.value),
                      }))
                    }
                    type="number"
                    id="songuoikhoang"
                    required
                    className={cx("input")}
                  />
                </div>

                <div className={cx("inputGroup")}>
                  <label className={cx("label")}>Giá khoáng điều chỉnh</label>
                  <input
                    value={data.giakhoangnuoc || ""}
                    onChange={(e) => {
                      setData((prev) => ({
                        ...prev,
                        giakhoangnuoc: Number(e.target.value),
                      }));
                      setDeposit((prev) => ({
                        ...prev,
                        giakhoangnuoc: e.target.value,
                      }));
                    }}
                    type="number"
                    id="giakhoangnuoc"
                    required
                    className={cx("input")}
                  />
                  <span>
                    {<VNDFormatter value={deposit.giakhoangnuoc} /> || ""}
                  </span>
                </div>
              </div>
            </>
          )}

          <div className={cx("control")}>
            <button
              type="button"
              onClick={() => handleBackAgian()}
              className={cx("button")}
            >
              Quay lại
            </button>
            <button
              type="submit"
              className={cx("button")}
            >
              Cập Nhật
            </button>
          </div>
        </form>
        <p id="message" className={cx("message")}>
          {message}
        </p>
      </div>
    </>
  );
}

export default AdjustRoom;
