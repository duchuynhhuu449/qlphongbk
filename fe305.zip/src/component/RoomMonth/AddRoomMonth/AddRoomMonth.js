import React, { useState, useEffect } from "react";
import classNames from "classnames/bind";
import styles from "./AddRoomMonth.module.scss";
import { addRoomV2, GetAllRoomsMonth, GetUpdateRoom } from "api";
import { useModal } from "component/Modal/ModalContext";
import ListRoom from "../Room";
import generateContract from "component/Contract/Contract";
import {
  CurrentDate,
  CalculateEndDate,
  formatNumberWithLeadingZeros,
  formatBirthDate,
  formatFloorNumber
} from "component/dateUtils";
import { convertNumberToVietnameseText } from "component/VietnamText/Vietnamtext";
import { VNDFormatter } from "component/VNDFormatter";
import Loading from "../../Loading";
import { useLoading } from "../../../hooks/useLoading";

import { useNavigate, useLocation } from 'react-router-dom';

const cx = classNames.bind(styles);

function AddRoomMonth({ list, onUpdate }) {
  const [data, setData] = useState({});
  const [deposit, setDeposit] = useState({});
  const [message, setMessage] = useState("");
  const { openModal, closeModal } = useModal();
  const [typeofWater, setTypeofWater] = useState(0);
  const [contractData, setContractData] = useState({});
  const { loading, withLoading } = useLoading();
  const [roomList, setRoomList] = useState([]);
  const [dbRoomsList, setDbRoomsList] = useState([]);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Load room data from room.json
  // Load room data from room.json and sync with backend
  useEffect(() => {
    const loadRoomData = async () => {
      try {
        const [jsonResponse, dbResponse] = await Promise.all([
          fetch("/room.json"),
          GetAllRoomsMonth()
        ]);
        const jsonData = await jsonResponse.json();
        const dbRooms = dbResponse?.data || [];
        setDbRoomsList(dbRooms);
        const occupiedRoomNumbers = dbRooms.filter(r => r.GiaPhong > 0).map(r => String(r.SoPhong));

        const updatedRooms = jsonData.rooms.map(room => {
          // If the room already exists in the backend DB and is actually occupied, mark it as occupied
          if (occupiedRoomNumbers.includes(String(room.roomNumber))) {
            return { ...room, status: "occupied" };
          }
          return room;
        });

        setRoomList(updatedRooms);
      } catch (error) {
        console.error("Error loading room data:", error);
        setMessage("Không thể tải dữ liệu phòng");
      }
    };
    loadRoomData();
  }, []);

  // Handle room selection
  const handleRoomSelect = (roomNumber) => {
    const room = roomList.find((r) => r.roomNumber === roomNumber);
    if (room) {
      setSelectedRoom(room);
      const giaPhong = room.price.toString();
      setData((prev) => ({
        ...prev,
        SoPhong: room.roomNumber,
        GiaPhong: giaPhong
      }));

      // Update contract data
      setContractData((prev) => ({
        ...prev,
        SOPHONG: room.roomNumber,
        FLOOR: formatFloorNumber(room.floor),
        GIAPHONG: VNDFormatter(giaPhong),
        GIABANGCHU: convertNumberToVietnameseText(giaPhong) || "Không đồng",
        BATDAU: CurrentDate(),
        KETTHUC: CalculateEndDate(data.sothang || 1)
      }));


    }
  };

  const handleAddRoom = async () => {
    const today = new Date();
    const giaPhong = data.GiaPhong || "0";

    // Cập nhật contractData với thông tin chính xác theo template
    const updatedContractData = {
      HOVATEN: data.hovaten,
      NAMSINH: formatBirthDate(data.NAMSINH),
      MASOCCCD: data.cccd,
      NGAYCAP: formatBirthDate(data.NGAYCAP),
      THUONGTRU: data.noithuongtru,
      SODIENTHOAI: "",
      FLOOR: formatFloorNumber(selectedRoom?.floor),
      SOPHONG: data.SoPhong,
      DANHSACHNGUOITHUE: data.nguoio,
      SOTHANGTHUE: formatNumberWithLeadingZeros(data.sothang),
      BATDAU: CurrentDate(),
      KETTHUC: CalculateEndDate(data.sothang || 1),
      GIAPHONG: VNDFormatter(giaPhong),
      GIABANGCHU: convertNumberToVietnameseText(giaPhong) || "Không đồng",
      CHISODIENBANGIAO: formatNumberWithLeadingZeros(data.chisodiencu || 0),
      CHISONUOCBANGIAO: formatNumberWithLeadingZeros((Number(data.chisonuoclanh) || 0) + (Number(data.chisonuocnong) || 0)),
      NOITHAT: selectedRoom?.furniture
    };

    setContractData(updatedContractData);

    if (typeofWater == 0) {
      setMessage("Vui lòng chọn loại sử dụng nước");
      return;
    }

    if (
      !data.SoPhong ||
      !data.GiaPhong ||
      !data.NgayLap ||
      !data.NgayHetHan
    ) {
      setMessage("Vui lòng điền đầy đủ thông tin bắt buộc (kể cả Ngày lập và Ngày hết hạn)");
      return;
    }

    try {
      await withLoading((async () => {
        // Prepare data for API
        const dataToSave = {
          hovaten: data.hovaten || "",
          SoPhong: data.SoPhong,
          GiaPhong: Number(data.GiaPhong.replace(/\./g, "")),
          chisodiencu: Number(data.chisodiencu) || 0,
          chisodienmoi: Number(data.chisodiencu) || 0,
          chisonuoclanhcu: Number(data.chisonuoclanh) || 0,
          chisonuoclanhmoi: Number(data.chisonuoclanh) || 0,
          chisonuocnongcu: Number(data.chisonuocnong) || 0,
          chisonuocnongmoi: Number(data.chisonuocnong) || 0,
          sinhhoatchung: Number(data.sinhhoatchung?.replace(/\./g, "")) || 0,
          ghichu: data.nguoio || "",
          loainuoc: typeofWater === "1" ? "chiso" : "khoang",
          songuoikhoang: Number(data.nguoi) || 0,
          giakhoangnuoc: 90000,
          NgayLap: data.NgayLap,
          NgayHetHan: data.NgayHetHan
        };

        const existingRoom = dbRoomsList.find(r => String(r.SoPhong) === String(data.SoPhong));
        if (existingRoom) {
          await GetUpdateRoom(existingRoom._id, dataToSave);
        } else {
          await addRoomV2(dataToSave);
        }

        await generateContract(updatedContractData);

        setData({});
        setMessage("Thêm phòng thành công!");

        // Reset form sau 3 giây
        setTimeout(() => {
          setMessage("");
          closeModal();
          if (onUpdate) onUpdate();
        }, 3000);
      })());
    } catch (e) {
      setMessage("Có lỗi xảy ra khi lưu phòng: " + e.message);
    }
  };

  useEffect(() => {
    const handleDeposit = (value) => {
      const rawValue = value.replace(/\./g, "");
      const numberValue = parseInt(rawValue, 10) || 0;
      return numberValue.toLocaleString();
    };

    ["GiaPhong", "sinhhoatchung"].forEach((key) => {
      if (data[key]) {
        const formattedValue = handleDeposit(data[key]);
        setDeposit((prev) => ({ ...prev, [key]: formattedValue }));
      }
    });

    // Tự động tính ngày hết hạn dựa trên ngày lập và số tháng
    if (data.NgayLap && data.sothang && !isNaN(Number(data.sothang))) {
      const startDate = new Date(data.NgayLap);
      if (!isNaN(startDate.getTime())) {
        const monthsToAdd = Number(data.sothang);
        const endDate = new Date(startDate);
        endDate.setMonth(endDate.getMonth() + monthsToAdd);

        // Handle edge cases like starting on Jan 31 + 1 month -> Feb 28
        if (endDate.getDate() !== startDate.getDate()) {
          endDate.setDate(0); // Set to last day of previous month
        }

        const formattedEndDate = endDate.toISOString().split('T')[0];
        if (data.NgayHetHan !== formattedEndDate) {
          setData(prev => ({ ...prev, NgayHetHan: formattedEndDate }));
        }
      }
    }
  }, [data.GiaPhong, data.sinhhoatchung, data.NgayLap, data.sothang]);

  const handleCloseBack = () => {
    closeModal();
  };

  // Hàm tạo dữ liệu mẫu
  const generateSampleData = () => {
    const sampleData = {
      cccd: "001234567890",
      NAMSINH: "1990-01-01",
      noithuongtru: "123 Đường ABC, Quận XYZ, TP.HCM",
      nguoio: "Nguyễn Văn B, Trần Thị C",
      SoPhong: roomList[0]?.roomNumber || "101",
      GiaPhong: "3500000",
      sinhhoatchung: "500000",
      sothang: "12",
      sonam: "1",
      chisodiencu: 100,
      chisonuoclanh: "50",
      chisonuocnong: "50",
      nguoi: "2"
    };

    // Cập nhật data state
    setData(sampleData);

    // Cập nhật contractData với cấu trúc mới
    const today = new Date();
    const updatedContractData = {
      HOVATEN: sampleData.hovaten || "",
      NAMSINH: formatBirthDate(sampleData.NAMSINH),
      MASOCCCD: sampleData.cccd,
      NGAYCAP: sampleData.NGAYCAP,
      THUONGTRU: sampleData.noithuongtru,
      SODIENTHOAI: "",
      FLOOR: formatFloorNumber(roomList[0]?.floor || 1),
      SOPHONG: sampleData.SoPhong,
      DANHSACHNGUOITHUE: sampleData.nguoio,
      SOTHANGTHUE: formatNumberWithLeadingZeros(sampleData.sothang),
      BATDAU: CurrentDate(),
      KETTHUC: CalculateEndDate(sampleData.sothang),
      GIAPHONG: VNDFormatter(sampleData.GiaPhong),
      GIABANGCHU: convertNumberToVietnameseText(sampleData.GiaPhong) || "Không đồng",
      CHISODIENBANGIAO: formatNumberWithLeadingZeros(sampleData.chisodiencu),
      CHISONUOCBANGIAO: formatNumberWithLeadingZeros(
        parseInt(sampleData.chisonuoclanh) + parseInt(sampleData.chisonuocnong)
      ),
      NOITHAT: selectedRoom?.furniture
    };

    setContractData(updatedContractData);
    setTypeofWater("1");
    setSelectedRoom(roomList[0] || null);

    setMessage("Đã tạo dữ liệu mẫu thành công!");
    setTimeout(() => {
      setMessage("");
    }, 3000);
  };


  if (loading) {
    return <Loading text="Đang thêm phòng mới..." />;
  }

  return (
    <>
      <div className={cx("container")}>
        <div className={cx("invoice-header")}>
          <h2 onClick={() => generateSampleData()} className={cx("title")} style={{ cursor: 'pointer' }}>Thêm hợp đồng mới</h2>
          <button className={cx("btn-close-modal")} onClick={handleCloseBack} title="Đóng">
            <i className="fas fa-times"></i>
          </button>
        </div>

        <form className={cx("form")} id="roomForm">
          {/* THÔNG TIN NGƯỜI THUÊ */}
          <div className={cx("section")}>
            <h3 className={cx("sectionTitle")}>Thông tin người thuê</h3>

            <div className={cx("formGroup")}>
              <label className={cx("label")}>Họ và tên</label>
              <input
                value={data.hovaten || ""}
                onChange={(e) => {
                  setData((prev) => ({ ...prev, hovaten: e.target.value }));
                  setContractData((prev) => ({
                    ...prev,
                    HOVATEN: e.target.value,
                  }));
                }}
                type="text"
                className={cx("input")}
                required
              />
            </div>

            <div className={cx("formGroup")}>
              <label className={cx("label")}>Căn cước công dân</label>
              <input
                value={data.cccd || ""}
                onChange={(e) => {
                  setData((prev) => ({ ...prev, cccd: e.target.value })); // Cập nhật data
                  setContractData((prev) => ({
                    ...prev,
                    MASOCCCD: e.target.value,
                  }));
                }}
                type="text"
                className={cx("input")}
                required
              />
            </div>
            <div className={cx("formGroup")}>
              <label className={cx("label")}>Ngày cấp</label>
              <input
                value={data.NGAYCAP || ""}
                onChange={(e) => {
                  setData((prev) => ({ ...prev, NGAYCAP: e.target.value })); // Cập nhật data
                  setContractData((prev) => ({
                    ...prev,
                    NGAYCAP: e.target.value,
                  }));
                }}
                type="date"
                className={cx("input")}
                required
              />
            </div>

            <div className={cx("formGroup")}>
              <label className={cx("label")}>Ngày sinh</label>
              <input
                value={data.NAMSINH || ""}
                onChange={(e) => {
                  setData((prev) => ({ ...prev, NAMSINH: e.target.value })); // Cập nhật data
                  setContractData((prev) => ({
                    ...prev,
                    NAMSINH: e.target.value,
                  }));
                }}
                type="date"
                className={cx("input")}
                required
              />
            </div>

            <div className={cx("formGroup")}>
              <label className={cx("label")}>Nơi thường trú</label>
              <input
                value={data.noithuongtru || ""}
                onChange={(e) => {
                  setData((prev) => ({
                    ...prev,
                    noithuongtru: e.target.value,
                  })); // Cập nhật data
                  setContractData((prev) => ({
                    ...prev,
                    THUONGTRU: e.target.value,
                  }));
                }}
                type="text"
                className={cx("input")}
                required
              />
            </div>

            <div className={cx("formGroup")}>
              <label className={cx("label")}>Người ở cùng (nhiều người)</label>
              <textarea
                value={data.nguoio || ""}
                onChange={(e) => {
                  setData((prev) => ({ ...prev, nguoio: e.target.value })); // Cập nhật data
                  setContractData((prev) => ({
                    ...prev,
                    DANHSACHNGUOITHUE: e.target.value,
                  }));
                }}
                className={cx("input")}
                rows="3"
                placeholder="Nhập thông tin mỗi người ở bằng cách xuống dòng"
              />
            </div>
          </div>

          {/* THÔNG TIN PHÒNG */}
          <div className={cx("section")}>
            <h3 className={cx("sectionTitle")}>Thông tin phòng</h3>

            <div className={cx("row")}>
              <div className={cx("formGroup")}>
                <label className={cx("label")}>Chọn phòng</label>
                <select
                  value={data.SoPhong || ""}
                  onChange={(e) => handleRoomSelect(e.target.value)}
                  className={cx("input", "selection")}
                  required
                >
                  <option value="">Chọn phòng</option>
                  {roomList.map((room) => (
                    <option
                      key={room.roomNumber}
                      value={room.roomNumber}
                      disabled={room.status !== "available"}
                    >
                      Phòng {room.roomNumber} - Tầng {room.floor} -{" "}
                      {data.GiaPhong == 0 ? VNDFormatter(data.price) : VNDFormatter(data.GiaPhong)}
                    </option>
                  ))}
                </select>
              </div>

              <div className={cx("formGroup")}>
                <label className={cx("label")}>Giá phòng tháng</label>
                <input
                  value={data.GiaPhong || ""}
                  onChange={(e) => {
                    setData((prev) => ({ ...prev, GiaPhong: e.target.value })); // Cập nhật data
                  }}
                  className={cx("input")}
                />
                <span>{deposit.GiaPhong || ""}</span>
              </div>
            </div>

            <div className={cx("row")}>
              <div className={cx("formGroup")}>
                <label className={cx("label")}>Thời gian ở (số tháng)</label>
                <input
                  value={data.sothang || ""}
                  onChange={(e) => {
                    const val = e.target.value;
                    const todayStr = new Date().toISOString().split('T')[0];
                    let ngayLap = data.NgayLap || todayStr;

                    let ngayHetHan = data.NgayHetHan || "";
                    if (val && !isNaN(Number(val))) {
                      const startDate = new Date(ngayLap);
                      const endDate = new Date(startDate);
                      endDate.setMonth(endDate.getMonth() + Number(val));
                      if (endDate.getDate() !== startDate.getDate()) {
                        endDate.setDate(0);
                      }
                      ngayHetHan = endDate.toISOString().split('T')[0];
                    }

                    setData((prev) => ({
                      ...prev,
                      sothang: val,
                      NgayLap: ngayLap,
                      NgayHetHan: ngayHetHan
                    }));

                    setContractData((prev) => ({
                      ...prev,
                      SOTHANGTHUE: val,
                      BATDAU: formatBirthDate(ngayLap),
                      KETTHUC: formatBirthDate(ngayHetHan)
                    }));
                    // Nếu chia hết cho 12 thì cập nhật số năm
                    if (val && Number(val) % 12 === 0) {
                      setData((prev) => ({ ...prev, sonam: String(Number(val) / 12) }));
                    }
                  }}
                  type="number"
                  className={cx("input")}
                  required
                />
              </div>

              <div className={cx("formGroup")}>
                <label className={cx("label")}>Ngày lập hợp đồng</label>
                <input
                  value={data.NgayLap || ""}
                  onChange={(e) => {
                    setData((prev) => ({ ...prev, NgayLap: e.target.value }));
                    setContractData((prev) => ({ ...prev, BATDAU: formatBirthDate(e.target.value) }));
                  }}
                  type="date"
                  className={cx("input")}
                  required
                />
              </div>
              <div className={cx("formGroup")}>
                <label className={cx("label")}>Ngày hết hạn</label>
                <input
                  value={data.NgayHetHan || ""}
                  onChange={(e) => {
                    setData((prev) => ({ ...prev, NgayHetHan: e.target.value }));
                    setContractData((prev) => ({ ...prev, KETTHUC: formatBirthDate(e.target.value) }));
                  }}
                  type="date"
                  className={cx("input")}
                  required
                />
              </div>

            </div>
          </div>

          {/* LỰA CHỌN NƯỚC */}
          <div className={cx("section")}>
            <label className={cx("label")}>Loại sử dụng nước</label>
            <select
              value={typeofWater}
              onChange={(e) => {
                setTypeofWater(e.target.value);
                setData((prev) => ({
                  ...prev,
                  loainuoc: e.target.value === "1" ? "chiso" : "khoang",
                }));
              }}
              className={cx("input", "selection")}
              id="loainuoc"
            >
              <option value="0">Lựa chọn phù hợp</option>
              <option value="1">Dùng nước tính theo chỉ số</option>
              <option value="2">Dùng nước khoáng (90.000đ/người)</option>
            </select>
          </div>

          {/* CHỈ SỐ ĐIỆN & NƯỚC */}
          <div className={cx("section")}>
            <h3 className={cx("sectionTitle")}>Chỉ số điện & nước</h3>

            <div className={cx("formGroup")}>
              <label className={cx("label")}>Chỉ số điện bàn giao</label>
              <input
                value={data.chisodiencu || ""}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, chisodiencu: e.target.value }))
                }
                type="number"
                className={cx("input")}
                required
              />
            </div>

            {typeofWater == 2 && (
              <div className={cx("formGroup")}>
                <label className={cx("label")}>Số lượng người</label>
                <input
                  value={data.nguoi || ""}
                  onChange={(e) =>
                    setData((prev) => ({ ...prev, nguoi: e.target.value }))
                  }
                  type="number"
                  className={cx("input")}
                  required
                />
              </div>
            )}

            {typeofWater == 1 && (
              <>
                <div className={cx("row")}>
                  <div className={cx("formGroup")}>
                    <label className={cx("label")}>Nước nóng bàn giao</label>
                    <input
                      value={data.chisonuocnong || ""}
                      onChange={(e) =>
                        setData((prev) => ({
                          ...prev,
                          chisonuocnong: e.target.value,
                        }))
                      }
                      type="number"
                      className={cx("input")}
                      required
                    />
                  </div>

                  <div className={cx("formGroup")}>
                    <label className={cx("label")}>Nước lạnh bàn giao</label>
                    <input
                      value={data.chisonuoclanh || ""}
                      onChange={(e) =>
                        setData((prev) => ({
                          ...prev,
                          chisonuoclanh: e.target.value,
                        }))
                      }
                      type="number"
                      className={cx("input")}
                      required
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* NÚT ĐIỀU KHIỂN */}
          <div className={cx("control")}>
            <button
              type="button"
              onClick={() => generateSampleData()}
              className={cx("button")}
              style={{ backgroundColor: '#28a745', marginRight: 'auto' }}
            >
              <i className="fas fa-magic"></i> Auto Fill (Test)
            </button>
            <button
              type="button"
              onClick={() => handleCloseBack()}
              className={cx("button")}
            >
              Quay lại
            </button>
            <button
              type="button"
              onClick={() => handleAddRoom()}
              className={cx("button")}
            >
              Thêm Phòng
            </button>
          </div>
        </form>

        <p id="message" className={cx("message")}>
          {message}
        </p>
      </div>
    </>
  );
}

export default AddRoomMonth;
