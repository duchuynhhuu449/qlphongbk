import React, { useState } from "react";
import classNames from "classnames/bind";
import styles from "./AddDataRoom.module.scss";
import { handleAdDataRoomMonth } from "api";

const cx = classNames.bind(styles);

function AddDataRoom() {
  const [data, setData] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const handleAddData = async () => {
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    const lines = data.trim().split("\n").map(line => line.trim()).filter(line => line !== "");
    const payload = lines.map(line => line.split(/\s+/)); // Split by any whitespace

    try {
      const response = await handleAdDataRoomMonth(payload)
      if(response) {
          setSuccessMessage(response.message || 'Thêm dữ liệu thành công.');
          setData(""); // Clear the textarea after successful submission
      }
    } catch (err) {
      setError('Lỗi kết nối đến máy chủ.');
      console.error("Fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={cx("container")}>
      <div className={cx("header")}>Thêm dữ liệu phòng</div>
      <div className={cx("content")}>
        <div className={cx("form")}>
          <div className={cx("form-group")}>
            <label htmlFor="roomName">Nhập dữ liệu phòng</label>
            <textarea
              value={data}
              onChange={(e) => setData(e.target.value)}
              id="roomName"
              name="roomName"
              rows="4"
              cols="50"
              placeholder="Nhập dữ liệu phòng. Mỗi dòng tương ứng với mỗi dữ liệu phòng, ví dụ: 001 2525 178 65 (số phòng, số điện mới, số nước lạnh mới, số nước nóng mới)"
            ></textarea>
          </div>
          <button
            className={cx("btn-submit")}
            onClick={handleAddData}
            disabled={loading}
          >
            {loading ? "Đang thêm..." : "Thêm dữ liệu"}
          </button>
        </div>
        {error && <div className={cx("error-message")}>{error}</div>}
        {successMessage && <div className={cx("success-message")}>{successMessage}</div>}
      </div>
    </div>
  );
}

export default AddDataRoom;