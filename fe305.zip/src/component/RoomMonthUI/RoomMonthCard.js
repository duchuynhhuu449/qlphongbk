import React, { useEffect, useState, useRef } from "react";
import classNames from "classnames/bind";
import styles from "../RoomDaily/Room.module.scss";
import { useDebounceHandler } from "../debounce";
import { FaEdit, FaTrash, FaPlug, FaTint, FaCalendarAlt } from "react-icons/fa";
import { useModal } from "component/Modal/ModalContext";
import AdjustRoomMonth from "../RoomMonth/AdjustRoom/AdjustRoom";
import { deleteRoomV2, GetUpdateRoom } from "../../api";
import { showSuccess, showError, showWarning } from "utils/toast";

const cx = classNames.bind(styles);

const RoomMonthCard = ({ room, handleInputChange, calculate, isSelected, onSelect, onUpdate }) => {
    const debounce = useDebounceHandler();

    // Local state for inputs to allow typing smoothly
    const [electricNew, setElectricNew] = useState(room.chisodienmoi || "");
    const [waterColdNew, setWaterColdNew] = useState(room.chisonuoclanhmoi || "");
    const [waterHotNew, setWaterHotNew] = useState(room.chisonuocnongmoi || "");
    const [ngayLap, setNgayLap] = useState(room.NgayLap || "");
    const [ngayHetHan, setNgayHetHan] = useState(room.NgayHetHan || "");
    const { openModal } = useModal();

    useEffect(() => {
        setElectricNew(room.chisodienmoi || "");
        setWaterColdNew(room.chisonuoclanhmoi || "");
        setWaterHotNew(room.chisonuocnongmoi || "");
        setNgayLap(room.NgayLap || "");
        setNgayHetHan(room.NgayHetHan || "");
    }, [room]);

    const handleChange = (field, value) => {
        if (field === "NgayLap") {
            setNgayLap(value);
            debounce(`${field}-${room._id}`, value, room[field], () => {
                handleInputChange(room._id, { [field]: value });
            });
            return;
        }
        if (field === "NgayHetHan") {
            setNgayHetHan(value);
            debounce(`${field}-${room._id}`, value, room[field], () => {
                handleInputChange(room._id, { [field]: value });
            });
            return;
        }

        let numericValue = parseInt(value, 10);
        if (isNaN(numericValue)) numericValue = 0;

        if (field === "chisodienmoi") setElectricNew(value);
        if (field === "chisonuoclanhmoi") setWaterColdNew(value);
        if (field === "chisonuocnongmoi") setWaterHotNew(value);

        debounce(
            `${field}-${room._id}`,
            numericValue,
            room[field],
            () => {
                handleInputChange(room._id, {
                    [field]: numericValue
                });
            }
        );
    };

    const handleSaveIndices = async () => {
        try {
            const eNew = parseInt(electricNew, 10) || 0;
            const wCNew = parseInt(waterColdNew, 10) || 0;
            const wHNew = parseInt(waterHotNew, 10) || 0;

            await GetUpdateRoom(room._id, {
                chisodienmoi: eNew,
                chisonuoclanhmoi: wCNew,
                chisonuocnongmoi: wHNew
            });
            showSuccess("Đã lưu chỉ số thành công!");
        } catch (e) {
            showError("Lỗi khi lưu chỉ số!");
        }
    };

    const handleDeleteRoom = async () => {
        const password = prompt("Bạn hãy nhập mật khẩu để xóa phòng?");
        if (password !== "0786566176") {
            showWarning("Mật khẩu không đúng!");
            return;
        }

        if (window.confirm(`Bạn có chắc muốn xóa phòng ${room.SoPhong}?`)) {
            try {
                await deleteRoomV2(room._id);
                if (onUpdate) onUpdate();
            } catch (error) {
                console.error("Lỗi khi xóa phòng:", error);
            }
        }
    };

    const isOccupied = room.GiaPhong > 0;

    return (
        <div
            className={cx("roomCard", { selected: isSelected })}
            onClick={() => onSelect && onSelect(room._id)}
        >
            {/* Room Header */}
            <div className={cx("roomHeader")}>
                <div className={cx("roomTitleGroup")}>
                    <div className={cx("roomNumber")}>{String(room.SoPhong).padStart(3, "0")}</div>
                    <div>
                        <h3 className={cx("roomTitle")}>Phòng {room.SoPhong}</h3>
                        <span className={cx("statusBadge", isOccupied ? "statusOccupied" : "statusEmpty")}>
                            {isOccupied ? "● Đã thuê" : "○ Trống"}
                        </span>
                    </div>
                </div>
                <div className={cx("iconActions")}>
                    <div className={cx("iconBtn", "deleteIcon")} onClick={(e) => { e.stopPropagation(); handleDeleteRoom(); }} title="Xóa phòng">
                        <FaTrash size={14} />
                    </div>
                    <div className={cx("iconBtn")} onClick={(e) => { e.stopPropagation(); openModal(<AdjustRoomMonth props={room} />); }} title="Điều chỉnh phòng">
                        <FaEdit size={14} />
                    </div>
                </div>
            </div>

            {/* Room Body */}
            <div className={cx("roomBody")} onClick={(e) => e.stopPropagation()}>
                {/* Dates */}
                <div className={cx("timeSection")} style={{ marginBottom: 8 }}>
                    <div className={cx("timeLabel")}>
                        <span className={cx("timeDot", "dotCheckin")} style={{ background: "#10b981" }} />
                        <FaCalendarAlt style={{ marginRight: 4 }} /> Thời gian hợp đồng
                    </div>
                    <div className={cx("timeContainer")} style={{ display: 'flex', gap: 6, padding: "8px" }}>
                        <div style={{ flex: 1 }}>
                            <label style={{ fontSize: 10, color: "var(--text-secondary)" }}>Ngày lập</label>
                            <input
                                type="date"
                                className={cx("timeInput")}
                                value={ngayLap}
                                onChange={(e) => handleChange("NgayLap", e.target.value)}
                                style={{ padding: "6px", fontSize: 11 }}
                            />
                        </div>
                        <div style={{ flex: 1 }}>
                            <label style={{ fontSize: 10, color: "var(--text-secondary)" }}>Ngày hết hạn</label>
                            <input
                                type="date"
                                className={cx("timeInput")}
                                value={ngayHetHan}
                                onChange={(e) => handleChange("NgayHetHan", e.target.value)}
                                style={{ padding: "6px", fontSize: 11 }}
                            />
                        </div>
                    </div>
                </div>

                {/* Electric & Water row */}
                <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                    {/* Electric Index */}
                    <div className={cx("timeSection")} style={{ flex: 1, marginBottom: 0 }}>
                        <div className={cx("timeLabel")}>
                            <span className={cx("timeDot", "dotCheckin")} style={{ background: "#eab308" }} />
                            <FaPlug style={{ marginRight: 4 }} /> Điện
                        </div>
                        <div className={cx("timeContainer")} style={{ flexDirection: 'column', gap: 4, padding: "8px" }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <span style={{ fontSize: 10, color: "var(--text-secondary)" }}>Số cũ: {room.chisodiencu || 0}</span>
                            </div>
                            <input
                                type="number"
                                className={cx("timeInput")}
                                value={electricNew}
                                onChange={(e) => handleChange("chisodienmoi", e.target.value)}
                                placeholder="Số mới"
                                style={{ padding: "6px", fontSize: 12, width: '100%' }}
                            />
                        </div>
                    </div>

                    {/* Water Index */}
                    {room.loainuoc === "chiso" ? (
                        <div className={cx("timeSection")} style={{ flex: 1, marginBottom: 0 }}>
                            <div className={cx("timeLabel")}>
                                <span className={cx("timeDot", "dotCheckout")} style={{ background: "#3b82f6" }} />
                                <FaTint style={{ marginRight: 4 }} /> Nước
                            </div>
                            <div className={cx("timeContainer")} style={{ flexDirection: 'column', gap: 4, padding: "8px" }}>
                                <div style={{ display: 'flex', gap: 4 }}>
                                    <div style={{ flex: 1 }}>
                                        <span style={{ fontSize: 9, color: "var(--text-secondary)", whiteSpace: 'nowrap' }}>Lạnh ({room.chisonuoclanhcu || 0})</span>
                                        <input
                                            type="number"
                                            className={cx("timeInput")}
                                            value={waterColdNew}
                                            onChange={(e) => handleChange("chisonuoclanhmoi", e.target.value)}
                                            placeholder="Mới"
                                            style={{ padding: "6px", fontSize: 12, width: '100%', marginTop: 2 }}
                                        />
                                    </div>
                                    <div style={{ flex: 1 }}>
                                        <span style={{ fontSize: 9, color: "var(--text-secondary)", whiteSpace: 'nowrap' }}>Nóng ({room.chisonuocnongcu || 0})</span>
                                        <input
                                            type="number"
                                            className={cx("timeInput")}
                                            value={waterHotNew}
                                            onChange={(e) => handleChange("chisonuocnongmoi", e.target.value)}
                                            placeholder="Mới"
                                            style={{ padding: "6px", fontSize: 12, width: '100%', marginTop: 2 }}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className={cx("timeSection")} style={{ flex: 1, marginBottom: 0 }}>
                            <div className={cx("timeLabel")}>
                                <span className={cx("timeDot", "dotCheckout")} style={{ background: "#3b82f6" }} />
                                <FaTint style={{ marginRight: 4 }} /> Nước
                            </div>
                            <div className={cx("timeContainer")} style={{ padding: "8px", height: "100%", display: "flex", alignItems: "center" }}>
                                <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>Khoán: {room.songuoikhoang || 0} người</span>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Buttons */}
            <div className={cx("btnContainer")} onClick={(e) => e.stopPropagation()}>
                <div className={cx("btnTop")}>
                    <button className={cx("roomButton", "checkIn")} style={{ background: "#3b82f6" }} onClick={handleSaveIndices}>
                        Lưu chỉ số
                    </button>
                </div>
                <div className={cx("btnBottom")}>
                    <button className={cx("roomButton", "calculate")} onClick={() => {
                        const currentData = {
                            ...room,
                            chisodienmoi: parseInt(electricNew, 10) || 0,
                            chisonuoclanhmoi: parseInt(waterColdNew, 10) || 0,
                            chisonuocnongmoi: parseInt(waterHotNew, 10) || 0,
                            NgayLap: ngayLap,
                            NgayHetHan: ngayHetHan
                        };
                        calculate(currentData);
                    }} style={{ flex: 1 }}>
                        Tính tiền
                    </button>
                </div>
            </div>

            {/* Price Badge */}
            {room.GiaPhong > 0 && (
                <div className={cx("depositBadge")} style={{ background: "var(--color-gold)", color: "#fff" }}>
                    Giá phòng: {room.GiaPhong.toLocaleString()}đ
                </div>
            )}
        </div>
    );
};

export default RoomMonthCard;
