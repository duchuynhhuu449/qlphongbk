import React, { useState, useEffect, useRef } from "react";
import RoomMonthCard from "./RoomMonthCard";
import { saveRoomHistory, GetAllRoomsMonth, GetUpdateRoom } from "../../api";
import classNames from "classnames/bind";
import styles from "../RoomDaily/Room.module.scss";
import { useModal } from "../Modal/ModalContext";
import { FaCalculator, FaSearch, FaTools, FaFileContract, FaPrint, FaBolt, FaChartBar } from "react-icons/fa";
import CalculateMonthModal from "./CalculateMonthModal";
import { showError } from "utils/toast";
import AddRoomMonth from "../RoomMonth/AddRoomMonth/AddRoomMonth";
import AddDataRoom from "../RoomMonth/AddDataRoom/index";
import HistoryRoom from "../RoomDaily/History/HistoryRoom";

const cx = classNames.bind(styles);

// Component hiển thị modal tính gộp cho phòng tháng
const BatchCalculateMonthModal = ({ rooms, onClose, onSuccess }) => {
    const [isSaving, setIsSaving] = useState(false);

    const calculateTotals = (room) => {
        const totalElectricCount = Math.max(0, (room.chisodienmoi || 0) - (room.chisodiencu || 0));
        const totalElectricUsed = totalElectricCount * 4000;

        let totalWaterCount = 0;
        let totalWaterUsed = 0;

        if (room.loainuoc === "chiso") {
            totalWaterCount = Math.max(0, ((room.chisonuoclanhmoi || 0) + (room.chisonuocnongmoi || 0)) - ((room.chisonuoclanhcu || 0) + (room.chisonuocnongcu || 0)));
            totalWaterUsed = totalWaterCount * 20000;
        } else {
            totalWaterUsed = (room.giakhoangnuoc || 0) * (room.songuoikhoang || 0);
        }

        let soNgayO = 0;
        let tienPhongThucTe = room.GiaPhong || 0;

        if (room.NgayLap && room.NgayHetHan) {
            const start = new Date(room.NgayLap);
            const end = new Date(room.NgayHetHan);
            if (end > start) {
                soNgayO = Math.round((end - start) / (1000 * 60 * 60 * 24));
                if (soNgayO > 0 && soNgayO < 30) {
                    tienPhongThucTe = Math.round((room.GiaPhong / 30) * soNgayO);
                } else if (soNgayO >= 30) {
                    tienPhongThucTe = room.GiaPhong;
                }
            }
        }

        const grandTotal = tienPhongThucTe + totalElectricUsed + totalWaterUsed + (room.sinhhoatchung || 0);

        return {
            grandTotal,
            totalElectricCount,
            totalWaterCount,
            totalWaterUsed,
            totalElectricUsed,
            tienPhongThucTe
        };
    };

    const handleSaveAll = async () => {
        if (!window.confirm(`Bạn có chắc muốn thanh toán và lưu dữ liệu cho ${rooms.length} phòng?`)) return;
        setIsSaving(true);
        try {
            for (const room of rooms) {
                const totals = calculateTotals(room);

                await saveRoomHistory(room.SoPhong, {
                    totalAmount: totals.grandTotal,
                    checkInDate: new Date().toISOString(),
                    checkOutDate: new Date().toISOString(),
                    description: `Thanh toán tháng - Phòng ${room.SoPhong}. Điện: ${totals.totalElectricCount}kwh, Nước: ${room.loainuoc === "chiso" ? totals.totalWaterCount + "m3" : "Khoán"}`,
                    waterTotal: 0,
                    waterDetails: "",
                });

                // Update indices (reset new to old)
                await GetUpdateRoom(room._id, {
                    chisodiencu: room.chisodienmoi || 0,
                    chisonuocnongcu: room.chisonuocnongmoi || 0,
                    chisonuoclanhcu: room.chisonuoclanhmoi || 0,
                    chisodienmoi: 0,
                    chisonuocnongmoi: 0,
                    chisonuoclanhmoi: 0
                });
            }
            onSuccess();
            onClose();
        } catch (err) {
            console.error(err);
            showError("Lỗi khi lưu dữ liệu tính tiền gộp");
        } finally {
            setIsSaving(false);
        }
    };

    const grandTotalAll = rooms.reduce((sum, room) => sum + calculateTotals(room).grandTotal, 0);

    return (
        <div style={{ margin: "-24px", overflow: "hidden", borderRadius: "12px", background: "var(--background-color)" }}>
            <div style={{
                background: "linear-gradient(135deg, #667eea, #764ba2)",
                color: "#fff",
                padding: "20px 24px",
                textAlign: "center"
            }}>
                <h3 style={{ margin: "0 0 4px", fontSize: 18, fontWeight: 700 }}>TẠO HÓA ĐƠN GỘP</h3>
                <span style={{ fontSize: 14, opacity: 0.9 }}>{rooms.length} phòng</span>
            </div>

            <div style={{ padding: "16px 24px", maxHeight: "60vh", overflowY: "auto" }}>
                {rooms.map((room, i) => {
                    const totals = calculateTotals(room);
                    return (
                        <div key={i} style={{
                            padding: "12px 16px",
                            marginBottom: 10,
                            borderRadius: 12,
                            border: "1px solid var(--border-color)",
                            background: "var(--background-color)"
                        }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                <strong style={{ fontSize: 15 }}>Phòng {room.SoPhong}</strong>
                                <span style={{ fontSize: 16, fontWeight: 700, color: "#667eea" }}>
                                    {totals.grandTotal.toLocaleString()} VNĐ
                                </span>
                            </div>
                            <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>
                                Điện: {totals.totalElectricCount} kWh - Nước: {room.loainuoc === "chiso" ? totals.totalWaterCount + " m3" : "Khoán"}
                            </div>
                        </div>
                    );
                })}
            </div>

            <div style={{
                padding: "16px 24px",
                borderTop: "2px solid #667eea",
                background: "var(--background-color)",
                borderRadius: "0 0 12px 12px"
            }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                    <span style={{ fontSize: 16, fontWeight: 700 }}>TỔNG CỘNG TẤT CẢ</span>
                    <div style={{ fontSize: 22, fontWeight: 800, color: "#667eea" }}>
                        {grandTotalAll.toLocaleString()} VNĐ
                    </div>
                </div>

                <div style={{ display: "flex", gap: 10 }}>
                    <button
                        onClick={onClose}
                        disabled={isSaving}
                        style={{
                            flex: 1, padding: "12px", borderRadius: 10, border: "1px solid var(--border-color)",
                            background: "var(--surface-color)", fontWeight: 600, cursor: "pointer"
                        }}
                    >
                        Đóng
                    </button>
                    <button
                        onClick={handleSaveAll}
                        disabled={isSaving || rooms.length === 0}
                        style={{
                            flex: 2, padding: "12px", borderRadius: 10, border: "none",
                            background: "linear-gradient(135deg, #10b981, #059669)", color: "#fff",
                            fontWeight: 700, cursor: "pointer", opacity: (isSaving || rooms.length === 0) ? 0.7 : 1
                        }}
                    >
                        {isSaving ? "Đang xử lý..." : "Thanh toán & Lưu"}
                    </button>
                </div>
            </div>
        </div>
    );
};

const RoomMonthList = () => {
    const [rooms, setRooms] = useState([]);
    const [backUpRoom, setBackUpRoom] = useState([]);
    const [selectedRooms, setSelectedRooms] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [activeTab, setActiveTab] = useState(3);
    const { openModal, closeModal } = useModal();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const menuRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setIsMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const loadData = async (currentTab = activeTab) => {
        try {
            const response = await GetAllRoomsMonth();
            if (response && response.data) {
                const sortedRooms = response.data.sort(
                    (a, b) => a.SoPhong - b.SoPhong
                );
                setBackUpRoom(sortedRooms);

                let filtered;
                if (currentTab === 2) {
                    filtered = sortedRooms.filter((item) => !item.GiaPhong);
                } else if (currentTab === 1) {
                    filtered = sortedRooms.filter((item) => item.GiaPhong > 0);
                } else {
                    filtered = sortedRooms;
                }
                setRooms(filtered);
            }
        } catch (error) {
            console.error("Lỗi tải danh sách phòng tháng", error);
        }
    };

    useEffect(() => {
        loadData(activeTab);
    }, []);

    const handleInputChange = async (roomId, data) => {
        try {
            await GetUpdateRoom(roomId, data);
            setBackUpRoom(prev => prev.map(r => r._id === roomId ? { ...r, ...data } : r));
            setRooms(prev => prev.map(r => r._id === roomId ? { ...r, ...data } : r));
        } catch (e) {
            console.error(e);
        }
    };

    const handleCalculate = (room) => {
        openModal(<CalculateMonthModal room={room} onSuccess={() => { closeModal(); loadData(); }} />);
    };

    const handleSelect = (tab) => {
        setActiveTab(tab);
        loadData(tab);
    };

    const handleRoomSelect = (roomId) => {
        setSelectedRooms((prev) =>
            prev.includes(roomId)
                ? prev.filter((r) => r !== roomId)
                : [...prev, roomId]
        );
    };

    const handleBatchCalculate = () => {
        if (selectedRooms.length === 0) return;
        const selectedRoomsData = rooms.filter((r) => selectedRooms.includes(r._id));
        openModal(
            <BatchCalculateMonthModal
                rooms={selectedRoomsData}
                onClose={() => closeModal()}
                onSuccess={() => { closeModal(); loadData(); }}
            />
        );
    };

    const handleSelectAll = () => {
        const occupiedRooms = rooms.filter((r) => r.GiaPhong > 0).map((r) => r._id);
        setSelectedRooms(occupiedRooms);
    };

    const handleDeselectAll = () => {
        setSelectedRooms([]);
    };

    const filteredRooms = rooms.filter(room =>
        room.SoPhong.toString().includes(searchTerm)
    );

    return (
        <>
            <div className={cx("tabs-container")}>
                <div className={cx("tabs")}>
                    <div className={cx("tabs-group")}>
                        <button
                            className={cx("tab-btn", { active: activeTab === 1 })}
                            onClick={() => handleSelect(1)}
                        >
                            Phòng có khách <span className={cx("badge", "occupied")}>{backUpRoom.filter(r => r.GiaPhong > 0).length}</span>
                        </button>
                        <button
                            className={cx("tab-btn", { active: activeTab === 2 })}
                            onClick={() => handleSelect(2)}
                        >
                            Phòng trống <span className={cx("badge", "empty")}>{backUpRoom.filter(r => !r.GiaPhong).length}</span>
                        </button>
                        <button
                            className={cx("tab-btn", { active: activeTab === 3 })}
                            onClick={() => handleSelect(3)}
                        >
                            Tất cả phòng <span className={cx("badge")}>{backUpRoom.length}</span>
                        </button>
                    </div>
                    <div className={cx("tabs-group")}>
                        <div className={cx("search-bar-wrapper")}>
                            <FaSearch className={cx("search-icon")} />
                            <input
                                type="text"
                                placeholder="Tìm số phòng..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className={cx("search-input")}
                            />
                        </div>
                        <div className={cx("toolsMenuContainer")} ref={menuRef}>
                            <button className={cx("toolsBtn")} onClick={() => setIsMenuOpen(!isMenuOpen)}>
                                <FaTools /> Công cụ
                            </button>
                            {isMenuOpen && (
                                <div className={cx("toolsDropdown")}>
                                    <button className={cx("toolMenuItem")} onClick={() => { setIsMenuOpen(false); openModal(<AddRoomMonth list={backUpRoom} onUpdate={loadData} />); }}>
                                        <FaFileContract style={{ color: '#34d399' }} /> Thêm phòng mới (Tạo hợp đồng)
                                    </button>
                                    <button className={cx("toolMenuItem")} onClick={() => { setIsMenuOpen(false); openModal(<AddDataRoom />); }}>
                                        <FaBolt style={{ color: '#fbbf24' }} /> Cập nhật điện nước hàng loạt
                                    </button>
                                    <button className={cx("toolMenuItem")} onClick={() => { setIsMenuOpen(false); openModal(<HistoryRoom />); }}>
                                        <FaChartBar style={{ color: '#a78bfa' }} /> Thống kê / Lịch sử chung
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {selectedRooms.length > 0 && (
                <div className={cx("batchToolbar")}>
                    <span className={cx("batchInfo")}>
                        Đã chọn <strong>{selectedRooms.length}</strong> phòng
                    </span>
                    <button className={cx("batchBtn", "batchCalcBtn")} onClick={handleBatchCalculate}>
                        <FaCalculator style={{ marginRight: 6 }} /> Tạo hóa đơn
                    </button>
                    <button className={cx("batchBtn", "selectAllBtn")} onClick={handleSelectAll}>
                        Chọn tất cả có khách
                    </button>
                    <button className={cx("batchBtn", "deselectAllBtn")} onClick={handleDeselectAll}>
                        Bỏ chọn
                    </button>
                </div>
            )}

            <div className={cx("roomList")}>
                {filteredRooms && filteredRooms.length > 0 ? (
                    filteredRooms.map((room) => (
                        <RoomMonthCard
                            key={room._id}
                            room={room}
                            handleInputChange={handleInputChange}
                            calculate={handleCalculate}
                            isSelected={selectedRooms.includes(room._id)}
                            onSelect={handleRoomSelect}
                            onUpdate={loadData}
                        />
                    ))
                ) : (
                    <span>Hiện tại không tìm thấy phòng</span>
                )}
            </div>
        </>
    );
};

export default RoomMonthList;
