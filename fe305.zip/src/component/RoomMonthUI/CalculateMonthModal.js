import React, { useState, useRef, useEffect } from "react";
import classNames from "classnames/bind";
import styles from "../RoomDaily/CalculateModal/CalculateModal.module.scss";
import { useModal } from "component/Modal/ModalContext";
import { saveRoomHistory, GetUpdateRoom } from "../../api";
import { useNavigate } from "react-router-dom";
import { showSuccess, showError } from "utils/toast";

const cx = classNames.bind(styles);

// Format date to YYYY-MM-DD for input[type=date]
const toInputDate = (d) => {
    const date = new Date(d);
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
};

// Get first day of current month
const firstDayOfMonth = () => {
    const now = new Date();
    return toInputDate(new Date(now.getFullYear(), now.getMonth(), 1));
};

function CalculateMonthModal({ room, onSuccess }) {
    const { closeModal } = useModal();
    const navigate = useNavigate();
    const [depositAmount, setDepositAmount] = useState("");
    const deposit2Ref = useRef(null);

    // Billing mode: "month" = full month, "day" = prorate by days
    const [billingMode, setBillingMode] = useState("month");

    // Milestone date - defaults to 1st of current month
    const [milestoneDate, setMilestoneDate] = useState(firstDayOfMonth());
    const [endDate, setEndDate] = useState(toInputDate(new Date()));

    // Dynamic surcharges list
    const [surcharges, setSurcharges] = useState([{ id: Date.now(), note: "", amount: "" }]);

    // ---------- Calculations ----------
    const totalElectricCount = Math.max(0, (room.chisodienmoi || 0) - (room.chisodiencu || 0));
    const totalElectricUsed = totalElectricCount * 4000;

    let totalWaterCount = 0;
    let totalWaterUsed = 0;

    if (room.loainuoc === "chiso") {
        totalWaterCount = Math.max(
            0,
            ((room.chisonuoclanhmoi || 0) + (room.chisonuocnongmoi || 0)) -
            ((room.chisonuoclanhcu || 0) + (room.chisonuocnongcu || 0))
        );
        totalWaterUsed = totalWaterCount * 20000;
    } else {
        totalWaterUsed = (room.giakhoangnuoc || 0) * (room.songuoikhoang || 0);
    }

    // --- Monthly mode (original logic) ---
    let tienPhong_Monthly = room.GiaPhong || 0;
    let soNgayO_Monthly = 0;
    let isProrated_Monthly = false;

    if (room.NgayLap && room.NgayHetHan) {
        const start = new Date(room.NgayLap);
        const end = new Date(room.NgayHetHan);
        if (end > start) {
            soNgayO_Monthly = Math.round((end - start) / (1000 * 60 * 60 * 24));
            if (soNgayO_Monthly > 0 && soNgayO_Monthly < 30) {
                isProrated_Monthly = true;
                tienPhong_Monthly = Math.round(((room.GiaPhong / 30) * soNgayO_Monthly) / 1000) * 1000;
            }
        }
    }

    // --- Daily mode (from milestone to endDate) ---
    const endMilestone = new Date(endDate);
    endMilestone.setHours(0, 0, 0, 0);
    const startMilestone = new Date(milestoneDate);
    startMilestone.setHours(0, 0, 0, 0);
    const soNgayO_Daily = Math.max(0, Math.round((endMilestone - startMilestone) / (1000 * 60 * 60 * 24)));
    const tienPhong_Daily = Math.ceil((((room.GiaPhong || 0) / 30) * soNgayO_Daily) / 1000) * 1000;

    // --- Active values based on mode ---
    const isDaily = billingMode === "day";
    const tienPhongThucTe = isDaily ? tienPhong_Daily : tienPhong_Monthly;
    const soNgayO = isDaily ? soNgayO_Daily : soNgayO_Monthly;
    const isProrated = isDaily ? true : isProrated_Monthly;

    // --- Sinh hoạt chung: chia theo ngày nếu tính ngày ---
    const sinhHoatFull = room.sinhhoatchung || 0;
    const sinhHoatThucTe = isDaily
        ? Math.ceil(((sinhHoatFull / 30) * soNgayO_Daily) / 1000) * 1000
        : sinhHoatFull;

    const totalSurcharges = surcharges.reduce((acc, curr) => {
        const val = parseInt(String(curr.amount).replace(/[^\d-]/g, ""), 10) || 0;
        return acc + val;
    }, 0);

    const grandTotal = tienPhongThucTe + totalElectricUsed + totalWaterUsed + sinhHoatThucTe + totalSurcharges;

    // ---------- Deposit display ----------
    const handleDepositChange = (e) => {
        const rawValue = e.target.value.replace(/[^\d]/g, "");
        if (!rawValue) { setDepositAmount(""); return; }
        setDepositAmount(parseInt(rawValue, 10).toLocaleString("vi-VN"));
    };

    useEffect(() => {
        if (!deposit2Ref.current) return;
        const depositNumber = parseInt(depositAmount.replace(/[^\d]/g, ""), 10) || 0;
        const diff = depositNumber - grandTotal;
        deposit2Ref.current.innerText = diff < 0 ? "0" : diff.toLocaleString("vi-VN");
    }, [depositAmount, grandTotal]);

    // ---------- Save ----------
    const HandleSaveDatatoHistory = async () => {
        try {
            if (window.confirm("Thanh toán sẽ làm tròn chỉ số Điện/Nước cũ bằng chỉ số mới và lưu vào lịch sử. Tiếp tục?")) {
                const modeLabel = isDaily ? `Tính theo ngày (${soNgayO} ngày từ ${milestoneDate} đến ${endDate})` : "Tính theo tháng";

                const validSurcharges = surcharges.filter(s => parseInt(String(s.amount).replace(/[^\d-]/g, ""), 10));
                const surchargeTexts = validSurcharges.map(s => `[${s.note || "Khác"}: ${parseInt(String(s.amount).replace(/[^\d-]/g, ""), 10).toLocaleString("vi-VN")}đ]`).join(", ");

                await saveRoomHistory(room.SoPhong, {
                    totalAmount: grandTotal,
                    checkInDate: new Date().toISOString(),
                    checkOutDate: new Date().toISOString(),
                    description: `Thanh toán tháng [${modeLabel}] - Phòng ${room.SoPhong}. Điện: ${totalElectricCount}kwh, Nước: ${room.loainuoc === "chiso" ? totalWaterCount + "m3" : "Khoán"}${surchargeTexts ? `. Phụ phí: ${surchargeTexts}` : ""}`,
                    waterTotal: 0,
                    waterDetails: "",
                });
                await GetUpdateRoom(room._id, {
                    chisodiencu: room.chisodienmoi || 0,
                    chisonuocnongcu: room.chisonuocnongmoi || 0,
                    chisonuoclanhcu: room.chisonuoclanhmoi || 0,
                    chisodienmoi: 0,
                    chisonuocnongmoi: 0,
                    chisonuoclanhmoi: 0
                });
                showSuccess("Thanh toán thành công!");
                if (onSuccess) onSuccess();
            }
        } catch (e) {
            showError("Lỗi khi thanh toán!");
            console.error(e);
        }
    };

    // ── Create Bill: build URL params and navigate to /hoa-don-thang ──────────
    const handleCreateBill = () => {
        const p = new URLSearchParams({
            room: room.SoPhong,
            ten: room.hovaten || "",
            mode: billingMode,
            milestone: milestoneDate,
            endDate: endDate,
            ngay: soNgayO,
            giaPhong: room.GiaPhong || 0,
            tienPhong: tienPhongThucTe,
            tienDien: totalElectricUsed,
            tienNuoc: totalWaterUsed,
            sinhHoat: sinhHoatThucTe,
            tongCong: grandTotal,
            csoDienCu: room.chisodiencu || 0,
            csoDienMoi: room.chisodienmoi || 0,
            csoNuocCu: (room.chisonuoclanhcu || 0) + (room.chisonuocnongcu || 0),
            csoNuocMoi: (room.chisonuoclanhmoi || 0) + (room.chisonuocnongmoi || 0),
            loaiNuoc: room.loainuoc || "chiso",
            soNguoi: room.songuoikhoang || 0,
            giaKhoan: room.giakhoangnuoc || 0,
            surcharges: JSON.stringify(surcharges.filter(s => parseInt(String(s.amount).replace(/[^\d-]/g, ""), 10))),
        });
        closeModal();
        navigate(`/hoa-don-thang?${p.toString()}`);
    };

    return (
        <>
            <div className={cx("invoice")}>
                {/* ===== HEADER ===== */}
                <div className={cx("invoice-header")}>
                    <div className={cx("invoice-title-group")}>
                        <h3 className={cx("invoice-title")}>HÓA ĐƠN THUÊ THÁNG</h3>
                        <span className={cx("invoice-room")}>Phòng {room.SoPhong}</span>
                    </div>

                    {/* Billing mode toggle */}
                    <div style={{ display: "flex", alignItems: "center", gap: 8, background: "rgba(255,255,255,0.08)", borderRadius: 10, padding: "6px 10px" }}>
                        <button
                            onClick={() => setBillingMode("month")}
                            style={{
                                padding: "6px 14px", borderRadius: 8, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 13,
                                background: !isDaily ? "#667eea" : "transparent",
                                color: !isDaily ? "#fff" : "rgba(255,255,255,0.6)",
                                transition: "all 0.2s"
                            }}
                        >
                            Theo tháng
                        </button>
                        <button
                            onClick={() => setBillingMode("day")}
                            style={{
                                padding: "6px 14px", borderRadius: 8, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 13,
                                background: isDaily ? "#f59e0b" : "transparent",
                                color: isDaily ? "#fff" : "rgba(255,255,255,0.6)",
                                transition: "all 0.2s"
                            }}
                        >
                            Theo ngày
                        </button>
                    </div>

                    <div className={cx("header-actions")}>
                        <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
                            <i className="fas fa-times"></i>
                        </button>
                    </div>
                </div>

                {/* Daily mode: milestone date picker */}
                {isDaily && (
                    <div style={{
                        background: "#fffbeb", borderBottom: "2px solid #fde68a",
                        padding: "12px 24px", display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap"
                    }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                            <span style={{ fontWeight: 700, fontSize: 13, color: "#92400e" }}>
                                📅 Từ ngày:
                            </span>
                            <input
                                type="date"
                                value={milestoneDate}
                                onChange={e => setMilestoneDate(e.target.value)}
                                style={{
                                    padding: "6px 12px", borderRadius: 8, border: "1px solid #fcd34d",
                                    fontSize: 13, fontWeight: 600, color: "#92400e", background: "#fff", cursor: "pointer"
                                }}
                            />
                        </div>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                            <span style={{ fontWeight: 700, fontSize: 13, color: "#92400e" }}>
                                Đến ngày:
                            </span>
                            <input
                                type="date"
                                value={endDate}
                                onChange={e => setEndDate(e.target.value)}
                                style={{
                                    padding: "6px 12px", borderRadius: 8, border: "1px solid #fcd34d",
                                    fontSize: 13, fontWeight: 600, color: "#92400e", background: "#fff", cursor: "pointer"
                                }}
                            />
                        </div>
                        <span style={{ fontSize: 13, color: "#78350f", background: "#fef3c7", padding: "4px 12px", borderRadius: 20, fontWeight: 600 }}>
                            Số ngày đã ở: <strong>{soNgayO_Daily} ngày</strong>
                        </span>
                        <span style={{ fontSize: 13, color: "#b45309", fontStyle: "italic" }}>
                            ({room.GiaPhong?.toLocaleString()} ÷ 30 × {soNgayO_Daily} = {tienPhong_Daily.toLocaleString()} đ)
                        </span>
                    </div>
                )}

                {/* ===== BODY 3-COL ===== */}
                <div className={cx("invoice-body", { "grid-3": true })}>

                    {/* Column 1: Meters + Payment */}
                    <div className={cx("invoice-col")}>
                        <div className={cx("section-title")}>Chỉ số tiêu thụ</div>
                        <div className={cx("invoice-section")}>
                            <div className={cx("time-card")} style={{ marginBottom: 10 }}>
                                <div className={cx("time-label")}>
                                    <i className="fas fa-plug" style={{ color: "#eab308" }}></i> Điện ({totalElectricCount} kWh)
                                </div>
                                <div className={cx("time-value")} style={{ fontSize: 13, marginTop: 4 }}>
                                    Cũ: {room.chisodiencu || 0} → Mới: {room.chisodienmoi || 0}
                                </div>
                            </div>
                            <div className={cx("time-card")}>
                                <div className={cx("time-label")}>
                                    <i className="fas fa-tint" style={{ color: "#3b82f6" }}></i> Nước {room.loainuoc === "chiso" ? `(${totalWaterCount} m3)` : "(Khoán)"}
                                </div>
                                {room.loainuoc === "chiso" ? (
                                    <div className={cx("time-value")} style={{ fontSize: 13, marginTop: 4 }}>
                                        <div>Nóng: {room.chisonuocnongcu || 0} → {room.chisonuocnongmoi || 0}</div>
                                        <div>Lạnh: {room.chisonuoclanhcu || 0} → {room.chisonuoclanhmoi || 0}</div>
                                    </div>
                                ) : (
                                    <div className={cx("time-value")} style={{ fontSize: 13, marginTop: 4 }}>Số người: {room.songuoikhoang || 0}</div>
                                )}
                            </div>
                        </div>

                        <div className={cx("section-title")}>Thanh toán nộp</div>
                        <div className={cx("invoice-section", "payment-section")}>
                            <div className={cx("payment-row")}>
                                <label>Khách đưa:</label>
                                <input type="text" value={depositAmount} onChange={handleDepositChange} placeholder="Nhập số tiền" />
                            </div>
                            <div className={cx("payment-row", "change-row")}>
                                <span>Tiền thối lại:</span>
                                <b ref={deposit2Ref}>0</b>
                            </div>
                        </div>
                    </div>

                    {/* Column 2: Cost detail */}
                    <div className={cx("invoice-col")}>
                        <div className={cx("section-title")}>Chi tiết chi phí</div>
                        <div className={cx("invoice-section")}>
                            <div className={cx("invoice-row", "detail")}>
                                <span>
                                    Tiền phòng {isDaily
                                        ? <small style={{ color: "#f59e0b", display: "block" }}>({soNgayO} ngày)</small>
                                        : isProrated
                                            ? <small style={{ color: "#64748b", display: "block" }}>({soNgayO} ngày)</small>
                                            : null
                                    }
                                </span>
                                <span style={{ fontWeight: 700, color: isDaily ? "#f59e0b" : "#0f172a" }}>
                                    {tienPhongThucTe.toLocaleString()} đ
                                </span>
                            </div>
                            <div className={cx("invoice-row", "detail")}>
                                <span>Sinh hoạt chung</span>
                                <span>{(room.sinhhoatchung || 0).toLocaleString()} đ</span>
                            </div>
                            <div className={cx("invoice-row", "detail")}>
                                <span>Tiền điện</span>
                                <span>{totalElectricUsed.toLocaleString()} đ</span>
                            </div>
                            <div className={cx("invoice-row", "detail")}>
                                <span>Tiền nước</span>
                                <span>{totalWaterUsed.toLocaleString()} đ</span>
                            </div>
                            {/* Dynamic Surcharges List */}
                            <div style={{ marginTop: 12, paddingTop: 12, borderTop: "2px dashed #f1f5f9" }}>
                                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                                    <span style={{ fontWeight: 700, fontSize: 13, color: "#64748b" }}>CÁC KHOẢN THU/TRỪ KHÁC</span>
                                    <button
                                        onClick={() => setSurcharges([...surcharges, { id: Date.now(), note: "", amount: "" }])}
                                        style={{ background: "#dbeafe", color: "#2563eb", border: "none", borderRadius: 6, padding: "6px 12px", fontSize: 12, fontWeight: 700, cursor: "pointer" }}
                                    >
                                        <i className="fas fa-plus"></i> Thêm mục
                                    </button>
                                </div>
                                {surcharges.map(s => (
                                    <div key={s.id} style={{ display: "flex", gap: 8, marginBottom: 8, alignItems: "center" }}>
                                        <input
                                            type="text"
                                            placeholder="Nội dung: Phí rác, Giảm giá..."
                                            value={s.note}
                                            onChange={(e) => setSurcharges(surcharges.map(item => item.id === s.id ? { ...item, note: e.target.value } : item))}
                                            style={{ flex: 1, border: "1px solid #e2e8f0", borderRadius: 8, padding: "8px 12px", fontSize: 13, background: "#f8fafc", color: "#1e293b", outline: "none" }}
                                        />
                                        <input
                                            type="number"
                                            placeholder="± Số tiền"
                                            value={s.amount}
                                            onChange={(e) => setSurcharges(surcharges.map(item => item.id === s.id ? { ...item, amount: e.target.value } : item))}
                                            style={{ width: 100, border: "1px solid #e2e8f0", borderRadius: 8, padding: "8px 12px", fontSize: 13, background: "#f8fafc", color: "#1e293b", textAlign: "right", outline: "none" }}
                                        />
                                        {surcharges.length > 1 && (
                                            <button
                                                onClick={() => setSurcharges(surcharges.filter(item => item.id !== s.id))}
                                                style={{ background: "transparent", border: "none", color: "#ef4444", padding: "6px", cursor: "pointer", fontSize: 16 }}
                                            >
                                                <i className="fas fa-times-circle"></i>
                                            </button>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Column 3: Total + Actions */}
                    <div className={cx("invoice-col")}>
                        <div className={cx("section-title")}>Tổng Kết</div>

                        {/* Mode badge */}
                        <div style={{ textAlign: "center", marginBottom: 8 }}>
                            <span style={{
                                display: "inline-block", padding: "4px 14px", borderRadius: 20, fontSize: 12, fontWeight: 700,
                                background: isDaily ? "#fef3c7" : "#ede9fe",
                                color: isDaily ? "#92400e" : "#5b21b6"
                            }}>
                                {isDaily ? `📅 Tính theo ngày (${soNgayO} ngày)` : "📆 Tính theo tháng"}
                            </span>
                        </div>

                        <div className={cx("invoice-total-box")} style={{ marginTop: 8, background: isDaily ? "linear-gradient(135deg, #f59e0b, #d97706)" : undefined }}>
                            <div className={cx("total-label")}>TỔNG CỘNG</div>
                            <div className={cx("total-amount")}>{grandTotal.toLocaleString()} VNĐ</div>
                        </div>

                        <div className={cx("invoice-actions-vertical")} style={{ marginTop: 24 }}>
                            <button
                                onClick={handleCreateBill}
                                style={{
                                    width: "100%", padding: "12px", borderRadius: 8, border: "none",
                                    background: "linear-gradient(135deg, #1e293b, #0f172a)",
                                    color: "#93c5fd", fontWeight: 700, fontSize: 13, cursor: "pointer",
                                    display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 6
                                }}
                            >
                                🧾 Tạo Bill &amp; Xem Hóa Đơn
                            </button>
                            <button className={cx("btn", "btn-save")} onClick={HandleSaveDatatoHistory}>
                                <i className="fas fa-check-circle"></i> Thanh toán &amp; Lưu
                            </button>
                            <button className={cx("btn", "btn-temp")} onClick={closeModal}>
                                <i className="fas fa-times"></i> Đóng
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </>
    );
}

export default CalculateMonthModal;
