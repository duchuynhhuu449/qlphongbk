import React from 'react';
import styles from './QRModal.module.scss';
import classNames from 'classnames/bind';
import { publicImages } from '../../assets';

const cx = classNames.bind(styles);

const QRModal = ({ isOpen, onClose, data }) => {
  if (!isOpen) return null;

  const { roomNumber, checkIn, checkOut, waterUsage, amount } = data;
  console.log(checkIn.split(" ")[0])
  
  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(':');
    return `${hours}h${minutes}phút`;
  };

  // Tạo URL cho mã QR với thông tincheckIn.split(" ")[0].split(" ")
  const content = `P${roomNumber}Vao:${formatTime(checkIn.split(" ")[0])}${checkIn.split(" ")[1]}Ra:${formatTime(checkOut.split(" ")[0])}${checkOut.split(" ")[1]}}`
  const qrUrl = `${publicImages.nganhang}?amount=${amount}&addInfo=${content}`;

  return (
    <div className={cx('overlay')} onClick={onClose}>
      <div className={cx('modal-wrapper')} onClick={e => e.stopPropagation()}>
        <div className={cx('modal-content')}>
          <h2 className={cx('modal-title')}>Mã QR Thanh Toán</h2>
          
          <div className={cx('info-section')}>
            <div className={cx('info-item')}>
              <span className={cx('label')}>Phòng:</span>
              <span className={cx('value')}>{roomNumber}</span>
            </div>
            <div className={cx('info-item')}>
              <span className={cx('value')}>Mã qr liên kết tài khoản Cô trâm</span>
            </div>
          </div>

          <div className={cx('qr-section')}>
            <img src={qrUrl} alt="QR Code" className={cx('qr-image')} />
            <p className={cx('qr-note')}>Quét mã QR để thanh toán</p>
          </div>

          <button className={cx('close-button')} onClick={onClose}>
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};

export default QRModal; 