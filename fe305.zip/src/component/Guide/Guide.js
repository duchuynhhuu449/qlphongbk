import React, { useState, useEffect } from "react";
import styles from "./Guide.module.scss";
import { useModal } from "../Modal/ModalContext";
import classNames from "classnames/bind";
import { useTheme } from "../../context/ThemeContext";

const cx = classNames.bind(styles);

const themes = {
  basic: {
    name: "Cơ bản",
    description: "Giao diện đơn giản, dễ sử dụng cho người mới",
    preview: {
      primary: "#1a365d",
      secondary: "#c4a777",
      background: "#ffffff",
    },
  },
  premium: {
    name: "Thượng hạng",
    description: "Giao diện sang trọng với hiệu ứng nâng cao",
    preview: {
      primary: "#2c5282",
      secondary: "#d4af37",
      background: "#faf9f6",
    },
  },
  luxury: {
    name: "Thượng hạng",
    description: "Giao diện đẳng cấp với phối màu tinh tế",
    preview: {
      primary: "#1a202c",
      secondary: "#c4a777",
      background: "#f8f6f1",
    },
  },
  dark: {
    name: "Tối",
    description: "Giao diện tối giúp giảm mỏi mắt khi làm việc lâu",
    preview: {
      primary: "#2d3748",
      secondary: "#c4a777",
      background: "#1a202c",
    },
  },
};

const sections = {
  overview: {
    title: "Tổng Quan",
    icon: "📋",
    content: (
      <div className={cx("section-content")}>
        <h3>Chào mừng đến với Hệ thống Quản Lý Khách Sạn HataHomeSTay</h3>
        <p>
          Hệ thống này giúp bạn quản lý và theo dõi công việc nội bộ hiệu quả.
        </p>
        <ul>
          <li>Theo dõi số lượng nước tồn kho</li>
          <li>Tính năng tính tiền ngày</li>
          <li>Tính năng tạo hợp đồng phòng nhanh gọn</li>
          <li>Tính năng tính tiền tháng phòng / điện / nước nhanh chóng</li>
          <li>Kiểm tra lịch sử giao dịch</li>
        </ul>
      </div>
    ),
  },
  inventory: {
    title: "Quản lý nước",
    icon: "📦",
    content: (
      <div className={cx("section-content")}>
        <h3>Hướng dẫn Quản lý Kho</h3>
        <p>Phần này giúp bạn theo dõi và quản lý kho nước:</p>
        <ul>
          <li>Kiểm tra số lượng tồn kho</li>
          <li>Nhập thêm nước mới</li>
          <li>Cập nhật số lượng bán</li>
        </ul>
      </div>
    ),
  },
  sales: {
    title: "Tính tiền ngày",
    icon: "💰",
    content: (
      <div className={cx('section-content')}>
  <h3>Hướng dẫn tính tiền theo ngày và giờ</h3>
  <p>Các tính năng hỗ trợ quản lý bán phòng hiệu quả:</p>
  <ul>
    <li>Tự động ghi nhận thời gian nhận phòng khi nhấn "Nhận phòng"</li>
    <li>Tự động ghi nhận thời gian trả phòng khi nhấn "Trả phòng"</li>
    <li>Ghi nhớ số lượng nước khách đã dùng cho từng phòng và tự động cộng vào hóa đơn</li>
    <li>
      Tự động tính tiền theo công thức:
      <div style={{ marginTop: 8 }}>
        <strong>Trường hợp 1: Tính theo giờ (ở ngắn hạn)</strong>
        <p>
          Tổng = G₁ + S × G<sub>phụ</sub>
        </p>
        <p>
          Trong đó:
          <br />
          G₁: Giá giờ đầu tiên
          <br />
          S = ⌊(T − 60 + 45) / 60⌋, nếu T &gt; 60 phút
        </p>
      </div>

      <div style={{ marginTop: 12 }}>
        <strong>Trường hợp 2: Tính theo ngày (ở qua đêm)</strong>
        <p>
          Nếu nhận phòng từ 05:00 đến 12:00:
          <br />
          → Phụ thu nhận sớm: P<sub>ns</sub> = (12 − h<sub>bđ</sub>) × G<sub>phụ</sub>
        </p>
        <p>
          Số ngày lưu trú:
          <br />
          S<sub>ngày</sub> = ⌈(trưa ngày trả − trưa ngày nhận) / 1 ngày⌉ + 1
        </p>
        <p>
          Tiền ở chính: T<sub>ở</sub> = S<sub>ngày</sub> × G<sub>ngày</sub>
        </p>
        <p>
          Nếu trả phòng sau 12:00:
          <br />
          → Phụ thu trả muộn: P<sub>tm</sub> = (h<sub>kết</sub> − 12) × G<sub>phụ</sub>
        </p>
        <p>
          <strong>Tổng = T<sub>ở</sub> + P<sub>ns</sub> + P<sub>tm</sub></strong>
        </p>
      </div>
    </li>
    <li>Cho phép tra cứu lịch sử giao dịch của từng phòng dễ dàng</li>
    <li>Hỗ trợ tính tiền qua Chatbot Telegram theo lệnh người dùng</li>
  </ul>
</div>

    ),
  },
  sales_month: {
    title: "Tính tiền tháng",
    icon: "💰",
    content: (
      <>
        <div className={cx("section-content")}>
  <h3>Thông tin tháng</h3>

  <p>
    Hệ thống hỗ trợ tự động chốt điện nước hàng loạt cho tất cả các phòng thông qua bot Telegram.
    Khi quản lý gửi chỉ số điện và nước mới từ Telegram, hệ thống sẽ xử lý và tính hóa đơn theo công thức toán học sau:
  </p>

  <p><strong>1. Công thức tính toán:</strong></p>
  <ul>
    <li><strong>Điện tiêu thụ:</strong> D = Chỉ số điện mới - Chỉ số điện cũ (nếu âm thì lấy 0)</li>
    <li><strong>Nước tiêu thụ:</strong> N = (Nước lạnh mới - Nước lạnh cũ) + (Nước nóng mới - Nước nóng cũ) (nếu âm thì lấy 0)</li>
    <li><strong>Tiền điện:</strong> C_điện = D × 4.000 VND</li>
    <li><strong>Tiền nước:</strong> C_nước = N × 20.000 VND</li>
    <li><strong>Tổng hóa đơn:</strong> Tổng = C_điện + C_nước + Phí sinh hoạt chung + Giá phòng</li>
  </ul>

  <p><strong>2. Tự động chốt điện nước qua Telegram:</strong></p>
  <ul>
    <li>Quản lý chỉ cần gửi chỉ số điện, nước mới của từng phòng theo mẫu định sẵn qua bot Telegram.</li>
    <li>Hệ thống sẽ tự động truy xuất chỉ số cũ từ cơ sở dữ liệu.</li>
    <li>Các công thức trên sẽ được áp dụng để tính toán hóa đơn từng phòng.</li>
    <li>Bot Telegram tự động phản hồi hóa đơn chi tiết gồm:
      <ul>
        <li>Số điện, số nước tiêu thụ</li>
        <li>Tiền điện, tiền nước</li>
        <li>Phí sinh hoạt chung</li>
        <li>Tiền phòng</li>
        <li>Tổng thanh toán</li>
      </ul>
    </li>
    <li>Toàn bộ quy trình được xử lý tự động, không cần đăng nhập giao diện quản trị.</li>
  </ul>
  <div className={cx("developer-info")}>
    <p>Nhà phát triển: Hữu Đức</p>
    <p>Ngày xây dựng: 01/03/2025</p>
  </div>
</div>

      </>

    ),
  },
  developer: {
    title: "Nhà Phát Triển",
    icon: "👨‍💻",
    content: (
      <div className={cx("section-content")}>
        <h3>Thông Tin Phát Triển</h3>
        <ul>
          <li>Ứng dụng đang trong quá trình phát triển chưa hoàn thiện</li>
        </ul>
        <div className={cx("developer-info")}>
          <p>Nhà phát triển: Hữu Đức</p>
          <p>Ngày xây dựng: 01/03/2025</p>
        </div>
      </div>
    ),
  },
};

const GuideContent = () => {
  const [activeSection, setActiveSection] = useState("overview");

  return (
    <div className={cx("guide-container")}>
      <div className={cx("guide-sidebar")}>
        <h2 className={cx("guide-title")}>Hướng dẫn sử dụng</h2>
        <ul className={cx("guide-list")}>
          {Object.entries(sections).map(([key, section]) => (
            <li
              key={key}
              className={cx("guide-item", { active: activeSection === key })}
              onClick={() => setActiveSection(key)}
            >
              <span className={cx("guide-icon")}>{section.icon}</span>
              <span>{section.title}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className={cx("guide-content")}>
        <h2 className={cx("content-title")}>{sections[activeSection].title}</h2>
        {sections[activeSection].content}
      </div>
    </div>
  );
};

const Guide = () => {
  const { openModal } = useModal();
  const { theme, toggleTheme } = useTheme();
  const [showThemeModal, setShowThemeModal] = useState(false);

  React.useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (!savedTheme) {
      setShowThemeModal(true);
    }
  }, []);

  const handleOpenGuide = () => {
    openModal(() => <GuideContent />);
  };

  return (
    <>
      <button className={cx('guide-button')} onClick={handleOpenGuide}>
        <i className="fas fa-book"></i> Hướng dẫn
      </button>
    </>
  );
};

export default Guide;
