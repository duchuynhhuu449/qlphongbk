export function convertNumberToVietnameseText(number) {
    const ChuSo = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"];
  
    function docSo3ChuSo(baso) {
      let tram = Math.floor(baso / 100);
      let chuc = Math.floor((baso % 100) / 10);
      let donvi = baso % 10;
      let ketQua = "";
  
      if (tram !== 0) {
        ketQua += ChuSo[tram] + " trăm ";
        if (chuc === 0 && donvi !== 0) ketQua += "lẻ ";
      }
  
      if (chuc !== 0 && chuc !== 1) {
        ketQua += ChuSo[chuc] + " mươi ";
        if (donvi === 1) ketQua += "mốt ";
        else if (donvi === 5) ketQua += "lăm ";
        else if (donvi !== 0) ketQua += ChuSo[donvi] + " ";
      } else if (chuc === 1) {
        ketQua += "mười ";
        if (donvi === 1) ketQua += "mốt ";
        else if (donvi === 5) ketQua += "lăm ";
        else if (donvi !== 0) ketQua += ChuSo[donvi] + " ";
      } else if (chuc === 0 && donvi !== 0) {
        ketQua += ChuSo[donvi] + " ";
      }
  
      return ketQua.trim();
    }
  
    function toVietnamese(number) {
      if (number === 0) return "không đồng";
  
      let so = number.toString().split("").reverse().join("");
      let arr = [];
      for (let i = 0; i < so.length; i += 3) {
        arr.push(so.substring(i, i + 3).split("").reverse().join(""));
      }
  
      let chu = "";
      let donvi = ["", " nghìn", " triệu", " tỷ", " nghìn tỷ", " triệu tỷ"];
      for (let i = arr.length - 1; i >= 0; i--) {
        let n = parseInt(arr[i]);
        if (n !== 0) {
          chu += docSo3ChuSo(n) + donvi[i] + " ";
        }
      }
  
      return chu.trim() + " đồng";
    }
  
    return toVietnamese(number);
  }
