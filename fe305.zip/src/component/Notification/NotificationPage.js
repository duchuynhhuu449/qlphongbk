import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './NotificationPage.module.scss';
import { getSystemNotifications } from '../../api';
import { useModal } from '../Modal/ModalContext';

const cx = classNames.bind(styles);

export default function NotificationPage() {
    const [activeTab, setActiveTab] = useState('debts');
    const [data, setData] = useState({ debts: [], expiringRooms: [] });
    const [loading, setLoading] = useState(true);
    const { openModal, closeModal } = useModal();

    const handleOpenDebtDetail = (debt) => {
        const diffDays = Math.ceil((new Date(debt.dueDate) - new Date()) / (1000 * 3600 * 24));
        const isOverdue = diffDays < 0;
        openModal(
            <div className={cx('detail-modal')}>
                <div className={cx('modal-header')}>
                    <div className={cx('icon-wrapper', { danger: isOverdue, warning: !isOverdue })}><i className="fas fa-file-invoice-dollar"></i></div>
                    <h3>Chi Tiết Nhắc Nợ</h3>
                </div>
                <div className={cx('modal-body')}>
                    <div className={cx('info-row')}>
                        <span>Số tiền nợ:</span>
                        <strong className={cx('amount')}>{debt.amount.toLocaleString('vi-VN')} đ</strong>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Hạn thanh toán:</span>
                        <strong className={cx({ 'text-danger': isOverdue })}>{new Date(debt.dueDate).toLocaleDateString('vi-VN')}</strong>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Tình trạng:</span>
                        <strong className={cx({ 'text-danger': isOverdue, 'text-warning': !isOverdue })}>
                            {isOverdue ? `Quá hạn ${Math.abs(diffDays)} ngày` : `Còn ${diffDays} ngày`}
                        </strong>
                    </div>
                    <div className={cx('info-box')}>
                        <span className={cx('box-title')}>Ghi chú:</span>
                        <p>{debt.note || 'Không có ghi chú'}</p>
                    </div>
                </div>
                <div className={cx('modal-footer')}>
                    <button className={cx('btn-cancel')} onClick={() => closeModal()}>Đóng</button>
                </div>
            </div>
        );
    };

    const handleOpenRoomDetail = (room) => {
        const diffDays = Math.ceil((new Date(room.NgayHetHan) - new Date()) / (1000 * 3600 * 24));
        const isOverdue = diffDays < 0;
        openModal(
            <div className={cx('detail-modal')}>
                <div className={cx('modal-header')}>
                    <div className={cx('icon-wrapper', 'room-icon')}><i className="fas fa-home"></i></div>
                    <h3>Thông Tin Phòng {room.SoPhong}</h3>
                </div>
                <div className={cx('modal-body')}>
                    <div className={cx('info-row')}>
                        <span>Trạng thái:</span>
                        <span className={cx('status-badge', isOverdue ? 'pending' : 'paid')}>
                            {isOverdue ? `Hết hạn hợp đồng` : `Sắp đến hạn`}
                        </span>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Giá phòng thu:</span>
                        <strong>{room.GiaPhong ? room.GiaPhong.toLocaleString('vi-VN') + ' đ' : 'Thỏa thuận'}</strong>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Ngày lập hợp đồng:</span>
                        <strong>{new Date(room.NgayLap).toLocaleDateString('vi-VN')}</strong>
                    </div>
                    <div className={cx('info-row')}>
                        <span>Ngày hết hạn:</span>
                        <strong className={cx({ 'text-danger': isOverdue })}>{new Date(room.NgayHetHan).toLocaleDateString('vi-VN')}</strong>
                    </div>
                </div>
                <div className={cx('modal-footer')}>
                    <button className={cx('btn-cancel')} onClick={() => closeModal()}>Đóng</button>
                </div>
            </div>
        );
    };

    useEffect(() => {
        const loadNotifications = async () => {
            try {
                const res = await getSystemNotifications();
                if (res && res.debts) {
                    setData(res);
                }
            } catch (error) {
                console.error('Lỗi tải thông báo', error);
            } finally {
                setLoading(false);
            }
        };
        loadNotifications();
    }, []);

    const renderDebtsTab = () => {
        if (data.debts.length === 0) return <p className={cx('empty')}>Không có nợ sắp đến hạn.</p>;

        return (
            <div className={cx('tab-content-list')}>
                {data.debts.map(d => {
                    const diffDays = Math.ceil((new Date(d.dueDate) - new Date()) / (1000 * 3600 * 24));
                    const isOverdue = diffDays < 0;

                    return (
                        <div key={d._id} className={cx('noti-card', isOverdue ? 'danger' : 'warning')} onClick={() => handleOpenDebtDetail(d)}>
                            <div className={cx('card-left')}>
                                <div className={cx('icon-container')}>
                                    <i className={`fas fa-bell`}></i>
                                </div>
                                <div className={cx('card-info')}>
                                    <h4>{d.note || 'Không có ghi chú'}</h4>
                                    <p className={cx('amount')}>{d.amount.toLocaleString('vi-VN')} đ</p>
                                </div>
                            </div>
                            <div className={cx('card-right')}>
                                <span className={cx('badge')}>
                                    {isOverdue ? `Quá hạn ${Math.abs(diffDays)} ngày` : `Còn ${diffDays} ngày`}
                                </span>
                                <span className={cx('date')}><i className="far fa-calendar-alt"></i> {new Date(d.dueDate).toLocaleDateString('vi-VN')}</span>
                            </div>
                        </div>
                    );
                })}
            </div>
        );
    };

    const renderExpiringRoomsTab = () => {
        if (data.expiringRooms.length === 0) return <p className={cx('empty')}>Không có phòng sắp hết hạn.</p>;

        return (
            <div className={cx('tab-content-list')}>
                {data.expiringRooms.map(r => {
                    const diffDays = Math.ceil((new Date(r.NgayHetHan) - new Date()) / (1000 * 3600 * 24));
                    const isOverdue = diffDays < 0;

                    return (
                        <div key={r._id} className={cx('noti-card', isOverdue ? 'danger' : 'warning')} onClick={() => handleOpenRoomDetail(r)}>
                            <div className={cx('card-left')}>
                                <div className={cx('icon-container', 'room')}>
                                    <i className={`fas fa-home`}></i>
                                </div>
                                <div className={cx('card-info')}>
                                    <h4>Phòng {r.SoPhong}</h4>
                                    <p>Hợp đồng {new Date(r.NgayLap).toLocaleDateString('vi-VN')} - {new Date(r.NgayHetHan).toLocaleDateString('vi-VN')}</p>
                                </div>
                            </div>
                            <div className={cx('card-right')}>
                                <span className={cx('badge')}>
                                    {isOverdue ? `Quá hạn ${Math.abs(diffDays)} ngày` : `Còn ${diffDays} ngày`}
                                </span>
                            </div>
                        </div>
                    );
                })}
            </div>
        );
    };

    return (
        <div className={cx('notification-page')}>
            <div className={cx('header')}>
                <h2>Thông Báo Hệ Thống</h2>
            </div>

            <div className={cx('tabs')}>
                <button
                    className={cx('tab-btn', { active: activeTab === 'debts' })}
                    onClick={() => setActiveTab('debts')}
                >
                    Nhắc Nợ
                    {data.debts.length > 0 && <span className={cx('counter')}>{data.debts.length}</span>}
                </button>
                <button
                    className={cx('tab-btn', { active: activeTab === 'rooms' })}
                    onClick={() => setActiveTab('rooms')}
                >
                    Hợp đồng sắp hết
                    {data.expiringRooms.length > 0 && <span className={cx('counter')}>{data.expiringRooms.length}</span>}
                </button>
            </div>

            <div className={cx('tab-content')}>
                {loading ? <div className={cx('loading')}><div className={cx('spinner')}></div></div> : (
                    activeTab === 'debts' ? renderDebtsTab() : renderExpiringRoomsTab()
                )}
            </div>
        </div>
    );
}
