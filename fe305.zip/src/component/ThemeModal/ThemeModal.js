import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import styles from './ThemeModal.module.scss';
import classNames from 'classnames/bind';

const cx = classNames.bind(styles);

const ThemeModal = ({ isOpen, onClose }) => {
  const { theme, themes, toggleTheme } = useTheme();
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleThemeSelect = async (themeId) => {
    if (themeId === theme) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000)); // 2 seconds delay
    toggleTheme(themeId);
    setIsLoading(false);
    onClose();
  };

  return (
    <>
      <div className={cx('overlay')} onClick={onClose}>
        <div className={cx('modal-wrapper')} onClick={e => e.stopPropagation()}>
          <div className={cx('modal-content')}>
            <h2 className={cx('modal-title')}>Chọn giao diện</h2>
            <div className={cx('theme-grid')}>
              {Object.values(themes).map((themeOption) => (
                <div
                  key={themeOption.id}
                  className={cx('theme-option', {
                    'theme-option--active': theme === themeOption.id
                  })}
                  onClick={() => handleThemeSelect(themeOption.id)}
                >
                  <div 
                    className={cx('theme-preview')}
                    data-theme={themeOption.id}
                  >
                    <div className={cx('preview-header')}></div>
                    <div className={cx('preview-content')}>
                      <div className={cx('preview-text')}></div>
                      <div className={cx('preview-text')}></div>
                    </div>
                  </div>
                  <div className={cx('theme-info')}>
                    <h3 className={cx('theme-name')}>{themeOption.name}</h3>
                    <p className={cx('theme-description')}>{themeOption.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      {isLoading && (
        <div className={cx('loading-overlay')}>
          <div className={cx('loading-spinner')}></div>
        </div>
      )}
    </>
  );
};

export default ThemeModal; 