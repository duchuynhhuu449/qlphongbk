import React from 'react';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useTheme } from '../../context/ThemeContext';
import './toast-custom.css';

const ToastProvider = ({ children }) => {
    const { theme } = useTheme();

    return (
        <>
            {children}
            <ToastContainer
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={true}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme={theme === 'dark' || theme === 'premium' ? 'dark' : 'light'}
                toastClassName="custom-toast-container"
            />
        </>
    );
};

export default ToastProvider;
