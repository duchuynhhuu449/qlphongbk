
export const VNDFormatter = ( value ) => {
  if (value == null || isNaN(value)) return '0';

  const formatted = Number(value).toLocaleString();

  return formatted;
};




