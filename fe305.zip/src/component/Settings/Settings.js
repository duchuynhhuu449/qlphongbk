import React, { useState, useEffect } from 'react';
import styles from './Settings.module.scss';
import classNames from 'classnames/bind';
import { useNavigate } from 'react-router-dom'; // Sửa lại đúng path


const cx = classNames.bind(styles);

const Settings = ({ isOpen, onClose }) => {
  const [key, setKey] = useState('');
  const [isActivated, setIsActivated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate(); // ✅ Gọi useNavigate ở đây
  useEffect(() => {
    // Check if key exists in localStorage
    const savedKey = localStorage.getItem('app_activation_key');
    if (savedKey === 'ducdeptroai') {
      setIsActivated(true);
    }
  }, []);

  const handleActivate = () => {
    if (key === 'ducdeptroai') {
      setIsLoading(true);
      setError('');
      
      // Simulate loading for 10 seconds
      setTimeout(() => {
        localStorage.setItem('app_activation_key', key);
        setIsActivated(true);
        setIsLoading(false);
        window.location.href = "/"
        onClose();
      }, 3200);
    } else {
      setError('Mã kích hoạt không hợp lệ!');
    }
  };

  if (!isOpen) return null;

  return (
    <div className={cx('modal-overlay')}>
      <div className={cx('modal-content')}>
        <div className={cx('modal-header')}>
          <h2>Cài đặt và Kích hoạt</h2>
          <button className={cx('close-button')} onClick={onClose}>×</button>
        </div>
        
        <div className={cx('modal-body')}>
          {!isActivated ? (
            <>
              <div className={cx('input-group')}>
                <label htmlFor="activation-key">Nhập mã kích hoạt:</label>
                <input
                  type="text"
                  id="activation-key"
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="Nhập mã kích hoạt"
                  className={cx('input')}
                />
                <span>Nhập ducdeptroai để mở khóa</span>
              </div>

              {error && <p className={cx('error-message')}>{error}</p>}
              
              <button 
                className={cx('activate-button')} 
                onClick={handleActivate}
                disabled={isLoading}
              >
                {isLoading ? 'Đang kích hoạt...' : 'Kích hoạt'}
              </button>
              
              {isLoading && (
                <div className={cx('progress-bar')}>
                  <div className={cx('progress')}></div>
                </div>
              )}
            </>
          ) : (
            <div className={cx('activated-message')}>
              <p>✓ Đã kích hoạt thành công!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings; 