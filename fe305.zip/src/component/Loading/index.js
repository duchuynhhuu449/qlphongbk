import React from 'react';
import classNames from 'classnames/bind';
import styles from './Loading.module.scss';

const cx = classNames.bind(styles);

const Loading = ({ fullScreen = false, text = 'Đang tải...' }) => {
  return (
    <div className={cx('loading-container', { 'full-screen': fullScreen })}>
      <div className={cx('loading-spinner')}>
        <div className={cx('spinner')}></div>
        <p className={cx('loading-text')}>{text}</p>
      </div>
    </div>
  );
};

export default Loading; 