import React, { useState } from "react";
import styles from "./AjustRoom.module.scss";
import classNames from "classnames/bind";
import { editRoom } from "api";
import { useModal } from "component/Modal/ModalContext";

const cx = classNames.bind(styles);

function AjustRoom({ room }) {
  const [data, setData] = useState({
    roomNumber: room.roomNumber || "",
    daily: room.daily || "",
    firstHour: room.firstHour || "",
    extraHour: room.extraHour || ""
  });
  const { closeModal } = useModal();
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setData(prev => ({ ...prev, [id]: value }));
  };

  const handeAjustRoom = async () => {
    const room = data.roomNumber
    try {
      const response = await editRoom(room, data)
      if (!response) return setMessage("Điều chỉnh phòng không thành công!")
      setMessage("Điều chỉnh phòng thành công")
    } catch (error) {
      setMessage(error)
    }

    setTimeout(() => {
      setMessage("")
    }, 5000)

  }

  return (
    <div className={cx("container")}>
      <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
        <i className="fas fa-times"></i>
      </button>
      <h2 className={cx("title")}>Điều chỉnh phòng</h2>
      <form className={cx("form")} id="roomForm">
        <div className={cx("row")}>
          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="roomNumber">Số phòng:</label>
            <input
              value={data.roomNumber}
              onChange={handleInputChange}
              type="number"
              id="roomNumber"
              required
              className={cx("input")}
              placeholder="Nhập số phòng"
            />
          </div>

          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="dailyprice">Giá phòng ngày:</label>
            <input
              value={data.daily}
              onChange={handleInputChange}
              type="number"
              id="daily"
              required
              className={cx("input")}
              placeholder="Nhập giá phòng ngày"
            />
          </div>
        </div>

        <div className={cx("row")}>
          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="firstHour">Giờ đầu tiên:</label>
            <input
              value={data.firstHour}
              onChange={handleInputChange}
              type="number"
              id="firstHour"
              required
              className={cx("input")}
              placeholder="Nhập giá giờ đầu tiên"
            />
          </div>

          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="extraHour">Giá thêm giờ:</label>
            <input
              value={data.extraHour}
              onChange={handleInputChange}
              type="number"
              id="extraHour"
              required
              className={cx("input")}
              placeholder="Nhập giá thêm giờ"
            />
          </div>
        </div>

        <div className={cx("control")}>
          <button
            type="button"
            onClick={handeAjustRoom}
            className={cx("button")}
          >
            Sữa
          </button>
        </div>
      </form>
      {message && (
        <p className={cx("message", messageType)}>{message}</p>
      )}
    </div>
  );
}

export default AjustRoom;