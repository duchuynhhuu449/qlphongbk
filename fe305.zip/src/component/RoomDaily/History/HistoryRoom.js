import React, { useEffect, useState } from "react";
import styles from "./History.module.scss";
import classNames from "classnames/bind";
import { fetchHistory, deleteHistory } from "../../../api";

import flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
import { formatDateValue, formatTimeValue } from "../../dateUtils";

import { FaTrash } from "react-icons/fa";
import { useModal } from "component/Modal/ModalContext";
import { showError } from "utils/toast";

const cx = classNames.bind(styles);

function HistoryRoom() {
  const { closeModal } = useModal();
  const [history, setHistory] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  useEffect(() => {
    const loadHistory = async () => {
      const getHistory = await fetchHistory('all');
      const sortedHistory = await getHistory.sort((a, b) => new Date(b.checkInDate) - new Date(a.checkInDate));
      setHistory(sortedHistory);
    };

    loadHistory();
  }, []);
  console.log(history)

  // Tính toán dữ liệu cho mỗi trang
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = history.slice(indexOfFirstItem, indexOfLastItem);

  // Chuyển sang trang kế tiếp
  const nextPage = () => {
    if (currentPage < totalPages()) {
      setCurrentPage(currentPage + 1);
    }
  };

  // Chuyển sang trang trước
  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // Tính tổng số trang
  const totalPages = () => {
    return Math.ceil(history.length / itemsPerPage);
  };


  const handleDeleteItem = async (idToDelete) => {
    if (!window.confirm("Bạn có chắc chắn muốn xóa bản ghi lịch sử này?")) return;
    try {
      const response = await deleteHistory(idToDelete);
      const updatedHistory = history.filter(item => item._id !== idToDelete);
      setHistory(updatedHistory);
    } catch (error) {
      console.error("Lỗi khi xóa lịch sử:", error);
      showError("Xóa không thành công: " + error.message);
    }
  };


  useEffect(() => {
    flatpickr(`#startTime`, {
      enableTime: true,
      noCalendar: true,
      dateFormat: "H:i",
      time_24hr: true,
      minuteIncrement: 60,

    });
    flatpickr(`#endTime`, {
      enableTime: true,
      noCalendar: true,
      dateFormat: "H:i",
      time_24hr: true,
      minuteIncrement: 60,
    });


    flatpickr(`#startDate`, {
      dateFormat: "d-m-Y", // <-- Định dạng ngày/tháng/năm đúng
      maxDate: "today",     // Chặn các ngày sau ngày hiện tại
    });

    flatpickr(`#endDate`, {
      dateFormat: "d-m-Y", // <-- Định dạng ngày/tháng/năm đúng
    });

  }, []);


  return (
    <div className={cx("historyContainer")}>
      <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
        <i className="fas fa-times"></i>
      </button>
      <h2 className={cx("title-table")}>Lịch sử thuê phòng</h2>

      <div className={cx("tableContainer")}>
        <table className={cx("history-table")}>
          <thead>
            <tr>
              <th>Phòng</th>
              <th>Thời gian Nhận/Trả</th>
              <th>Ghi chú</th>
              <th>Thành tiền</th>
              <th>Xóa</th>
            </tr>
          </thead>
          <tbody className={cx("data")}>
            {currentItems && currentItems.length > 0 ? (
              currentItems.map((item, index) => (
                <tr key={index}>
                  <td style={{ textAlign: "center" }}>
                    <div className={cx("roomBadge")}>{item.roomNumber}</div>
                  </td>
                  <td>
                    <span className={cx("highlight")}>
                      Nhận: {formatTimeValue(item.checkInDate)} - {formatDateValue(item.checkInDate)}
                    </span>
                    <span>
                      Trả: {formatTimeValue(item.checkOutDate)} - {formatDateValue(item.checkOutDate)}
                    </span>
                  </td>
                  <td dangerouslySetInnerHTML={{ __html: item.description }} />
                  <td className={cx("totalAmount")}>{item.totalAmount}đ</td>
                  <td style={{ textAlign: "center" }}>
                    <button className={cx("deleteBtn")} onClick={() => handleDeleteItem(item._id)}>
                      <FaTrash />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                  Không có dữ liệu lịch sử
                </td>
              </tr>
            )}

          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <div className={cx("pagination")}>
        <div className={cx("notification")}><span>Trang {currentPage} of {totalPages()}</span></div>
        <div className={cx("controls")}>
          <button onClick={prevPage} disabled={currentPage === 1}>
            Trang trước
          </button>
          <button onClick={nextPage} disabled={currentPage === totalPages()}>
            Trang sau
          </button>
        </div>
      </div>
    </div>
  );
}

export default HistoryRoom;
