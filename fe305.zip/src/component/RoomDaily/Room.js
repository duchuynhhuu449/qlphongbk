import React, { useEffect, useState, useRef } from "react";
import flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
import classNames from "classnames/bind";
import styles from "./Room.module.scss";
import { formatTimeValue, formatDateValue } from "../dateUtils";
import { useDebounceHandler } from "../debounce";
import { FaGlassWhiskey, FaEdit, FaTrash, FaEllipsisV, FaTimes } from "react-icons/fa";
import { useModal } from "component/Modal/ModalContext";
import Notes from "./Notes/Notes";
import AjustRoom from "./AjustRoom/AjustRoom";
import DepositModal from "./DepositModal/DepositModal";
import { deleteRoomData, deleteNoteWater, checkRoomDeposit } from "../../api";
import { showError } from "utils/toast";
import ConfirmModal from 'component/Modal/ConfirmModal';

const cx = classNames.bind(styles);

const Room = ({ room, handleInputChange, setCurrentTime, calculate, isSelected, onSelect, sharedRef, onUpdate }) => {
  const debounce = useDebounceHandler();
  const [tempDates, setTempDates] = useState({});
  const localRef = useRef({});
  const checkDateRef = sharedRef || localRef;
  const originalRef = useRef({});
  const { openModal, closeModal } = useModal();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const [localDeposit, setLocalDeposit] = useState(room.deposit || 0);
  const [localDepositStatus, setLocalDepositStatus] = useState(room.depositStatus || "kept");

  const fetchDep = async () => {
    try {
      const res = await checkRoomDeposit(room.roomNumber);
      if (res && res.amount) {
        setLocalDeposit(res.amount);
        setLocalDepositStatus(res.status || "kept");
      } else {
        setLocalDeposit(0);
      }
    } catch (e) { }
  };

  useEffect(() => {
    fetchDep();
  }, [room.roomNumber]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleChange = (type, roomNumber, e) => {
    const newValue = e.target.value;
    const originalValue = originalRef.current[`${type}-${roomNumber}`] ??
      (type === "date" ? formatDateValue(room.checkInDate) : formatTimeValue(room.checkInDate));

    originalRef.current[`${type}-${roomNumber}`] = newValue;

    setTempDates((prev) => ({
      ...prev,
      [`${type}-${roomNumber}`]: newValue,
    }));

    debounce(
      `${type}-${roomNumber}`,
      newValue,
      originalValue,
      () => {
        handleInputChange(roomNumber, {
          type,
          value: newValue,
          ...(type === "checkTimeDate"
            ? {
              date: tempDates[`checkInDate-${room.roomNumber}`] ?? formatDateValue(room.checkInDate),
            }
            : {
              time: tempDates[`checkTimeDate-${room.roomNumber}`] ?? formatTimeValue(room.checkInDate),
            }),
        });
      }
    );
  };

  const initFlatpickr = () => {
    if (!checkDateRef.current[room.roomNumber]) return;

    const refs = checkDateRef.current[room.roomNumber];

    flatpickr(refs.checkindate, {
      dateFormat: "d-m-Y",
      onChange: () => handleChange("checkInDate", room.roomNumber, { target: { value: refs.checkindate.value } }),
    });

    flatpickr(refs.checkoutdate, {
      dateFormat: "d-m-Y",
    });

    flatpickr(refs.checkintime, {
      enableTime: true,
      noCalendar: true,
      dateFormat: "H:i",
      time_24hr: true,
      minuteIncrement: 60,
      onChange: () => handleChange("checkTimeDate", room.roomNumber, { target: { value: refs.checkintime.value } }),
    });

    flatpickr(refs.checkouttime, {
      enableTime: true,
      noCalendar: true,
      dateFormat: "H:i",
      time_24hr: true,
      minuteIncrement: 60,
    });
  };

  useEffect(() => {
    initFlatpickr();
  }, [room.roomNumber]);

  const setRef = (el, key) => {
    if (!checkDateRef.current[room.roomNumber]) {
      checkDateRef.current[room.roomNumber] = {};
    }
    if (el) {
      checkDateRef.current[room.roomNumber][key] = el;
    }
  };

  const handleCalculate = () => {
    const data = {
      roomNumber: room.roomNumber,
      checkDateRef: checkDateRef
    };
    calculate(data);
  };

  const handleDeleteRoom = async () => {
    openModal(
      <ConfirmModal
        title="Xóa dữ liệu phòng"
        message={`Bạn có chắc muốn xóa dữ liệu nhận phòng và phụ phí nước của Phòng ${room.roomNumber}?`}
        onConfirm={async () => {
          try {
            await deleteRoomData(room.roomNumber);
            await deleteNoteWater(room.roomNumber);
            if (onUpdate) onUpdate();
          } catch (error) {
            console.error("Lỗi khi xóa dữ liệu phòng:", error);
            showError("Lỗi khi xóa dữ liệu phòng");
          }
        }}
      />
    );
  };

  const handleOpenNote = () => {
    openModal(<Notes room={room.roomNumber} />);
  };

  const handleOpenDeposit = () => {
    openModal(
      <DepositModal
        roomNumber={room.roomNumber}
        onClose={() => closeModal()}
        onDepositSuccess={() => { fetchDep(); if (onUpdate) onUpdate(); }}
      />
    );
  };

  const isOccupied = !!room.checkInDate;

  return (
    <div
      className={cx("roomCard", { selected: isSelected, "menu-open": isMenuOpen })}
      onClick={() => onSelect && onSelect(room.roomNumber)}
    >
      {/* Room Header */}
      <div className={cx("roomHeader")}>
        <div className={cx("roomTitleGroup")}>
          <div className={cx("roomNumber")}>{String(room.roomNumber).padStart(3, "0")}</div>
          <div>
            <h3 className={cx("roomTitle")}>Phòng {room.roomNumber}</h3>
            <span className={cx("statusBadge", isOccupied ? "statusOccupied" : "statusEmpty")}>
              {isOccupied ? "● Có khách" : "○ Trống"}
            </span>
          </div>
        </div>
        <div className={cx("iconActions")} ref={menuRef}>
          <div className={cx("iconBtn", { active: isMenuOpen })} onClick={(e) => { e.stopPropagation(); setIsMenuOpen(!isMenuOpen); }} title="Thao tác">
            {isMenuOpen ? <FaTimes size={14} /> : <FaEllipsisV size={14} />}
          </div>

          {isMenuOpen && (
            <div className={cx("dropdownMenu")} onClick={(e) => e.stopPropagation()}>
              <div className={cx("dropdownItem")} onClick={() => { setIsMenuOpen(false); handleOpenDeposit(); }}>
                <i className="fas fa-money-check-alt" style={{ fontSize: 13, color: '#f59e0b', width: 14, textAlign: 'center' }}></i>
                <span>{localDeposit > 0 ? "Đã cọc giữ chỗ" : "Nhận cọc giữ chỗ"}</span>
              </div>
              <div className={cx("dropdownItem")} onClick={() => { setIsMenuOpen(false); handleOpenNote(); }}>
                <FaGlassWhiskey size={14} style={{ color: '#3b82f6' }} /> <span>Bán nước / Ghi chú</span>
              </div>
              <div className={cx("dropdownItem")} onClick={() => { setIsMenuOpen(false); openModal(<AjustRoom room={room} />); }}>
                <FaEdit size={14} style={{ color: '#10b981' }} /> <span>Sửa thông tin phòng</span>
              </div>
              <div className={cx("dropdownItem", "delete")} onClick={() => { setIsMenuOpen(false); handleDeleteRoom(); }}>
                <FaTrash size={14} /> <span>Xóa phòng này</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Room Body */}
      <div className={cx("roomBody")} onClick={(e) => e.stopPropagation()}>
        {/* Check-in */}
        <div className={cx("timeSection")}>
          <div className={cx("timeLabel")}>
            <span className={cx("timeDot", "dotCheckin")} />
            Nhận phòng
          </div>
          <div className={cx("timeContainer")}>
            <input
              ref={(el) => setRef(el, "checkindate")}
              type="text"
              id={`checkin-date-${room.roomNumber}`}
              className={cx("timeInput")}
              value={tempDates[`checkInDate-${room.roomNumber}`] ?? formatDateValue(room.checkInDate)}
              onChange={(e) => handleChange("checkInDate", room.roomNumber, e)}
            />
            <input
              ref={(el) => setRef(el, "checkintime")}
              type="text"
              id={`checkin-time-${room.roomNumber}`}
              className={cx("timeInput")}
              value={tempDates[`checkTimeDate-${room.roomNumber}`] ?? formatTimeValue(room.checkInDate)}
              onChange={(e) => handleChange("checkTimeDate", room.roomNumber, e)}
            />
          </div>
        </div>

        {/* Check-out */}
        <div className={cx("timeSection")}>
          <div className={cx("timeLabel")}>
            <span className={cx("timeDot", "dotCheckout")} />
            Trả phòng
          </div>
          <div className={cx("timeContainer")}>
            <input
              ref={(el) => setRef(el, "checkoutdate")}
              type="text"
              id={`checkout-date-${room.roomNumber}`}
              className={cx("timeInput")}
              value={tempDates[`checkOutDate-${room.roomNumber}`] ?? ""}
              onChange={(e) => handleChange("checkOutDate", room.roomNumber, e)}
            />
            <input
              ref={(el) => setRef(el, "checkouttime")}
              type="text"
              id={`checkout-time-${room.roomNumber}`}
              className={cx("timeInput")}
              value={tempDates[`checkOutTime-${room.roomNumber}`] ?? ""}
              onChange={(e) => handleChange("checkOutTime", room.roomNumber, e)}
            />
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className={cx("btnContainer")} onClick={(e) => e.stopPropagation()}>
        <div className={cx("btnTop")}>
          <button className={cx("roomButton", "checkIn")} onClick={() => setCurrentTime("checkin", room.roomNumber, checkDateRef)}>
            Nhận phòng
          </button>
          <button className={cx("roomButton", "checkOut")} onClick={() => setCurrentTime("checkout", room.roomNumber, checkDateRef)}>
            Trả phòng
          </button>
        </div>
        <div className={cx("btnBottom")}>
          <button className={cx("roomButton", "calculate")} onClick={handleCalculate}>
            Tính tiền
          </button>
        </div>
      </div>

      {/* Deposit Badge */}
      {localDeposit > 0 && (
        <div className={cx("depositBadge", localDepositStatus || "kept")}>
          {localDepositStatus === 'refunded' ? 'Đã hoàn: ' : localDepositStatus === 'lost' ? 'Mất cọc: ' : 'Đang giữ: '} {localDeposit.toLocaleString('vi-VN')} đ
        </div>
      )}
    </div>
  );
};

export default Room;
