import { convertToISODate } from "../../dateUtils";

const isValidNumber = (val) => val !== "" && val !== null && val !== undefined && !isNaN(val);

/**
 * Tìm surcharge entry áp dụng cho 1 ngày cụ thể
 * So sánh theo ngày (bỏ qua giờ), hỗ trợ date range (startDate → endDate)
 */
const findSurchargeForDate = (dateObj, surchargeDates) => {
  // Lấy YYYY-MM-DD của dateObj theo local timezone
  const year = dateObj.getFullYear();
  const month = String(dateObj.getMonth() + 1).padStart(2, "0");
  const day = String(dateObj.getDate()).padStart(2, "0");
  const checkStr = `${year}-${month}-${day}`;

  return surchargeDates.find((s) => {
    const start = s.startDate; // YYYY-MM-DD string
    const end = s.endDate;     // YYYY-MM-DD string
    return checkStr >= start && checkStr <= end;
  });
};

/**
 * Tính tiền phòng có tích hợp phụ thu ngày đặc biệt
 * Hỗ trợ: date range, multiplier mode, fixed price mode
 */
export const calculateRoomFee = (roomNumber, ref, rooms, surchargeDates = []) => {
  const checkInDate = convertToISODate(
    ref.current[roomNumber]["checkindate"].value
  );
  const checkInTime = ref.current[roomNumber]["checkintime"].value;
  const checkOutDate = convertToISODate(
    ref.current[roomNumber]["checkoutdate"].value
  );
  const checkOutTime = ref.current[roomNumber]["checkouttime"].value;

  if (!checkInDate || !checkInTime || !checkOutDate || !checkOutTime) {
    return { error: "Vui lòng nhập đầy đủ thời gian." };
  }

  const start = new Date(`${checkInDate}T${checkInTime}`);
  const end = new Date(`${checkOutDate}T${checkOutTime}`);

  if (end <= start) {
    return {
      error: "Thời gian trả phòng cần được thiết lập muộn hơn thời gian nhận phòng để đảm bảo hợp lệ."
    };
  }

  let total = 0;
  const notes = [];
  const diffMs = end - start;
  const diffMinutes = Math.ceil(diffMs / 60000);
  const diffHours = Math.ceil(diffMs / 3600000);
  const startHour = start.getHours();
  const endHour = end.getHours();
  const isSameDay = start.toDateString() === end.toDateString();
  const isNightStay =
    startHour >= 19 &&
    startHour <= 23 &&
    endHour >= 0 &&
    endHour <= 2 &&
    diffHours <= 9;

  const dataRoom = rooms.find((room) => room.roomNumber === roomNumber);
  if (!dataRoom) {
    return { error: "Không tìm thấy thông tin phòng." };
  }

  let surcharge = 0;
  let surchargeTotal = 0;
  const surchargeNotes = [];

  if (isSameDay || isNightStay) {
    // === TÍNH THEO GIỜ ===
    // Kiểm tra phụ thu ngày đặc biệt
    const surchargeEntry = findSurchargeForDate(start, surchargeDates);
    const hasSurchargeHourly = surchargeEntry &&
      (surchargeEntry.mode === "fixed" ? true : (surchargeEntry.applyTo === "hourly" || surchargeEntry.applyTo === "both"));

    // Xác định giá áp dụng
    let effectiveFirstHour = dataRoom.firstHour;
    let effectiveExtraHour = dataRoom.extraHour;

    if (hasSurchargeHourly && surchargeEntry.mode === "fixed") {
      if (isValidNumber(surchargeEntry.fixedFirstHour)) {
        const extraDiff = Number(surchargeEntry.fixedFirstHour);
        surchargeTotal += extraDiff;
        surchargeNotes.push(`🎉 ${surchargeEntry.name}: Cộng thêm giờ đầu (${extraDiff >= 0 ? '+' : ''}${extraDiff.toLocaleString()}đ)`);
      }
      if (isValidNumber(surchargeEntry.fixedExtraHour)) {
        effectiveExtraHour = dataRoom.extraHour + Number(surchargeEntry.fixedExtraHour);
      }
    }

    total = effectiveFirstHour;
    notes.push(`Giờ đầu (cơ bản): ${effectiveFirstHour.toLocaleString()} VNĐ`);

    const extraMinutes = diffMinutes - 60;
    const extraHoursCharged =
      extraMinutes > 0 ? Math.floor((extraMinutes + 45) / 60) : 0;

    if (extraHoursCharged > 0) {
      const baseExtraSurcharge = extraHoursCharged * dataRoom.extraHour;
      const totalExtraHourSurcharge = extraHoursCharged * effectiveExtraHour;

      if (effectiveExtraHour !== dataRoom.extraHour) {
        const extraDiff = totalExtraHourSurcharge - baseExtraSurcharge;
        surchargeTotal += extraDiff;
        surchargeNotes.push(`🎉 ${surchargeEntry?.name || 'Phụ thu'}: Cộng thêm thêm giờ (${extraDiff >= 0 ? '+' : ''}${extraDiff.toLocaleString()}đ)`);
      }

      notes.push(
        `Phụ thu (cơ bản): ${extraHoursCharged} giờ x ${dataRoom.extraHour.toLocaleString()} VNĐ = ${baseExtraSurcharge.toLocaleString()} VNĐ`
      );
      total += baseExtraSurcharge;
    }

    // Mode hệ số: nhân thêm
    if (hasSurchargeHourly && surchargeEntry.mode === "multiplier") {
      const surchargeAmount = Math.round(total * (surchargeEntry.multiplier - 1));
      surchargeTotal += surchargeAmount;
      const ds = `${String(start.getDate()).padStart(2, '0')}/${String(start.getMonth() + 1).padStart(2, '0')}/${start.getFullYear()}`;
      surchargeNotes.push(
        `🎉 ${surchargeEntry.name} (${ds}): x${surchargeEntry.multiplier} (+${surchargeAmount.toLocaleString()} VNĐ)`
      );
    }
  } else {
    // === TÍNH THEO NGÀY ===
    if (startHour >= 5 && startHour <= 12) {
      const surchargeHours = 12 - startHour;
      if (surchargeHours > 0) {
        surcharge += surchargeHours * dataRoom.extraHour;
        notes.push(
          `Phụ thu nhận phòng sớm: ${surchargeHours} giờ x ${dataRoom.extraHour.toLocaleString()} VNĐ = ${surcharge.toLocaleString()} VNĐ`
        );
      }
    }

    const firstDayEnd = new Date(start);
    if (startHour >= 5 && startHour <= 23) {
      firstDayEnd.setDate(firstDayEnd.getDate() + 1);
    }
    firstDayEnd.setHours(12, 0, 0, 0);

    if (end <= firstDayEnd) {
      // === 1 NGÀY ===
      const surchargeEntry = findSurchargeForDate(start, surchargeDates);
      const hasSurchargeDaily = surchargeEntry &&
        (surchargeEntry.mode === "fixed" ? true : (surchargeEntry.applyTo === "daily" || surchargeEntry.applyTo === "both"));

      let effectiveDaily = dataRoom.daily;

      if (hasSurchargeDaily && surchargeEntry.mode === "fixed" && isValidNumber(surchargeEntry.fixedDaily)) {
        const extraDiff = Number(surchargeEntry.fixedDaily);
        surchargeNotes.push(
          `🎉 ${surchargeEntry.name}: Cộng thêm ngày (${extraDiff >= 0 ? '+' : ''}${extraDiff.toLocaleString()}đ)`
        );
        surchargeTotal += extraDiff; // Bóc tách phần chênh lệch đưa vào tổng phụ thu
      }

      total = effectiveDaily;
      notes.push(`Tính 1 ngày cơ bản: ${dataRoom.daily.toLocaleString()} VNĐ`);

      if (hasSurchargeDaily && surchargeEntry.mode === "multiplier") {
        const surchargeAmount = Math.round(dataRoom.daily * (surchargeEntry.multiplier - 1));
        surchargeTotal += surchargeAmount;
        surchargeNotes.push(
          `🎉 ${surchargeEntry.name}: x${surchargeEntry.multiplier} (+${surchargeAmount.toLocaleString()} VNĐ)`
        );
      }
    } else {
      // === NHIỀU NGÀY ===
      const lastNoon = new Date(end);
      lastNoon.setHours(12, 0, 0, 0);
      const fullDays = Math.round((lastNoon - firstDayEnd) / 86400000) + 1;

      // Tính từng ngày: kiểm tra phụ thu cho mỗi ngày
      let totalDailyCharge = 0;
      const startDateForCalc = new Date(firstDayEnd);
      startDateForCalc.setDate(startDateForCalc.getDate() - 1); // Start from the actual first day
      startDateForCalc.setHours(0, 0, 0, 0);

      let surchargeDaysList = [];

      for (let i = 0; i < fullDays; i++) {
        const checkDate = new Date(startDateForCalc);
        checkDate.setDate(checkDate.getDate() + i);

        const surchargeEntry = findSurchargeForDate(checkDate, surchargeDates);
        const hasSurchargeDaily = surchargeEntry &&
          (surchargeEntry.mode === "fixed" ? true : (surchargeEntry.applyTo === "daily" || surchargeEntry.applyTo === "both"));

        if (hasSurchargeDaily) {
          if (surchargeEntry.mode === "fixed" && isValidNumber(surchargeEntry.fixedDaily)) {
            totalDailyCharge += dataRoom.daily; // Tính tiền cơ bản
            const extraDiff = Number(surchargeEntry.fixedDaily);
            surchargeTotal += extraDiff; // Phần chênh lệch phụ thu
            surchargeDaysList.push({
              date: checkDate,
              entry: surchargeEntry,
              price: extraDiff,
              extra: extraDiff,
              type: "fixed"
            });
          } else if (surchargeEntry.mode === "multiplier") {
            totalDailyCharge += dataRoom.daily;
            const extraAmount = Math.round(dataRoom.daily * (surchargeEntry.multiplier - 1));
            surchargeTotal += extraAmount;
            surchargeDaysList.push({
              date: checkDate,
              entry: surchargeEntry,
              extra: extraAmount,
              type: "multiplier"
            });
          } else {
            totalDailyCharge += dataRoom.daily;
          }
        } else {
          totalDailyCharge += dataRoom.daily;
        }
      }

      total = totalDailyCharge;

      notes.push(`${fullDays} ngày x ${dataRoom.daily.toLocaleString()} VNĐ = ${(fullDays * dataRoom.daily).toLocaleString()} VNĐ`);

      // Ghi chú cho từng ngày phụ thu
      surchargeDaysList.forEach((item) => {
        const dateStr = `${String(item.date.getDate()).padStart(2, '0')}/${String(item.date.getMonth() + 1).padStart(2, '0')}/${item.date.getFullYear()}`;
        if (item.type === "fixed") {
          surchargeNotes.push(
            `🎉 ${dateStr} - ${item.entry.name}: Cộng thêm ngày (${item.extra >= 0 ? '+' : ''}${item.extra.toLocaleString()}đ)`
          );
        } else {
          surchargeNotes.push(
            `🎉 ${dateStr} - ${item.entry.name}: x${item.entry.multiplier} (+${item.extra.toLocaleString()}đ)`
          );
        }
      });

      if (surchargeDaysList.length === 0) {
        // Không có surcharge nào → ghi note bình thường
        notes.length > 0 || notes.push(`${fullDays} ngày x ${dataRoom.daily.toLocaleString()} VNĐ = ${total.toLocaleString()} VNĐ`);
      }
    }

    if (endHour >= 12 || (endHour === 12 && end.getMinutes() > 15)) {
      let extraHours = endHour - 12;
      if (extraHours < 0) extraHours = 0;
      if (end.getMinutes() > 15) {
        extraHours += 1;
      }
      if (extraHours > 0) {
        // Kiểm tra phụ thu cho ngày trả phòng
        const lateDate = new Date(end);
        const lateSurcharge = findSurchargeForDate(lateDate, surchargeDates);
        const hasLateSurcharge = lateSurcharge &&
          (lateSurcharge.mode === "fixed" ? true : (lateSurcharge.applyTo === "hourly" || lateSurcharge.applyTo === "both"));

        let effExtra = dataRoom.extraHour;
        let isFixed = false;

        if (hasLateSurcharge && lateSurcharge.mode === "fixed" && isValidNumber(lateSurcharge.fixedExtraHour)) {
          effExtra = dataRoom.extraHour + Number(lateSurcharge.fixedExtraHour);
          isFixed = true;
        }

        const baseLateCost = extraHours * dataRoom.extraHour;
        const lateCost = extraHours * effExtra;

        if (isFixed) {
          surcharge += baseLateCost;
          const extraDiff = lateCost - baseLateCost;
          surchargeTotal += extraDiff;
          notes.push(`Phụ thu trả phòng muộn: ${extraHours} giờ x ${dataRoom.extraHour.toLocaleString()} VNĐ = ${baseLateCost.toLocaleString()} VNĐ`);
        } else {
          surcharge += lateCost;
          notes.push(`Phụ thu trả phòng muộn: ${extraHours} giờ x ${effExtra.toLocaleString()} VNĐ = ${lateCost.toLocaleString()} VNĐ`);
        }

        if (hasLateSurcharge && !isFixed && lateSurcharge.mode === "multiplier") {
          const extraM = Math.round(lateCost * (lateSurcharge.multiplier - 1));
          surchargeTotal += extraM;
          const dl = `${String(lateDate.getDate()).padStart(2, '0')}/${String(lateDate.getMonth() + 1).padStart(2, '0')}/${lateDate.getFullYear()}`;
          surchargeNotes.push(
            `🎉 Trả phòng muộn (${dl}): x${lateSurcharge.multiplier} (+${extraM.toLocaleString()}đ)`
          );
        } else if (isFixed) {
          const dl = `${String(lateDate.getDate()).padStart(2, '0')}/${String(lateDate.getMonth() + 1).padStart(2, '0')}/${lateDate.getFullYear()}`;
          const diffDiff = lateCost - baseLateCost;
          surchargeNotes.push(
            `🎉 Cộng thêm trả phòng muộn (${dl}): ${diffDiff >= 0 ? '+' : ''}${diffDiff.toLocaleString()}đ`
          );
        }
      }
    }
  }

  total += surcharge;
  total += surchargeTotal;

  notes.push(
    `Thời gian ở thực: ${diffMinutes >= 1440
      ? `${Math.floor(diffMinutes / 1440)} ngày${diffMinutes % 1440
        ? ` ${Math.floor((diffMinutes % 1440) / 60)} giờ ${diffMinutes % 60} phút`
        : ""
      }`
      : `${Math.floor(diffMinutes / 60)} giờ ${diffMinutes % 60} phút`
    }`
  );

  const objectDatatoSaveHistory = {
    totalAmount: total.toLocaleString(),
    checkInDate: start.toLocaleString(),
    checkOutDate: end.toLocaleString(),
    description: [...notes, ...surchargeNotes].map((note) => `<span>${note}</span>`).join(""),
  };

  return {
    start,
    end,
    notes,
    total,
    surchargeTotal,
    surchargeNotes,
    deposit: dataRoom.deposit || 0,
    objectDatatoSaveHistory
  };
};
