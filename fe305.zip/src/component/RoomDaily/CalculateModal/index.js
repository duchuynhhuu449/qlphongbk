import React, { useEffect, useState } from "react";
import classNames from "classnames/bind";
import styles from "./CalculateModal.module.scss";
import { useModal } from "component/Modal/ModalContext";
import { useRef } from "react";
import {
  saveRoomHistory,
  deleteRoomData,
  fetchNoteList,
  deleteNoteWater,
  checkRoomDeposit,
  deleteDeposit,
} from "api";
import { showSuccess, showError } from "utils/toast";

const cx = classNames.bind(styles);

function CalculateModal({ data, onSuccess }) {
  const depositRef = useRef(null);
  const deposit2Ref = useRef(null);
  const { closeModal } = useModal();

  const [waterTotal, setWaterTotal] = useState(0);
  const [waterDetails, setWaterDetails] = useState([]);

  const [depositAmount, setDepositAmount] = useState("");
  const [isDeletingDeposit, setIsDeletingDeposit] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const waterNote = await fetchNoteList();
        if (!waterNote || !Array.isArray(waterNote.data)) {
          setWaterTotal(0);
          setWaterDetails([]);
          return;
        }

        const roomNote = waterNote.data.find(
          (note) => note.SoPhong === data?.roomNumber
        );

        if (roomNote && Array.isArray(roomNote.nuocuong)) {
          const total = roomNote.nuocuong.reduce(
            (sum, item) => sum + item.soLuong * item.unitprice,
            0
          );
          setWaterTotal(total);
          setWaterDetails(roomNote.nuocuong);
        } else {
          setWaterTotal(0);
          setWaterDetails([]);
        }
      } catch (error) {
        console.error("Lỗi khi lấy dữ liệu nước:", error);
        setWaterTotal(0);
        setWaterDetails([]);
      }
    };

    if (data?.roomNumber) {
      fetchData();
    }
  }, [data?.roomNumber]);

  const formatDateTimeVN = (dateObj) => {
    if (!dateObj) return "";
    const d = new Date(dateObj);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  };

  const surchargeTotal = data?.surchargeTotal || 0;
  const depositPaid = data?.deposit || 0;
  const grandTotal = (data?.total || 0) + waterTotal - depositPaid;

  const handleDepositChange = (e) => {
    // Strip everything except numbers
    const rawValue = e.target.value.replace(/[^\d]/g, "");
    if (!rawValue) {
      setDepositAmount("");
      return;
    }

    // Parse to int and format locale
    const numberValue = parseInt(rawValue, 10);
    setDepositAmount(numberValue.toLocaleString("vi-VN"));
  };

  useEffect(() => {
    if (!deposit2Ref.current) return;
    const depositNumber = parseInt(depositAmount.replace(/[^\d]/g, ""), 10) || 0;
    const difference = depositNumber - grandTotal;
    deposit2Ref.current.innerText = difference < 0 ? "0" : difference.toLocaleString("vi-VN");
  }, [depositAmount, grandTotal]);

  const HandleSaveDatatoHistory = async () => {
    if (data?.ref?.current && data.ref.current[data.roomNumber]) {
      const refs = data.ref.current[data.roomNumber];
      if (refs.checkindate) refs.checkindate.value = "";
      if (refs.checkintime) refs.checkintime.value = "";
      if (refs.checkoutdate) refs.checkoutdate.value = "";
      if (refs.checkouttime) refs.checkouttime.value = "";
    }
    await deleteNoteWater(data?.roomNumber);
    await deleteRoomData(data?.roomNumber);
    await saveRoomHistory(data?.roomNumber, {
      ...(data?.objectDatatoSaveHistory || {}),
      totalAmount: grandTotal.toLocaleString(),
      waterTotal: waterTotal || "",
      waterDetails: waterDetails || "",
    });

    closeModal();
  };

  const handleDeleteDeposit = async () => {
    if (!window.confirm("Bạn có muốn xóa Tiền cọc giữ chỗ của phòng này?")) return;
    setIsDeletingDeposit(true);
    try {
      const depositInfo = await checkRoomDeposit(data?.roomNumber);
      if (depositInfo) {
        await deleteDeposit(depositInfo._id || depositInfo.id || data?.roomNumber);
        showSuccess("Đã xóa tiền cọc thành công!");
        closeModal();
        if (onSuccess) onSuccess();
      } else {
        showError("Không tìm thấy thông tin cọc!");
      }
    } catch (error) {
      showError("Lỗi khi xóa cọc: " + error.message);
    } finally {
      setIsDeletingDeposit(false);
    }
  };

  const surchargeNotes = data?.surchargeNotes || [];

  const [showDetails, setShowDetails] = useState(false);

  return (
    <>
      <div className={cx("invoice")}>
        {/* Header spanning across all columns */}
        <div className={cx("invoice-header")}>
          <div className={cx("invoice-title-group")}>
            <h3 className={cx("invoice-title")}>HÓA ĐƠN TÍNH TIỀN</h3>
            <span className={cx("invoice-room")}>Phòng {data.roomNumber}</span>
          </div>
          <div className={cx("header-actions")}>
            <button
              className={cx("btn-toggle-details")}
              onClick={() => setShowDetails(!showDetails)}
            >
              {showDetails ? "Ẩn bớt chi tiết" : "Xem chi tiết"} <i className={`fas fa-chevron-${showDetails ? 'up' : 'down'}`}></i>
            </button>
            <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>

        {/* 3-Column Grid Body */}
        <div className={cx("invoice-body", { "grid-3": true })}>

          {/* Column 1: Time Info */}
          <div className={cx("invoice-col")}>
            <div className={cx("section-title")}>Thời gian</div>
            <div className={cx("invoice-section")}>
              <div className={cx("time-card")}>
                <div className={cx("time-label")}><i className="fas fa-sign-in-alt"></i> Nhận phòng</div>
                <div className={cx("time-value")}>{formatDateTimeVN(data.start)}</div>
              </div>
              <div className={cx("time-card")}>
                <div className={cx("time-label")}><i className="fas fa-sign-out-alt"></i> Trả phòng</div>
                <div className={cx("time-value")}>{formatDateTimeVN(data.end)}</div>
              </div>
            </div>

            <div className={cx("section-title")}>Thanh toán</div>
            <div className={cx("invoice-section", "payment-section")}>
              <div className={cx("payment-row")}>
                <label>Khách đưa:</label>
                <input
                  type="text"
                  value={depositAmount}
                  onChange={handleDepositChange}
                  placeholder="Nhập số tiền"
                />
              </div>
              <div className={cx("payment-row", "change-row")}>
                <span>Tiền thối lại:</span>
                <b ref={deposit2Ref}>0</b>
              </div>
            </div>
          </div>

          {/* Column 2: Pricing Details */}
          <div className={cx("invoice-col")}>
            <div className={cx("section-title")}>Chi phí phòng</div>
            <div className={cx("invoice-section")}>
              {(!showDetails && data.notes.length > 0) && (
                <div className={cx("summary-note")}>Hiển thị rút gọn (nhấn Xem chi tiết để mở ra)</div>
              )}
              {showDetails && data.notes.map((note, i) => (
                <div className={cx("invoice-row", "detail")} key={i}>
                  <span>{note}</span>
                </div>
              ))}
              <div className={cx("invoice-row", "subtotal", "highlight-total")}>
                <span>Tiền phòng cơ bản</span>
                <span>{(data.total - surchargeTotal).toLocaleString()} đ</span>
              </div>
            </div>

            {surchargeNotes.length > 0 && (
              <>
                <div className={cx("section-title", "surcharge-title")}>Phụ thu đặc biệt</div>
                <div className={cx("invoice-section", "surcharge-section")}>
                  {showDetails && surchargeNotes.map((note, i) => (
                    <div className={cx("invoice-row", "surcharge-row")} key={i}>
                      <span>{note}</span>
                    </div>
                  ))}
                  <div className={cx("invoice-row", "subtotal")}>
                    <span>Tổng phụ thu</span>
                    <span>{surchargeTotal.toLocaleString()} đ</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Column 3: Water Details & Actions */}
          <div className={cx("invoice-col")}>
            <div className={cx("section-title")}>Dịch vụ (Nước uống)</div>
            <div className={cx("invoice-section")}>
              {waterTotal === 0 && <div className={cx("empty-note")}>Không sử dụng</div>}
              {waterTotal > 0 && showDetails && waterDetails.map((water, index) => (
                <div key={index} className={cx("water-row")}>
                  <span className={cx("water-name")}>{water.tenNuoc}</span>
                  <span className={cx("water-qty")}>{water.soLuong} x {water.unitprice.toLocaleString()}đ</span>
                  <span className={cx("water-price")}>{water.gia.toLocaleString()}đ</span>
                </div>
              ))}
              {waterTotal > 0 && (
                <div className={cx("invoice-row", "subtotal")}>
                  <span>Tổng tiền nước</span>
                  <span>{waterTotal.toLocaleString()} đ</span>
                </div>
              )}
            </div>

            {depositPaid > 0 && (
              <div className={cx("invoice-row", "subtotal")} style={{ color: "#d97706", marginTop: "10px", fontWeight: "600", fontSize: "15px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  Đã cọc trước
                  <button
                    onClick={handleDeleteDeposit}
                    disabled={isDeletingDeposit}
                    style={{ background: "#ef4444", color: "white", border: "none", borderRadius: "6px", padding: "4px 8px", fontSize: "12px", fontWeight: "600", cursor: "pointer", display: "flex", alignItems: "center", gap: "4px" }}
                  >
                    {isDeletingDeposit ? "Đang xóa..." : <><i className="fas fa-trash-alt"></i> Xóa cọc</>}
                  </button>
                </span>
                <span>-{depositPaid.toLocaleString()} VNĐ</span>
              </div>
            )}

            <div className={cx("invoice-total-box")}>
              <div className={cx("total-label")}>TỔNG CỘNG</div>
              <div className={cx("total-amount")}>{grandTotal.toLocaleString()} VNĐ</div>
            </div>

            <div className={cx("invoice-actions-vertical")}>
              <button className={cx("btn", "btn-save")} onClick={HandleSaveDatatoHistory}>
                <i className="fas fa-check-circle"></i> Thanh toán & Lưu
              </button>
              <button className={cx("btn", "btn-temp")} onClick={closeModal}>
                <i className="fas fa-times"></i> Đóng
              </button>
            </div>
          </div>

        </div>
      </div>
    </>
  );
}

export default CalculateModal;
