import React, { useEffect, useState } from "react";
import styles from "./ListRoomDetail.module.scss";
import classNames from "classnames/bind";
import { fetchRoomsList } from "../../../api";
import { editRoom } from "api";
import { useModal } from "component/Modal/ModalContext";
import AddRoom from "../AddRoom/AddRoom";
import HistoryRoom from "../History/HistoryRoom";

import { FaEdit, FaSearch } from "react-icons/fa";
import AjustRoom from "../AjustRoom/AjustRoom";

const cx = classNames.bind(styles);

function ListRoomDetail() {
  const { openModal, closeModal } = useModal();
  const [ListRoom, setListroom] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const itemsPerPage = 5;

  const loadHistory = async () => {
    try {
      const getRooms = await fetchRoomsList();
      const sortedRooms = getRooms.sort((a, b) => a.roomNumber - b.roomNumber);
      setListroom(sortedRooms);
    } catch (error) {
      console.error("Error loading rooms:", error);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const filteredRooms = ListRoom.filter(room =>
    String(room.roomNumber).includes(searchTerm)
  );

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredRooms.slice(indexOfFirstItem, indexOfLastItem);

  const nextPage = () => {
    if (currentPage < totalPages()) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const totalPages = () => {
    return Math.ceil(filteredRooms.length / itemsPerPage);
  };

  const handleEditRoom = async (roomID) => {
    try {
      const response = await editRoom(roomID, { deleted: true });
      if (response) {
        await loadHistory();
      }
    } catch (error) {
      console.error("Error deleting room:", error);
    }
  };

  const handleOpenAddRoom = () => {
    openModal(<AddRoom />);
  };

  const handleHistoryRoom = (roomNumber) => {
    openModal(<HistoryRoom roomNumber={roomNumber} />);
  };



  const handleOpenAdjustRoom = async (room) => {
    openModal(<AjustRoom room={room} />)
  };

  return (
    <div className={cx("listRoomContainer")}>
      <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
        <i className="fas fa-times"></i>
      </button>
      <h1 className={cx("title-table")}>Danh sách phòng cụ thể</h1>
      <div className={cx("control")}>
        <div className={cx("search-container")}>
          <FaSearch className={cx("search-icon")} />
          <input
            type="text"
            placeholder="Tìm kiếm số phòng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={cx("search-input")}
          />
        </div>
        <button onClick={handleOpenAddRoom} className={cx("add-room")}>
          Thêm phòng
        </button>

      </div>
      <div className={cx("roomGrid")}>
        {currentItems && currentItems.length > 0 ? (
          currentItems.map((item) => (
            <div key={item._id} className={cx("roomCard")}>
              <div className={cx("roomHeader")}>
                <span className={cx("roomNumber")}>Phòng {String(item.roomNumber).padStart(3, "0")}</span>
                <div className={cx("roomActions")}>
                  <button
                    onClick={() => handleOpenAdjustRoom(item)}
                    className={cx("actionBtn", "editBtn")}
                    title="Sửa phòng"
                  >
                    <FaEdit />
                  </button>
                  <button
                    onClick={() => handleEditRoom(item._id)}
                    className={cx("actionBtn", "deleteBtn")}
                    title="Xóa phòng"
                  >
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </div>
              </div>

              <div className={cx("roomDetails")}>
                <div className={cx("detailRow")}>
                  <span className={cx("label")}>Giá ngày:</span>
                  <span className={cx("value")}>{item.daily.toLocaleString()} VNĐ</span>
                </div>
                <div className={cx("detailRow")}>
                  <span className={cx("label")}>Giá giờ đầu:</span>
                  <span className={cx("value")}>{item.firstHour.toLocaleString()} VNĐ</span>
                </div>
                <div className={cx("detailRow")}>
                  <span className={cx("label")}>Giá giờ thêm:</span>
                  <span className={cx("value")}>{item.extraHour.toLocaleString()} VNĐ</span>
                </div>
              </div>

              <button
                onClick={() => handleHistoryRoom(item.roomNumber)}
                className={cx("historyButtonFull")}
              >
                <i className="fas fa-history"></i> Xem lịch sử thuê
              </button>
            </div>
          ))
        ) : (
          <div className={cx("no-data")}>Không có dữ liệu</div>
        )}
      </div>

      <div className={cx("pagination")}>
        <div className={cx("notification")}>
          <span>
            Trang {currentPage} / {totalPages()}
          </span>
        </div>
        <div className={cx("controls")}>
          <button onClick={prevPage} disabled={currentPage === 1}>
            Trang trước
          </button>
          <button onClick={nextPage} disabled={currentPage === totalPages()}>
            Trang sau
          </button>
        </div>
      </div>
    </div>
  );
}

export default ListRoomDetail;
