import React, { useState, useEffect } from "react";
import classNames from "classnames/bind";
import styles from "./SurchargeDateManager.module.scss";
import { fetchSurchargeDates, addSurchargeDateApi, deleteSurchargeDateApi, editSurchargeDateApi } from "api";
import { FaTrash, FaPlus, FaCalendarAlt, FaTimes, FaPen } from "react-icons/fa";
import { showWarning, showError, showSuccess } from "utils/toast";

const cx = classNames.bind(styles);

function SurchargeDateManager() {
    const [dates, setDates] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState({
        startDate: "",
        endDate: "",
        name: "",
        mode: "multiplier",
        multiplier: 1.5,
        fixedDaily: "",
        fixedFirstHour: "",
        fixedExtraHour: "",
        applyTo: "both",
    });
    const [loading, setLoading] = useState(false);

    const loadDates = async () => {
        try {
            const data = await fetchSurchargeDates();
            setDates(data || []);
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => {
        loadDates();
    }, []);

    const handleAdd = async () => {
        if (!form.startDate || !form.endDate || !form.name) {
            return showWarning("Vui lòng nhập đầy đủ thông tin!");
        }
        if (form.mode === "multiplier" && !form.multiplier) {
            return showWarning("Vui lòng chọn hệ số nhân!");
        }
        if (form.mode === "fixed" && !form.fixedDaily && !form.fixedFirstHour) {
            return showWarning("Vui lòng nhập số tiền cộng thêm!");
        }

        setLoading(true);
        try {
            if (editingId) {
                await editSurchargeDateApi(editingId, form);
            } else {
                await addSurchargeDateApi(form);
            }
            setForm({
                startDate: "", endDate: "", name: "", mode: "multiplier",
                multiplier: 1.5, fixedDaily: "", fixedFirstHour: "", fixedExtraHour: "", applyTo: "both",
            });
            setShowForm(false);
            setEditingId(null);
            await loadDates();
        } catch (err) {
            showError(err.message);
        }
        setLoading(false);
    };

    const handleEdit = (item) => {
        setEditingId(item._id);
        setForm({
            startDate: item.startDate,
            endDate: item.endDate,
            name: item.name,
            mode: item.mode,
            multiplier: item.multiplier || 1.5,
            fixedDaily: item.fixedDaily !== undefined && item.fixedDaily !== null ? item.fixedDaily : "",
            fixedFirstHour: item.fixedFirstHour !== undefined && item.fixedFirstHour !== null ? item.fixedFirstHour : "",
            fixedExtraHour: item.fixedExtraHour !== undefined && item.fixedExtraHour !== null ? item.fixedExtraHour : "",
            applyTo: item.applyTo || "both",
        });
        setShowForm(true);
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Bạn có chắc muốn xóa ngày phụ thu này?")) return;
        try {
            await deleteSurchargeDateApi(id);
            showSuccess("Xóa ngày phụ thu thành công!");
            await loadDates();
        } catch (err) {
            showError("Lỗi: " + err.message);
        }
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return "";
        const d = new Date(dateStr + "T00:00:00");
        return d.toLocaleDateString("vi-VN");
    };

    const getApplyLabel = (applyTo) => {
        switch (applyTo) {
            case "hourly": return "Theo giờ";
            case "daily": return "Theo ngày";
            default: return "Cả hai";
        }
    };
    const getModeLabel = (item) => {
        if (item.mode === "fixed") {
            const parts = [];
            if (item.fixedDaily !== "" && item.fixedDaily != null) parts.push(`Ngày: +${Number(item.fixedDaily).toLocaleString()}đ`);
            if (item.fixedFirstHour !== "" && item.fixedFirstHour != null) parts.push(`Giờ: +${Number(item.fixedFirstHour).toLocaleString()}đ`);
            if (item.fixedExtraHour !== "" && item.fixedExtraHour != null) parts.push(`Thêm giờ: +${Number(item.fixedExtraHour).toLocaleString()}đ`);
            return parts.join(" | ") || "Cộng thêm tiền cố định";
        }
        return `x${item.multiplier}`;
    };

    return (
        <div className={cx("manager")}>
            <div className={cx("header")}>
                <div className={cx("header-left")}>
                    <FaCalendarAlt className={cx("header-icon")} />
                    <h3>Quản lý ngày phụ thu</h3>
                </div>
                <button
                    className={cx("add-btn", { active: showForm })}
                    onClick={() => {
                        if (showForm) {
                            setEditingId(null);
                            setForm({
                                startDate: "", endDate: "", name: "", mode: "multiplier",
                                multiplier: 1.5, fixedDaily: "", fixedFirstHour: "", fixedExtraHour: "", applyTo: "both",
                            });
                        }
                        setShowForm(!showForm);
                    }}
                >
                    {showForm ? <FaTimes /> : <FaPlus />}
                    <span>{showForm ? "Đóng" : "Thêm mới"}</span>
                </button>
            </div >

            {showForm && (
                <div className={cx("form")}>
                    <div className={cx("form-grid")}>
                        <div className={cx("form-group")}>
                            <label>Từ ngày</label>
                            <input
                                type="date"
                                value={form.startDate}
                                onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                            />
                        </div>
                        <div className={cx("form-group")}>
                            <label>Đến ngày</label>
                            <input
                                type="date"
                                value={form.endDate}
                                onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                            />
                        </div>
                        <div className={cx("form-group", "full")}>
                            <label>Tên đợt phụ thu</label>
                            <input
                                type="text"
                                placeholder="VD: Lễ 30/4 - 1/5"
                                value={form.name}
                                onChange={(e) => setForm({ ...form, name: e.target.value })}
                            />
                        </div>
                        <div className={cx("form-group")}>
                            <label>Cách tính</label>
                            <select
                                value={form.mode}
                                onChange={(e) => setForm({ ...form, mode: e.target.value })}
                            >
                                <option value="multiplier">Nhân hệ số (x)</option>
                                <option value="fixed">Cộng tiền cố định (+)</option>
                            </select>
                        </div>
                        {form.mode === "multiplier" && (
                            <div className={cx("form-group")}>
                                <label>Áp dụng cho</label>
                                <select
                                    value={form.applyTo}
                                    onChange={(e) => setForm({ ...form, applyTo: e.target.value })}
                                >
                                    <option value="both">Cả giờ & ngày</option>
                                    <option value="hourly">Chỉ tính giờ</option>
                                    <option value="daily">Chỉ tính ngày</option>
                                </select>
                            </div>
                        )}
                    </div>

                    {/* Multiplier Mode */}
                    {form.mode === "multiplier" && (
                        <div className={cx("mode-section")}>
                            <label>Hệ số nhân</label>
                            <select
                                value={form.multiplier}
                                onChange={(e) => setForm({ ...form, multiplier: Number(e.target.value) })}
                            >
                                <option value={1.2}>x1.2 (+20%)</option>
                                <option value={1.5}>x1.5 (+50%)</option>
                                <option value={2.0}>x2.0 (+100%)</option>
                                <option value={2.5}>x2.5 (+150%)</option>
                                <option value={3.0}>x3.0 (+200%)</option>
                            </select>
                        </div>
                    )}

                    {/* Fixed Price Mode */}
                    {form.mode === "fixed" && (
                        <div className={cx("mode-section", "fixed-grid")}>
                            <div className={cx("form-group")}>
                                <label>Cộng thêm ngày (VNĐ)</label>
                                <input
                                    type="number"
                                    placeholder="VD: 50000"
                                    value={form.fixedDaily}
                                    onChange={(e) => setForm({ ...form, fixedDaily: e.target.value })}
                                />
                            </div>
                            <div className={cx("form-group")}>
                                <label>Cộng thêm giờ đầu (VNĐ)</label>
                                <input
                                    type="number"
                                    placeholder="VD: 20000"
                                    value={form.fixedFirstHour}
                                    onChange={(e) => setForm({ ...form, fixedFirstHour: e.target.value })}
                                />
                            </div>
                            <div className={cx("form-group")}>
                                <label>Cộng thêm thêm giờ (VNĐ)</label>
                                <input
                                    type="number"
                                    placeholder="VD: 10000"
                                    value={form.fixedExtraHour}
                                    onChange={(e) => setForm({ ...form, fixedExtraHour: e.target.value })}
                                />
                            </div>
                        </div>
                    )}

                    <button className={cx("submit-btn", { "btn-edit-mode": editingId })} onClick={handleAdd} disabled={loading}>
                        {loading ? "Đang lưu..." : editingId ? "Cập nhật phụ thu" : "Lưu đợt phụ thu"}
                    </button>
                </div>
            )
            }

            <div className={cx("list")}>
                {dates.length === 0 ? (
                    <div className={cx("empty")}>
                        <FaCalendarAlt size={32} />
                        <p>Chưa có ngày phụ thu nào</p>
                    </div>
                ) : (
                    dates.map((item) => (
                        <div className={cx("item")} key={item._id}>
                            <div className={cx("item-info")}>
                                <span className={cx("item-date")}>
                                    {formatDate(item.startDate)} → {formatDate(item.endDate)}
                                </span>
                                <span className={cx("item-name")}>{item.name}</span>
                            </div>
                            <div className={cx("item-meta")}>
                                <span className={cx("badge", item.mode === "fixed" ? "fixed" : "multiplier")}>
                                    {getModeLabel(item)}
                                </span>
                                <span className={cx("badge", "apply")}>{getApplyLabel(item.applyTo)}</span>
                            </div>
                            <div className={cx("item-actions")}>
                                <button className={cx("edit-btn-small")} onClick={() => handleEdit(item)}>
                                    <FaPen size={12} />
                                </button>
                                <button className={cx("delete-btn")} onClick={() => handleDelete(item._id)}>
                                    <FaTrash size={12} />
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div >
    );
}

export default SurchargeDateManager;
