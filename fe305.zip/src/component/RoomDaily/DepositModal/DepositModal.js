import React, { useState, useEffect } from "react";
import classNames from "classnames/bind";
import styles from "./DepositModal.module.scss";
import { depositRoom, checkRoomDeposit, deleteDeposit } from "../../../api";
import { showSuccess, showError, showWarning } from "../../../utils/toast";

const cx = classNames.bind(styles);

function DepositModal({ roomNumber, onClose, onDepositSuccess }) {
    const [depositAmount, setDepositAmount] = useState("");
    const [note, setNote] = useState("");
    const [status, setStatus] = useState("kept");
    const [loading, setLoading] = useState(false);
    const [existingDeposit, setExistingDeposit] = useState(null);
    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        const fetchDeposit = async () => {
            try {
                const response = await checkRoomDeposit(roomNumber);
                if (response && response.amount) {
                    setExistingDeposit(response);
                    setDepositAmount(response.amount);
                    setNote(response.note || "");
                    setStatus(response.status || "kept");
                    setIsEditing(false);
                }
            } catch (error) {
                // Có thể lờ đi nếu chưa có cọc
            }
        };
        fetchDeposit();
    }, [roomNumber]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!depositAmount || Number(depositAmount) <= 0) {
            return showWarning("Vui lòng nhập số tiền cọc hợp lệ!");
        }

        setLoading(true);
        try {
            const data = {
                roomName: roomNumber.toString(),
                amount: Number(depositAmount),
                status,
                note
            };

            await depositRoom(data);
            showSuccess(existingDeposit ? "Cập nhật cọc thành công!" : "Đặt cọc thành công!");
            if (onDepositSuccess) {
                onDepositSuccess();
            }
            onClose();
        } catch (error) {
            showError("Lỗi khi đặt cọc: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleDeleteDeposit = async () => {
        if (!window.confirm("Bạn có chắc chắn muốn xóa tiền cọc này không?")) return;
        setLoading(true);
        try {
            await deleteDeposit(roomNumber);
            showSuccess("Đã xóa tiền cọc thành công!");
            if (onDepositSuccess) {
                onDepositSuccess();
            }
            onClose();
        } catch (error) {
            showError("Lỗi xóa cọc: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className={cx("modal-overlay")} onClick={onClose}>
            <div className={cx("modal-content")} onClick={(e) => e.stopPropagation()}>
                <div className={cx("modal-header")}>
                    <h2>{existingDeposit ? "Đã Cọc Giữ Chỗ" : "Nhận Cọc Giữ Chỗ"} - Phòng {roomNumber}</h2>
                    <button className={cx("close-btn")} onClick={onClose}>&times;</button>
                </div>

                <div className={cx("modal-body")}>
                    {existingDeposit && !isEditing ? (
                        <div className={cx("deposit-form")}>
                            <div className={cx("warning-box")} style={{ background: 'rgba(16, 185, 129, 0.1)', borderColor: '#10b981' }}>
                                <i className="fas fa-check-circle" style={{ color: '#10b981' }}></i>
                                <p style={{ color: '#059669', fontWeight: 'bold' }}>Phòng này đã đóng tiền cọc giữ chỗ!</p>
                            </div>

                            <div className={cx("deposit-info")} style={{ background: '#f8fafc', padding: '20px', borderRadius: '12px', marginTop: '16px', border: '1px solid #e2e8f0' }}>
                                <p style={{ fontSize: '20px', fontWeight: '800', color: '#f59e0b', marginBottom: '12px' }}>
                                    Số tiền cọc: {Number(existingDeposit.amount).toLocaleString('vi-VN')} VNĐ
                                </p>
                                <p style={{ color: '#475569', fontSize: '14px', margin: '6px 0' }}><strong>Ngày nhận cọc:</strong> {new Date(existingDeposit.depositDate).toLocaleString('vi-VN')}</p>
                                {existingDeposit.note && <p style={{ color: '#475569', fontSize: '14px', margin: '6px 0' }}><strong>Ghi chú:</strong> {existingDeposit.note}</p>}
                                <p style={{ color: '#475569', fontSize: '14px', margin: '6px 0' }}>
                                    <strong>Trạng thái:</strong> {existingDeposit.status === 'kept' ? 'Đang giữ cọc' : existingDeposit.status === 'refunded' ? 'Đã hoàn trả' : 'Chưa hoàn / Mất cọc'}
                                </p>
                            </div>

                            <div className={cx("form-actions")} style={{ marginTop: '24px', display: 'flex', gap: '8px' }}>
                                <button type="button" className={cx("btn", "btn-secondary")} onClick={onClose} style={{ flex: 1 }}>
                                    Đóng
                                </button>
                                <button type="button" className={cx("btn")} style={{ flex: 1, background: '#ef4444', color: 'white', border: 'none', fontWeight: '600', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }} onClick={handleDeleteDeposit} disabled={loading}>
                                    {loading ? 'Đang xử lý...' : <><i className="fas fa-trash-alt"></i> Xóa cọc này</>}
                                </button>
                                <button type="button" className={cx("btn", "btn-primary")} onClick={() => setIsEditing(true)} style={{ flex: 1.5 }}>
                                    <i className="fas fa-edit"></i> Cập nhật
                                </button>
                            </div>
                        </div>
                    ) : existingDeposit && isEditing ? (
                        <form onSubmit={handleSubmit} className={cx("deposit-form")}>
                            <div className={cx("warning-box")} style={{ background: 'rgba(59, 130, 246, 0.1)', borderColor: '#3b82f6', color: '#2563eb', marginBottom: 16 }}>
                                <i className="fas fa-edit"></i>
                                <span>Chế độ điều chỉnh thông tin tiền cọc.</span>
                            </div>

                            <div className={cx("form-group")}>
                                <label>Số tiền đặt cọc (VNĐ)</label>
                                <input
                                    type="number"
                                    value={depositAmount}
                                    onChange={(e) => setDepositAmount(e.target.value)}
                                    className={cx("form-control")}
                                />
                            </div>

                            <div className={cx("form-group")}>
                                <label>Trạng thái cọc</label>
                                <select
                                    className={cx("form-control")}
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                >
                                    <option value="kept">Đang giữ cọc</option>
                                    <option value="refunded">Đã hoàn trả</option>
                                    <option value="lost">Chưa hoàn/Mất cọc</option>
                                </select>
                            </div>

                            <div className={cx("form-group")}>
                                <label>Ghi chú thêm</label>
                                <textarea
                                    value={note}
                                    onChange={(e) => setNote(e.target.value)}
                                    className={cx("form-control")}
                                    rows="3"
                                ></textarea>
                            </div>

                            <div className={cx("form-actions")} style={{ marginTop: '24px', display: 'flex', gap: '8px' }}>
                                <button type="button" className={cx("btn", "btn-secondary")} onClick={() => setIsEditing(false)} style={{ flex: 1 }}>
                                    Hủy
                                </button>
                                <button type="submit" className={cx("btn", "btn-primary")} disabled={loading} style={{ flex: 1.5 }}>
                                    {loading ? 'Đang lưu...' : 'Lưu lại'}
                                </button>
                            </div>
                        </form>
                    ) : (
                        <form onSubmit={handleSubmit} className={cx("deposit-form")}>
                            <div className={cx("form-group")}>
                                <label>Số tiền đặt cọc (VNĐ) <span className={cx("required")}>*</span></label>
                                <input
                                    type="number"
                                    placeholder="Ví dụ: 500000"
                                    value={depositAmount}
                                    onChange={(e) => setDepositAmount(e.target.value)}
                                    className={cx("form-control")}
                                />
                            </div>
                            <div className={cx("form-group")}>
                                <label>Ghi chú thêm</label>
                                <textarea
                                    placeholder="Ghi chú (tùy chọn)..."
                                    value={note}
                                    onChange={(e) => setNote(e.target.value)}
                                    className={cx("form-control")}
                                    rows="3"
                                ></textarea>
                            </div>
                            <div className={cx("form-actions")}>
                                <button type="button" className={cx("btn", "btn-secondary")} onClick={onClose}>
                                    Hủy
                                </button>
                                <button type="submit" className={cx("btn", "btn-primary")} disabled={loading}>
                                    {loading ? 'Đang xử lý...' : 'Xác nhận cọc'}
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
}

export default DepositModal;
