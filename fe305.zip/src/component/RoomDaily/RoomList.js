import React, { useState, useEffect, useRef } from "react";
import Room from "./Room";
import {
  fetchRoomsList,
  editRoom,
  fetchSurchargeDates,
  saveRoomHistory,
  deleteRoomData,
  deleteNoteWater,
  fetchNoteList
} from "../../api";
import classNames from "classnames/bind";
import styles from "./Room.module.scss";
import { convertToStandardDateFormat } from "../dateUtils";
import { useModal } from "../Modal/ModalContext";
import CalculateModal from "./CalculateModal";
import { calculateRoomFee } from "./utils/calculateRoomFee";
import SurchargeDateManager from "./SurchargeDateManager";
import { FaCalendarAlt, FaCalculator } from "react-icons/fa";
import ConfirmModal from '../Modal/ConfirmModal';
import { showError } from "utils/toast";

const cx = classNames.bind(styles);

// Component hiển thị modal tính gộp
const BatchCalculateModal = ({ results, errors, onClose, onSuccess }) => {
  const [isSaving, setIsSaving] = useState(false);
  const [waterNotes, setWaterNotes] = useState([]);
  const [isLoadingWater, setIsLoadingWater] = useState(true);
  const { openModal, closeModal } = useModal();

  useEffect(() => {
    const fetchWater = async () => {
      try {
        const res = await fetchNoteList();
        setWaterNotes(res?.data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoadingWater(false);
      }
    };
    fetchWater();
  }, []);

  const handleSaveAll = async () => {
    openModal(
      <ConfirmModal
        title="Thanh toán gộp"
        message={`Bạn có chắc muốn thanh toán và lưu dữ liệu cho ${results.length} phòng?`}
        onConfirm={async () => {
          setIsSaving(true);
          try {
            for (const r of results) {
              const waterNote = waterNotes.find(n => n.SoPhong === r.roomNumber);
              let waterTotal = 0;
              let waterDetails = [];
              if (waterNote && Array.isArray(waterNote.nuocuong)) {
                waterTotal = waterNote.nuocuong.reduce((sum, item) => sum + item.soLuong * item.unitprice, 0);
                waterDetails = waterNote.nuocuong;
              }

              if (r.ref?.current && r.ref.current[r.roomNumber]) {
                const refs = r.ref.current[r.roomNumber];
                if (refs.checkindate) refs.checkindate.value = "";
                if (refs.checkintime) refs.checkintime.value = "";
                if (refs.checkoutdate) refs.checkoutdate.value = "";
                if (refs.checkouttime) refs.checkouttime.value = "";
              }

              const historyData = {
                ...(r.objectDatatoSaveHistory || {}),
                waterTotal: waterTotal || "",
                waterDetails: waterDetails || "",
              };

              const fullTotal = r.total + waterTotal - (r.deposit || 0);
              historyData.totalAmount = fullTotal.toLocaleString();

              await deleteNoteWater(r.roomNumber);
              await deleteRoomData(r.roomNumber);
              await saveRoomHistory(r.roomNumber, historyData);
            }
            onSuccess();
            onClose();
          } catch (err) {
            console.error(err);
            showError("Lỗi khi lưu dữ liệu tính tiền gộp");
          } finally {
            setIsSaving(false);
          }
        }}
      />
    );
  };

  const getWaterTotal = (roomNum) => {
    const note = waterNotes.find(n => n.SoPhong === roomNum);
    if (!note || !Array.isArray(note.nuocuong)) return 0;
    return note.nuocuong.reduce((sum, item) => sum + item.soLuong * item.unitprice, 0);
  };

  const getSubTotal = (r) => r.total + getWaterTotal(r.roomNumber) - (r.deposit || 0);
  const grandTotal = results.reduce((sum, r) => sum + getSubTotal(r), 0);

  return (
    <div style={{ margin: "-24px", overflow: "hidden", borderRadius: "12px", background: "var(--background-color)" }}>
      <div style={{
        background: "linear-gradient(135deg, #667eea, #764ba2)",
        color: "#fff",
        padding: "20px 24px",
        textAlign: "center"
      }}>
        <h3 style={{ margin: "0 0 4px", fontSize: 18, fontWeight: 700 }}>TÍNH TIỀN GỘP & THANH TOÁN</h3>
        <span style={{ fontSize: 14, opacity: 0.9 }}>{results.length} phòng</span>
      </div>

      <div style={{ padding: "16px 24px", maxHeight: "60vh", overflowY: "auto" }}>
        {results.map((r, i) => {
          const wTotal = getWaterTotal(r.roomNumber);
          const rDeposit = r.deposit || 0;
          return (
            <div key={i} style={{
              padding: "12px 16px",
              marginBottom: 10,
              borderRadius: 12,
              border: "1px solid var(--border-color)",
              background: "var(--background-color)"
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <strong style={{ fontSize: 15 }}>Phòng {r.roomNumber}</strong>
                <span style={{ fontSize: 16, fontWeight: 700, color: "#667eea" }}>
                  {(r.total + wTotal - rDeposit).toLocaleString()} VNĐ
                </span>
              </div>
              <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>
                {r.notes.map((n, j) => <div key={j}>{n}</div>)}
              </div>
              {wTotal > 0 && (
                <div style={{ fontSize: 12, color: "#059669", marginTop: 4, fontWeight: 600 }}>
                  💦 Nước uống: +{wTotal.toLocaleString()}đ {isLoadingWater && "..."}
                </div>
              )}
              {rDeposit > 0 && (
                <div style={{ fontSize: 12, color: "#d97706", marginTop: 4, fontWeight: 600 }}>
                  💰 Đã cọc: -{rDeposit.toLocaleString()}đ
                </div>
              )}
              {r.surchargeNotes && r.surchargeNotes.length > 0 && (
                <div style={{ fontSize: 12, color: "#f5576c", marginTop: 4 }}>
                  {r.surchargeNotes.map((n, j) => <div key={j}>{n}</div>)}
                </div>
              )}
            </div>
          );
        })}

        {errors.length > 0 && (
          <div style={{ padding: 12, background: "rgba(239,68,68,0.08)", borderRadius: 10, marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#ef4444", marginBottom: 4 }}>Không thể tính ({errors.length}):</div>
            {errors.map((e, i) => <div key={i} style={{ fontSize: 12, color: "#ef4444" }}>{e}</div>)}
          </div>
        )}
      </div>

      <div style={{
        padding: "16px 24px",
        borderTop: "2px solid #667eea",
        background: "var(--background-color)",
        borderRadius: "0 0 12px 12px"
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <span style={{ fontSize: 16, fontWeight: 700 }}>TỔNG CỘNG TẤT CẢ</span>
          <div style={{ fontSize: 22, fontWeight: 800, color: "#667eea" }}>
            {grandTotal.toLocaleString()} VNĐ
          </div>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={onClose}
            disabled={isSaving}
            style={{
              flex: 1, padding: "12px", borderRadius: 10, border: "1px solid var(--border-color)",
              background: "var(--surface-color)", fontWeight: 600, cursor: "pointer"
            }}
          >
            Đóng
          </button>
          <button
            onClick={handleSaveAll}
            disabled={isSaving || results.length === 0}
            style={{
              flex: 2, padding: "12px", borderRadius: 10, border: "none",
              background: "linear-gradient(135deg, #10b981, #059669)", color: "#fff",
              fontWeight: 700, cursor: "pointer", opacity: (isSaving || results.length === 0) ? 0.7 : 1
            }}
          >
            {isSaving ? "Đang lưu..." : "Thanh toán & Lưu dữ liệu"}
          </button>
        </div>
      </div>
    </div>
  );
};

const RoomList = () => {
  const [rooms, setRooms] = useState([]);
  const [backUpRoom, setBackUpRoom] = useState([]);
  const [selectedRooms, setSelectedRooms] = useState([]);
  const [surchargeDates, setSurchargeDates] = useState([]);
  const [activeTab, setActiveTab] = useState("all"); // "all", "occupied", "empty", "surcharge"
  const { openModal, closeModal } = useModal();

  // Shared ref chứa tất cả checkDateRef input từ tất cả Room
  const sharedCheckDateRef = useRef({});

  const loadData = async (currentTab = activeTab) => {
    const [fetchedRooms, fetchedSurcharges] = await Promise.all([
      fetchRoomsList(),
      fetchSurchargeDates().catch(() => []),
    ]);
    const sortedRooms = fetchedRooms.sort(
      (a, b) => a.roomNumber - b.roomNumber
    );
    setBackUpRoom(sortedRooms);
    setSurchargeDates(fetchedSurcharges || []);

    if (currentTab === "occupied") {
      setRooms(sortedRooms.filter((item) => item.checkInDate));
    } else if (currentTab === "empty") {
      setRooms(sortedRooms.filter((item) => !item.checkInDate));
    } else {
      setRooms(sortedRooms);
    }
  };

  useEffect(() => {
    loadData(activeTab);
  }, []);

  const handleInputChange = async (roomNumber, data) => {
    let date;
    if (data.type === "checkTimeDate") {
      date = data.date + " " + data.value;
    } else {
      date = data.value + " " + data.time;
    }
    await editRoom(String(roomNumber), { checkInDate: date });
  };

  const setCurrentTime = async (type, roomNumber, ref) => {
    const now = new Date();
    const dateStr = now.toLocaleDateString("vi-VN");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const timeStr = `${hours}:${minutes}`;

    const dateStrBK = convertToStandardDateFormat(dateStr, timeStr);

    if (type === "checkin") {
      const checkinDateInput = ref.current[roomNumber]["checkindate"];
      const checkinTimeInput = ref.current[roomNumber]["checkintime"];

      if (checkinDateInput && checkinDateInput._flatpickr) {
        checkinDateInput.value = dateStr;
        checkinDateInput._flatpickr.setDate(dateStr, true, "d-m-Y");
      }

      if (checkinTimeInput && checkinTimeInput._flatpickr) {
        checkinTimeInput.value = timeStr;
        checkinTimeInput._flatpickr.setDate(timeStr, true, "H:i");
      }

      const response = await editRoom(String(roomNumber), {
        checkInDate: dateStrBK,
      });
      if (response) return loadData();
    } else {
      const checkoutDateInput = ref.current[roomNumber]["checkoutdate"];
      const checkoutTimeInput = ref.current[roomNumber]["checkouttime"];

      if (checkoutDateInput && checkoutDateInput._flatpickr) {
        checkoutDateInput.value = dateStr;
        checkoutDateInput._flatpickr.setDate(dateStr, true, "d-m-Y");
      }

      if (checkoutTimeInput && checkoutTimeInput._flatpickr) {
        checkoutTimeInput.value = timeStr;
        checkoutTimeInput._flatpickr.setDate(timeStr, true, "H:i");
      }
    }
  };

  const handleCalculate = async (data) => {
    // Load fresh surcharge dates before calculating to avoid stale configs
    const currentSurcharges = await fetchSurchargeDates().catch(() => []);
    setSurchargeDates(currentSurcharges);

    const result = calculateRoomFee(data.roomNumber, data.checkDateRef, rooms, currentSurcharges);

    if (result.error) {
      return openModal(<p style={{ textAlign: "center" }}>{result.error}</p>);
    }

    const calculateData = {
      ...result,
      roomNumber: data.roomNumber,
      ref: data.checkDateRef
    };

    openModal(<CalculateModal data={calculateData} onSuccess={() => { closeModal(); loadData(); }} />);
  };

  // Tính tiền gộp cho nhiều phòng
  const handleBatchCalculate = async () => {
    if (selectedRooms.length === 0) return;

    // Load fresh surcharge dates
    const currentSurcharges = await fetchSurchargeDates().catch(() => []);
    setSurchargeDates(currentSurcharges);

    // Tự động set giờ trả phòng bằng thời gian hiện tại
    const now = new Date();
    const dateStr = now.toLocaleDateString("vi-VN");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const timeStr = `${hours}:${minutes}`;

    selectedRooms.forEach((roomNumber) => {
      if (sharedCheckDateRef.current[roomNumber]) {
        const checkoutDateInput = sharedCheckDateRef.current[roomNumber]["checkoutdate"];
        const checkoutTimeInput = sharedCheckDateRef.current[roomNumber]["checkouttime"];

        if (checkoutDateInput && checkoutDateInput._flatpickr) {
          checkoutDateInput.value = dateStr;
          checkoutDateInput._flatpickr.setDate(dateStr, true, "d-m-Y");
        }

        if (checkoutTimeInput && checkoutTimeInput._flatpickr) {
          checkoutTimeInput.value = timeStr;
          checkoutTimeInput._flatpickr.setDate(timeStr, true, "H:i");
        }
      }
    });

    const results = [];
    const errors = [];

    // Tính tiền
    selectedRooms.forEach((roomNumber) => {
      if (!sharedCheckDateRef.current[roomNumber]) {
        errors.push(`Phòng ${roomNumber}: Không tìm thấy dữ liệu input`);
        return;
      }

      const result = calculateRoomFee(roomNumber, sharedCheckDateRef, rooms, currentSurcharges);

      if (result.error) {
        errors.push(`Phòng ${roomNumber}: ${result.error}`);
      } else {
        results.push({
          ...result,
          roomNumber,
          ref: sharedCheckDateRef
        });
      }
    });

    openModal(
      <BatchCalculateModal
        results={results}
        errors={errors}
        onClose={closeModal}
        onSuccess={() => { closeModal(); loadData(); }}
      />
    );
  };

  const handleSelectTab = (tab) => {
    setActiveTab(tab);
    loadData(tab);
  };

  const handleRoomSelect = (roomNumber) => {
    setSelectedRooms((prev) =>
      prev.includes(roomNumber)
        ? prev.filter((r) => r !== roomNumber)
        : [...prev, roomNumber]
    );
  };

  const handleSelectAll = () => {
    const occupiedRooms = rooms.filter((r) => r.checkInDate).map((r) => r.roomNumber);
    setSelectedRooms(occupiedRooms);
  };

  const handleDeselectAll = () => {
    setSelectedRooms([]);
  };

  const occupiedCount = backUpRoom.filter((r) => r.checkInDate).length;
  const emptyCount = backUpRoom.filter((r) => !r.checkInDate).length;

  return (
    <div className={cx("room-management-layout")}>
      {/* Modern Tab Bar */}
      <div className={cx("tabs-container")}>
        <div className={cx("tabs")}>
          <div className={cx("tabs-group")}>
            <button
              className={cx("tab-btn", { active: activeTab === "all" })}
              onClick={() => handleSelectTab("all")}
            >
              Tất cả phòng <span className={cx("badge")}>{backUpRoom.length}</span>
            </button>
            <button
              className={cx("tab-btn", { active: activeTab === "occupied" })}
              onClick={() => handleSelectTab("occupied")}
            >
              Có khách <span className={cx("badge", "occupied")}>{occupiedCount}</span>
            </button>
            <button
              className={cx("tab-btn", { active: activeTab === "empty" })}
              onClick={() => handleSelectTab("empty")}
            >
              Phòng trống <span className={cx("badge", "empty")}>{emptyCount}</span>
            </button>
          </div>
          <div className={cx("tabs-group")}>
            <button
              className={cx("tab-btn")}
              onClick={() => openModal(<SurchargeDateManager />)}
            >
              <FaCalendarAlt style={{ marginRight: 6 }} /> Cài đặt Phụ thu
            </button>
          </div>
        </div>
      </div>

      <div className={cx("main-contentArea")}>
        <>
          {selectedRooms.length > 0 && (
            <div className={cx("batchToolbar")}>
              <span className={cx("batchInfo")}>
                Đã chọn <strong>{selectedRooms.length}</strong> phòng
              </span>
              <button className={cx("batchBtn", "batchCalcBtn")} onClick={handleBatchCalculate}>
                <FaCalculator style={{ marginRight: 6 }} /> Tính gộp & Thanh toán
              </button>
              <button className={cx("batchBtn", "selectAllBtn")} onClick={handleSelectAll}>
                Chọn tất cả {activeTab === "all" ? "có khách" : ""}
              </button>
              <button className={cx("batchBtn", "deselectAllBtn")} onClick={handleDeselectAll}>
                Bỏ chọn
              </button>
            </div>
          )}

          <div className={cx("roomList")}>
            {rooms && rooms.length > 0 ? (
              rooms.map((room) => (
                <Room
                  key={room.roomNumber}
                  room={room}
                  handleInputChange={handleInputChange}
                  setCurrentTime={setCurrentTime}
                  calculate={handleCalculate}
                  isSelected={selectedRooms.includes(room.roomNumber)}
                  onSelect={handleRoomSelect}
                  sharedRef={sharedCheckDateRef}
                  onUpdate={loadData}
                />
              ))
            ) : (
              <div className={cx("empty-state")}>
                <p>Không có phòng nào trong mục này</p>
              </div>
            )}
          </div>
        </>
      </div>
    </div>
  );
};

export default RoomList;
