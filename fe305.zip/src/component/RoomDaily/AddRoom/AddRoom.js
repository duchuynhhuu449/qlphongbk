import React, { useState } from "react";
import styles from "./AddRoom.module.scss";
import classNames from "classnames/bind";
import { addRoom } from "api";
import { useModal } from "component/Modal/ModalContext";

const cx = classNames.bind(styles);

function AddRoom() {
  const [data, setData] = useState({
    roomNumber: "",
    dailyprice: "",
    firstHour: "",
    extraHour: ""
  });
  const { closeModal } = useModal();
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const handleAddRoom = async (event) => {
    const { roomNumber, dailyprice, firstHour, extraHour } = data;

    if (!roomNumber || !dailyprice || !firstHour || !extraHour) {
      setMessage("Vui lòng nhập đầy đủ thông tin!");
      setMessageType("error");
      return;
    }

    try {
      const response = await addRoom(data);
      if (response) {
        setMessage("Thêm phòng thành công!");
        setMessageType("success");
        // Reset form
        setData({
          roomNumber: "",
          dailyprice: "",
          firstHour: "",
          extraHour: ""
        });
      }
    } catch (error) {
      console.error(error);
      setMessage(error.message || "Có lỗi xảy ra khi thêm phòng!");
      setMessageType("error");
    }
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setData(prev => ({ ...prev, [id]: value }));
  };

  return (
    <div className={cx("container")}>
      <button className={cx("btn-close-modal")} onClick={closeModal} title="Đóng">
        <i className="fas fa-times"></i>
      </button>
      <h2 className={cx("title")}>Thêm Phòng Mới</h2>
      <form className={cx("form")} id="roomForm">
        <div className={cx("row")}>
          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="roomNumber">Số phòng:</label>
            <input
              value={data.roomNumber}
              onChange={handleInputChange}
              type="number"
              id="roomNumber"
              required
              className={cx("input")}
              placeholder="Nhập số phòng"
            />
          </div>

          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="dailyprice">Giá phòng ngày:</label>
            <input
              value={data.dailyprice}
              onChange={handleInputChange}
              type="number"
              id="dailyprice"
              required
              className={cx("input")}
              placeholder="Nhập giá phòng ngày"
            />
          </div>
        </div>

        <div className={cx("row")}>
          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="firstHour">Giờ đầu tiên:</label>
            <input
              value={data.firstHour}
              onChange={handleInputChange}
              type="number"
              id="firstHour"
              required
              className={cx("input")}
              placeholder="Nhập giá giờ đầu tiên"
            />
          </div>

          <div className={cx("formGroup")}>
            <label className={cx("label")} htmlFor="extraHour">Giá thêm giờ:</label>
            <input
              value={data.extraHour}
              onChange={handleInputChange}
              type="number"
              id="extraHour"
              required
              className={cx("input")}
              placeholder="Nhập giá thêm giờ"
            />
          </div>
        </div>

        <div className={cx("control")}>
          <button
            type="button"
            onClick={handleAddRoom}
            className={cx("button")}
          >
            Thêm Phòng
          </button>
        </div>
      </form>
      {message && (
        <p className={cx("message", messageType)}>{message}</p>
      )}
    </div>
  );
}

export default AddRoom;

