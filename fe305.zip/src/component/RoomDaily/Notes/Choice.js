import React from "react";
import classNames from "classnames/bind";
import styles from "./Choice.module.scss";

const cx = classNames.bind(styles);

function Choice({ setChoice }) {
    return (
      <div className={cx("choice")}>
        <div onClick={() => setChoice(1)} className={cx("item")}>Viết ghi chú</div>
        <div onClick={() => setChoice(2)} className={cx("item")}>Ghi chú nước</div>
      </div>
    );
  }
  
  export default Choice;