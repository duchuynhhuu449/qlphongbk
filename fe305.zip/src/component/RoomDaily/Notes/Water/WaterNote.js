import React, { useState, useEffect } from "react";
import classNames from "classnames/bind"; // Nếu dùng thư viện cx
import styles from "./WaterNote.module.scss";
import { fetchBannuocProducts, fetchNoteList, addWaterNote, deleteNoteWater, deleteNoteWaterDetails } from "api";
import { VNDFormatter } from "component/VNDFormatter";
import { showError } from "utils/toast";

const cx = classNames.bind(styles);

function WaterNote({ room }) {
  const [data, setData] = useState([]);
  const [noteListData, setNote] = useState([]);
  const [isGuideExpanded, setIsGuideExpanded] = useState(false);

  useEffect(() => {
    const fetchWater = async () => {
      try {
        const response = await fetchBannuocProducts();
        const response2 = await fetchNoteList();
        if (response && response2) {
          setNote(response2.data);
          const notes = response2.data;
          // Lấy danh sách nước của phòng hiện tại

          const roomNote = notes.find((item) => item.SoPhong == room);

          const roomWaterList = roomNote?.nuocuong || [];

          const formatted = response.map((item) => {
            const selectedWater = roomWaterList.find(
              (w) => w.tenNuoc === item.name
            );

            return {
              name: item.name,
              checked: selectedWater ? true : false,
              quantity: selectedWater ? selectedWater.soLuong || 1 : 1,
              unitprice: item.price || 0,
              price: selectedWater ? selectedWater.gia : item.price, // an toàn hơn,
            };
          });

          setData(formatted);
        }
      } catch (error) {
        console.error("Error fetching water data:", error);
        setData([]);
      }
    };
    fetchWater();
  }, [room]);

  const handleSelect = async (index, e) => {
    // Kiểm tra nếu click vào input, select hoặc label thì không xử lý
    if (
      e.target.tagName === "INPUT" ||
      e.target.tagName === "SELECT" ||
      e.target.tagName === "LABEL" ||
      e.target.closest(".details")
    ) {
      return;
    }

    const updated = [...data];
    updated[index].checked = !updated[index].checked;

    if (updated[index].checked) {
      updated[index].price = updated[index].unitprice * updated[index].quantity;
    }

    // Eager update UI
    setData(updated);

    // Backend call
    if (!updated[index].checked) {
      const object = {
        SoPhong: room,
        drinkName: updated[index].name
      }
      try {
        await deleteNoteWaterDetails(object);
      } catch (err) {
        console.error(err);
      }
    } else {
      handleAddNote(updated, index);
    }
  };

  const handleAddNote = async (currentData, index) => {
    const dataNotes = {
      SoPhong: room,
      nuocuong: {
        tenNuoc: currentData[index].name,
        soLuong: currentData[index].quantity,
        gia: currentData[index].price,
        unitprice: currentData[index].unitprice
      },
    };
    try {
      await addWaterNote(dataNotes);
    } catch (error) {
      showError(error.message || error);
    }
  };

  const handleQuantityChange = (index, value, e) => {
    e.stopPropagation();
    const updated = [...data];
    updated[index].quantity = parseInt(value, 10) || 1;
    updated[index].price = updated[index].unitprice * updated[index].quantity;
    setData(updated);
    handleAddNote(updated, index);
  };

  const handlePriceChange = (index, value, e) => {
    e.stopPropagation();
    const updated = [...data];
    setData(updated);
  };

  return (
    <div className={cx("waterNoteContainer")}>
      <h2
        className={cx("title")}
        onClick={() => setIsGuideExpanded(!isGuideExpanded)}
      >
        Quản lý nước
        <span className={cx("icon", { expanded: isGuideExpanded })}>▼</span>
      </h2>

      <div className={cx("guide", { collapsed: !isGuideExpanded })}>
        <h3>Hướng dẫn sử dụng:</h3>
        <ul>
          <li>
            <strong>Chọn loại nước:</strong> Nhấn vào tên loại nước để chọn/bỏ
            chọn. Khi chọn, ô vuông bên phải sẽ hiển thị dấu tích.
          </li>
          <li>
            <strong>Nhập số lượng:</strong> Sau khi chọn, nhập số lượng nước cần
            tính tiền vào ô "Số lượng".
          </li>
          <li>
            <strong>Chọn đơn giá:</strong> Chọn giá tiền cho mỗi đơn vị nước từ
            danh sách có sẵn.
          </li>
          <li>
            <strong>Tổng tiền:</strong> Hệ thống sẽ tự động tính tổng tiền dựa
            trên số lượng và đơn giá đã chọn.
          </li>
          <li>
            <strong>Lưu ý:</strong> Dữ liệu sẽ tự động được lưu khi có thay đổi.
            Bạn có thể thay đổi số lượng hoặc đơn giá bất kỳ lúc nào.
          </li>
        </ul>
      </div>

      <div className={cx("waterNote")}>
        {data.map((item, index) => (
          <div
            key={index}
            className={cx("waterItem", { selected: item.checked })}
            onClick={(e) => handleSelect(index, e)}
          >
            <div className={cx("waterCheckbox", { checked: item.checked })} />

            <div className={cx("waterItemName")}>{item.name}</div>

            {item.checked && (
              <div
                className={cx("waterDetails")}
                onClick={(e) => e.stopPropagation()}
              >
                <div className={cx("waterInputRow")}>
                  <label htmlFor={`quantity-${index}`}>Số lượng:</label>
                  <input
                    id={`quantity-${index}`}
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) =>
                      handleQuantityChange(index, e.target.value, e)
                    }
                    className={cx("quantityInput")}
                  />
                </div>

                <div className={cx("waterInputRow")}>
                  <label htmlFor={`price-${index}`}>Giá tiền:</label>
                  <select
                    id={`price-${index}`}
                    value={item.unitprice}
                    onChange={(e) => handlePriceChange(index, e)}
                  >
                    <option value={item.unitprice}>
                      {VNDFormatter(item.unitprice)}/1 số lượng
                    </option>
                  </select>
                </div>
                <span>Tổng tiền: {VNDFormatter(item.price)}đ</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default WaterNote;
