import React, { useState } from "react";
import classNames from "classnames/bind";
import styles from "./Note.module.scss";

const cx = classNames.bind(styles);

function Note({handleNote}) {
  const [write, setWrite] = useState()
  return (
    <>
      <div className={cx("noteContainer")}>
        <div className={cx("noteForm")}>
          <div className={cx("noteFormGroup")}>
            <textarea
              onChange={(e) => setWrite(e.target.value)}
              placeholder="Nhập ghi chú muốn ghi"
              className={cx("noteTextarea")}
            ></textarea>
            <button onClick={() => handleNote(write)} className={cx("noteButton")}>Thêm vào</button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Note;
