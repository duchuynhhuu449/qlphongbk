import React from "react";
import classNames from "classnames/bind";
import styles from "./Choice.module.scss";

const cx = classNames.bind(styles);

function Choice({ setChoice }) {
    return (
      <div className={cx("choiceContainer")}>
        <div onClick={() => setChoice(1)} className={cx("choiceItem")}>Viết ghi chú</div>
        <div onClick={() => setChoice(2)} className={cx("choiceItem")}>Ghi chú nước</div>
      </div>
    );
  }
  
  export default Choice;