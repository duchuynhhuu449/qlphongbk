import React, { useState } from "react";
import classNames from "classnames/bind";
import styles from "./Note.module.scss";

const cx = classNames.bind(styles);

function Note({handleNote}) {
  const [write, setWrite] = useState()
  return (
    <>
      <div className={cx("note")}>
        <div className={cx("form")}>
          <div className={cx("form-group")}>
            <textarea
              onChange={(e) => setWrite(e.target.value)}
              placeholder="Nhập ghi chú muốn ghi"
              className={cx("textarea")}
            ></textarea>
            <button onClick={() => handleNote(write)} className={cx("btn")}>Thêm vào</button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Note;
