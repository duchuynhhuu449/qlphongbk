import React, { useEffect, useState } from "react";
import classNames from "classnames/bind";
import styles from "./Notes.module.scss";
import Note from "./Note/Note";
import Choice from "./Choice/Choice";
import WaterNote from "./Water/WaterNote";
const cx = classNames.bind(styles);

function Notes({ room }) {
  const [choice, setChoice] = useState(2);

  const handleNote = (data) => {
    if (choice === 1) {
      const prev = JSON.parse(localStorage.getItem("notes")) || [];

      const index = prev.findIndex((item) => item.room === room.roomNumber);

      if (index !== -1) {
        // Nếu đã có note cho phòng này, nối thêm nội dung mới (nếu có)
        prev[index].note = `${prev[index].note},${data}`;
      } else {
        // Nếu chưa có, thêm mới
        prev.push({ room: room.roomNumber, note: data });
      }

      localStorage.setItem("notes", JSON.stringify(prev));
    }
  };

  return (
    <>
      <div className={cx("container")}>
        {choice == 0 && <Choice setChoice={setChoice} />}
        {choice == 1 && <Note handleNote={handleNote} />}
        {choice == 2 && <WaterNote room={room}/>}
      </div>
    </>
  );
}

export default Notes;
