import React, { useState, useEffect } from "react";
import classNames from "classnames/bind"; // Nếu dùng thư viện cx
import styles from "./WaterNote.module.scss";
import { fetchBannuocProducts } from "api";
import { VNDFormatter } from "component/VNDFormatter";

const cx = classNames.bind(styles);

function WaterNote({ room }) {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchWater = async () => {
      const response = await fetchBannuocProducts();
      if (response) {
        const formatted = response.map((item) => ({
          name: item.name,
          checked: false,
          quantity: 1,
          unitprice: item.price || 5000,
          price: 0,
        }));
        setData(formatted);
      }
    };
    fetchWater();
  }, []);

  const handleSelect = (index) => {
    const updated = [...data];
    updated[index].checked = !updated[index].checked;
    if (!updated[index].checked) {
      updated[index].quantity = 1;
      updated[index].unitprice = 0;
      updated[index].price = 0;
    }
    setData(updated);
  };

  const handleQuantityChange = (index, value) => {
    const updated = [...data];
    updated[index].quantity = parseInt(value, 10) || 1; // Đảm bảo giá trị nhập là số nguyên
    setData(updated);
    handlePriceChange(index, updated[index].unitprice);
  };

  const handlePriceChange = (index, value) => {
    const updated = [...data];
    updated[index].unitprice = value;
    updated[index].price = updated[index].quantity * Number(value);
    setData(updated);
    handleNote(index, room);
  };

  const handleNote = (position, room) => {
    const prev = JSON.parse(localStorage.getItem("notes")) || [];

    const selected = data
      .filter(item => item.checked)
      .map(item => ({
        name: item.name,
        soluong: item.quantity,
        price: item.price,
      }));

    const index = prev.findIndex(item => item.room === room);

    if (index !== -1) {
      // Nếu đã có phòng
      if (!Array.isArray(prev[index].water)) {
        prev[index].water = [];
      }

      selected.forEach(sel => {
        const existIndex = prev[index].water.findIndex(w => w.name === sel.name);
        if (existIndex !== -1) {
          // Nếu nước đã tồn tại, cập nhật lại số lượng và giá
          prev[index].water[existIndex].soluong = sel.soluong;
          prev[index].water[existIndex].price = sel.price;
        } else {
          // Nếu chưa có, thêm mới
          prev[index].water.push(sel);
        }
      });
    } else {
      // Nếu chưa có phòng, thêm mới
      prev.push({ room, water: selected });
    }

    localStorage.setItem("notes", JSON.stringify(prev));
  };



  return (
    <div className={cx("water-note-container")}>
      <div className={cx("water-note")}>
        {data.map((item, index) => (
          <div
            onClick={(e) => handleSelect(index)}
            key={index}
            className={cx("item", { selected: item.checked })}
          >
            <div className={cx("checkbox-container")}>
              <input
                type="hidden"
                checked={item.checked}
                onChange={() => handleSelect(index)}
              />
            </div>

            <div onClick={() => handleSelect(index)} className={cx("name")}>
              {item.name}
            </div>

            {item.checked && (
              <div
                className={cx("details")}
                onClick={(e) => e.stopPropagation()}
              >
                <div className={cx("input-row")}>
                  <label htmlFor={`quantity-${index}`}>Số lượng:</label>
                  <input
                    id={`quantity-${index}`}
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) =>
                      handleQuantityChange(index, e.target.value)
                    }
                  />
                </div>

                <div className={cx("input-row")}>
                  <label htmlFor={`price-${index}`}>Giá tiền:</label>
                  <select
                    className={cx("input")}
                    id={`price-${index}`}
                    value={item.unitprice}
                    onChange={(e) => handlePriceChange(index, e.target.value)}
                  >
                    <option value="">Chọn giá</option>
                    <option value="5000">5.000/1 số lượng</option>
                    <option value="10000">10.000/1 số lượng</option>
                    <option value="15000">15.000/1 số lượng</option>
                    <option value="20000">20.000/1 số lượng</option>
                    <option value="30000">30.000/1 số lượng</option>
                    <option value="45000">45.000/1 số lượng</option>
                  </select>
                </div>
                <span>Tổng tiền: {VNDFormatter(item.price)}đ</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default WaterNote;
