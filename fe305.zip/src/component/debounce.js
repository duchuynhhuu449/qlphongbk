import { useRef } from "react";

export const useDebounceHandler = () => {
  const debounceTimers = useRef({});


  const debounce = (key, newVal, oldVal, callback, delay = 800) => {
    console.log("hàm này hoạt động")
    if (newVal === oldVal) return;

    if (debounceTimers.current[key]) {
      clearTimeout(debounceTimers.current[key]);
    }

    debounceTimers.current[key] = setTimeout(() => {
      callback();
      delete debounceTimers.current[key];
      console.log("da goi lai")
    }, delay);
  };

  return debounce;
};
