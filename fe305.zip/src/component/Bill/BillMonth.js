import React, { useRef } from "react";
import html2canvas from "html2canvas";
import { useSearchParams, useNavigate } from "react-router-dom";
import { VNDFormatter } from "component/VNDFormatter";
import { publicImages } from "../../assets";
import { showError } from "utils/toast";

// ── helpers ───────────────────────────────────────────────────────────────────
const now = new Date();
const formatDate = (d) => {
    if (!d) return "—";
    const dt = new Date(d);
    return `${String(dt.getDate()).padStart(2, "0")}/${String(dt.getMonth() + 1).padStart(2, "0")}/${dt.getFullYear()}`;
};

// ── shared style tokens ───────────────────────────────────────────────────────
const BLUE = "#2b4c93";
const DS = "'Dancing Script', cursive";
const RB = "'Roboto', sans-serif";

// Table header cell
const TH = {
    border: "1.5px solid #000",
    padding: "12px 10px",
    textAlign: "center",
    fontSize: 15,
    fontWeight: 700,
    fontFamily: RB,
    background: "#fff",
    color: "#000",
};

// Table data cell factory
const td = ({ center = true, bold = false, big = false, red = false } = {}) => ({
    border: "1px solid #000",
    padding: "10px 14px",
    textAlign: center ? "center" : "left",
    fontSize: bold && big ? 20 : 17,
    fontFamily: bold && !big ? RB : DS,
    color: red ? "#dc2626" : BLUE,
    fontWeight: bold ? 600 : 400,
    letterSpacing: "0.5px",
});

function BillMonth() {
    const [params] = useSearchParams();
    const navigate = useNavigate();
    const billRef = useRef(null);

    // ── decode params ──────────────────────────────────────────────────────────
    const soPhong = params.get("room") || "—";
    const hoVaTen = params.get("ten") || "—";
    const billingMode = params.get("mode") || "month";
    const milestoneDate = params.get("milestone") || "";
    const endDateParam = params.get("endDate") || "";
    const soNgayO = parseInt(params.get("ngay") || "0", 10);
    const giaPhong = parseInt(params.get("giaPhong") || "0", 10);
    const tienPhong = parseInt(params.get("tienPhong") || "0", 10);
    const tienDien = parseInt(params.get("tienDien") || "0", 10);
    const tienNuoc = parseInt(params.get("tienNuoc") || "0", 10);
    const sinhHoat = parseInt(params.get("sinhHoat") || "0", 10);
    const tongCong = parseInt(params.get("tongCong") || "0", 10);
    const csoDienCu = params.get("csoDienCu") || "0";
    const csoDienMoi = params.get("csoDienMoi") || "0";
    const dienKwh = parseInt(csoDienMoi, 10) - parseInt(csoDienCu, 10);
    const csoNuocCu = params.get("csoNuocCu") || "0";
    const csoNuocMoi = params.get("csoNuocMoi") || "0";
    const nuocM3 = parseInt(csoNuocMoi, 10) - parseInt(csoNuocCu, 10);
    const loaiNuoc = params.get("loaiNuoc") || "chiso";
    const soNguoi = parseInt(params.get("soNguoi") || "0", 10);
    const giaKhoan = parseInt(params.get("giaKhoan") || "0", 10);

    const rawSurcharges = params.get("surcharges");
    let parsedSurcharges = [];
    try { if (rawSurcharges) parsedSurcharges = JSON.parse(rawSurcharges); } catch (_) { }

    const thang = now.getMonth() + 1;
    const nam = now.getFullYear();

    // ── download ───────────────────────────────────────────────────────────────
    const handleDownload = async () => {
        if (!billRef.current) return;
        const orig = billRef.current.style.padding;
        billRef.current.style.padding = "36px 48px";
        try {
            const canvas = await html2canvas(billRef.current, { scale: 2, useCORS: true });
            const link = document.createElement("a");
            link.href = canvas.toDataURL("image/png");
            link.download = `hoa-don-thang-phong-${soPhong}-${thang}-${nam}.png`;
            link.click();
        } catch (_) { showError("Lỗi khi tải hóa đơn!"); }
        finally { billRef.current.style.padding = orig; }
    };

    // ── valid surcharges ───────────────────────────────────────────────────────
    const validSurcharges = parsedSurcharges.filter(s => {
        return (parseInt(String(s.amount).replace(/[^\d-]/g, ""), 10) || 0) !== 0;
    });
    const dataRows = 4 + validSurcharges.length;
    const totalRows = Math.max(7, dataRows);
    const emptyCount = totalRows - dataRows;

    return (
        <div style={{ minHeight: "100vh", background: "linear-gradient(135deg,#f0f4ff,#fafafa)", display: "flex", flexDirection: "column", alignItems: "center", padding: "32px 16px", fontFamily: RB }}>

            {/* ── Toolbar ── */}
            <div style={{ width: "100%", maxWidth: 1040, display: "flex", gap: 12, marginBottom: 20 }}>
                <button onClick={() => navigate(-1)}
                    style={{ padding: "9px 20px", borderRadius: 10, border: "1px solid #cbd5e1", background: "#fff", fontWeight: 600, cursor: "pointer", fontSize: 14 }}>
                    ← Quay lại
                </button>
                <button onClick={handleDownload}
                    style={{ padding: "9px 22px", borderRadius: 10, border: "none", background: `linear-gradient(135deg,${BLUE},#4f6cb8)`, color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>
                    ⬇ Tải Hóa Đơn (PNG)
                </button>
                <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", background: billingMode === "day" ? "#fef3c7" : "#ede9fe", color: billingMode === "day" ? "#92400e" : "#5b21b6", padding: "6px 16px", borderRadius: 20, fontWeight: 700, fontSize: 13 }}>
                    {billingMode === "day" ? `📅 Theo ngày (${soNgayO} ngày)` : "📆 Theo tháng"}
                </span>
            </div>

            {/* ── Bill card ── */}
            <div ref={billRef} style={{ background: "#fff", borderRadius: 12, boxShadow: "0 6px 32px rgba(0,0,0,0.10)", padding: "36px 48px", width: "100%", maxWidth: 1040 }}>

                {/* Header row */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
                    {/* Left */}
                    <div style={{ flex: 1 }}>
                        <p style={{ margin: 0, fontWeight: 800, fontSize: 17, fontFamily: RB }}>HATA HOME STAY</p>
                        <p style={{ margin: "2px 0 0", fontSize: 14, fontFamily: RB }}>128/1A Trần Phú</p>
                    </div>
                    {/* Center title */}
                    <div style={{ flex: 1.5, textAlign: "center" }}>
                        <p style={{ margin: 0, fontWeight: 900, fontSize: 22, letterSpacing: 1, fontFamily: RB }}>PHIẾU THU TIỀN TRỌ</p>
                    </div>
                    {/* Right — room no */}
                    <div style={{ flex: 1, textAlign: "right" }}>
                        <span style={{ fontSize: 15, fontFamily: RB }}>Phòng số : </span>
                        <span style={{ fontSize: 18, fontFamily: DS, color: BLUE, borderBottom: `2px solid ${BLUE}`, paddingBottom: 2, fontWeight: 400, letterSpacing: "1px" }}>
                            {String(soPhong).padStart(3, "0")}
                        </span>
                    </div>
                </div>

                {/* Info rows */}
                <div style={{ marginBottom: 6 }}>
                    <span style={{ fontSize: 15, fontFamily: RB }}>Thời gian : </span>
                    <span style={{ fontFamily: DS, color: BLUE, borderBottom: `1.5px solid ${BLUE}`, paddingBottom: 1, fontSize: 20, fontWeight: 700, paddingLeft: 6, paddingRight: 16 }}>
                        {billingMode === "day"
                            ? `Từ ${formatDate(milestoneDate)} → ${formatDate(endDateParam || now)} (${soNgayO} ngày)`
                            : `Tháng ${thang}/${nam}`}
                    </span>
                </div>
                <div style={{ marginBottom: 20 }}>
                    <span style={{ fontSize: 15, fontFamily: RB }}>Họ và tên : </span>
                    <span style={{ fontFamily: DS, color: BLUE, borderBottom: `1.5px solid ${BLUE}`, paddingBottom: 1, fontSize: 20, fontWeight: 700, paddingLeft: 6, paddingRight: 32 }}>
                        {hoVaTen}
                    </span>
                </div>

                {/* Table */}
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr>
                            <th style={{ ...TH, width: "5%" }}>STT</th>
                            <th style={{ ...TH, textAlign: "left", width: "28%" }}>Nội dung</th>
                            <th style={TH}>Chỉ số đầu</th>
                            <th style={TH}>Chỉ số cuối</th>
                            <th style={TH}>Số lượng</th>
                            <th style={TH}>Đơn giá</th>
                            <th style={TH}>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* Row 1 — Tiền phòng */}
                        <tr>
                            <td style={td()}>{1}</td>
                            <td style={td({ center: false })}>
                                Tiền Phòng
                                {billingMode === "day" && (
                                    <div style={{ fontSize: 13, color: "#d97706", marginTop: 2, fontFamily: RB, fontWeight: 500 }}>
                                        ({giaPhong.toLocaleString()} ÷ 30 × {soNgayO} ngày)
                                    </div>
                                )}
                            </td>
                            <td style={td()}></td>
                            <td style={td()}></td>
                            <td style={td()}>{billingMode === "day" ? `${soNgayO} ngày` : ""}</td>
                            <td style={td()}>{billingMode === "day" ? VNDFormatter(giaPhong) : ""}</td>
                            <td style={td()}>{VNDFormatter(tienPhong)}</td>
                        </tr>

                        {/* Row 2 — Tiền điện */}
                        <tr>
                            <td style={td()}>{2}</td>
                            <td style={td({ center: false })}>Tiền Điện</td>
                            <td style={td()}>{csoDienCu}</td>
                            <td style={td()}>{csoDienMoi}</td>
                            <td style={td()}>{Math.max(0, dienKwh)}</td>
                            <td style={td()}>{VNDFormatter(4000)}</td>
                            <td style={td()}>{VNDFormatter(tienDien)}</td>
                        </tr>

                        {/* Row 3 — Tiền nước */}
                        <tr>
                            <td style={td()}>{3}</td>
                            <td style={td({ center: false })}>Tiền Nước</td>
                            <td style={td()}>{loaiNuoc === "chiso" ? csoNuocCu : ""}</td>
                            <td style={td()}>{loaiNuoc === "chiso" ? csoNuocMoi : ""}</td>
                            <td style={td()}>{loaiNuoc === "chiso" ? `${Math.max(0, nuocM3)}` : `${soNguoi} người`}</td>
                            <td style={td()}>{loaiNuoc === "chiso" ? VNDFormatter(20000) : VNDFormatter(giaKhoan)}</td>
                            <td style={td()}>{VNDFormatter(tienNuoc)}</td>
                        </tr>

                        {/* Row 4 — Sinh hoạt */}
                        <tr>
                            <td style={td()}>{4}</td>
                            <td style={td({ center: false })}>Tiền Wifi+Rác+Xe</td>
                            <td style={td()}></td>
                            <td style={td()}></td>
                            <td style={td()}></td>
                            <td style={td()}></td>
                            <td style={td()}>{VNDFormatter(sinhHoat)}</td>
                        </tr>

                        {/* Dynamic surcharges */}
                        {validSurcharges.map((s, idx) => {
                            const val = parseInt(String(s.amount).replace(/[^\d-]/g, ""), 10) || 0;
                            return (
                                <tr key={`sc-${idx}`}>
                                    <td style={td()}>{5 + idx}</td>
                                    <td style={{ ...td({ center: false }), color: val < 0 ? "#dc2626" : BLUE }}>{s.note || "Khoản khác"}</td>
                                    <td style={td()}></td>
                                    <td style={td()}></td>
                                    <td style={td()}></td>
                                    <td style={td()}></td>
                                    <td style={{ ...td(), color: val < 0 ? "#dc2626" : BLUE }}>{VNDFormatter(val)}</td>
                                </tr>
                            );
                        })}

                        {/* Empty padding rows */}
                        {Array.from({ length: emptyCount }, (_, i) => (
                            <tr key={`emp-${i}`}>
                                <td style={td()}>{dataRows + 1 + i}</td>
                                <td style={td({ center: false })}></td>
                                <td style={td()}></td>
                                <td style={td()}></td>
                                <td style={td()}></td>
                                <td style={td()}></td>
                                <td style={td()}></td>
                            </tr>
                        ))}

                        {/* Total */}
                        <tr>
                            <td style={{ ...td(), border: "1px solid #000" }}></td>
                            <td colSpan={5} style={{ border: "1px solid #000", padding: "12px 14px", textAlign: "left", fontFamily: RB, fontWeight: 800, fontSize: 16, color: "#000" }}>
                                TỔNG CỘNG
                            </td>
                            <td style={{ ...td({ big: true }), fontFamily: DS, fontSize: 22, color: BLUE, fontWeight: 700, textAlign: "center" }}>
                                {VNDFormatter(tongCong)}
                            </td>
                        </tr>
                    </tbody>
                </table>

                {/* Footer */}
                {/* <div style={{ marginTop: 28, display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 12 }}>
                    <span style={{ fontFamily: DS, fontSize: 20, fontWeight: 700, color: "#374151" }}>Người Lập Phiếu:</span>
                    <img src={publicImages.editIcon} alt="signature" style={{ width: 120, height: 44, objectFit: "contain" }} />
                </div> */}
            </div>
        </div>
    );
}

export default BillMonth;
