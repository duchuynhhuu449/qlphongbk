import React, { useEffect, useRef, useState } from "react";
import html2canvas from "html2canvas";
import classNames from "classnames/bind";
import styles from "./Bill.module.scss";
import { useParams } from "react-router";
import { GetAllRoomsMonth } from "api";
import { VNDFormatter } from "component/VNDFormatter";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { publicImages } from '../../assets';
import { showSuccess, showWarning, showInfo } from "utils/toast";

const cx = classNames.bind(styles);

function Bill({ props }) {
  const { room } = useParams();
  const contentRef = useRef([]);
  const sliderRef = useRef(null);
  const setWidth = useRef(null);
  const [data, setData] = useState([]);
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const handleKeyDown = async (e) => {
      if (!sliderRef.current) return;

      if (e.key === "ArrowLeft") {
        sliderRef.current.slickPrev();
      } else if (e.key === "ArrowRight") {
        sliderRef.current.slickNext();
      } else if (e.key === "Enter") {
        const checked = window.confirm("Bạn có muốn tạo phiếu này không");
        if (checked) {
          showInfo("Hệ thống cần thời gian render ảnh vui lòng đợi khoảng 3-5s");
          const download = await handleDownloadAll();
          if (download) showSuccess("render thành công");
        } else {
          showWarning("Hủy thành công");
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    const GetRoom = async () => {
      try {
        const response = await GetAllRoomsMonth();
        if (response) {
          let filtered = null;
          if (room === "has") {
            filtered = response.data.filter(item => item.GiaPhong !== 0);
          } else if (room === "empty") {
            filtered = response.data.filter(item => item.GiaPhong === 0);
          } else {
            filtered = response.data.filter(
              (item) => item.SoPhong === Number(room) || item.SoPhong === Number(props)
            );

          }
          setData(filtered.length > 0 ? filtered : response.data);
        }
      } catch (error) {
        console.error("Error fetching rooms:", error);
      }
    };
    GetRoom();
  }, [room, props]);

  const handleDownloadAll = async () => {
    const originalWidth = setWidth.current.style.width;
    setWidth.current.style.width = "100%";

    try {
      const promises = contentRef.current.map(async (content, index) => {
        if (!content) return;

        const originalPadding = content.style.padding;
        content.style.padding = "24px";

        const canvas = await html2canvas(content, {
          scale: 2,
          useCORS: true,
        });

        const imgData = canvas.toDataURL("image/png");
        const link = document.createElement("a");
        link.href = imgData;
        link.download = `hoa-don-phong-${index}.png`;
        link.click();

        content.style.padding = originalPadding;
      });

      await Promise.all(promises);
      return true;
    } catch (error) {
      console.error("Error downloading bills:", error);
      return false;
    } finally {
      setWidth.current.style.width = originalWidth;
    }
  };

  const sliderSettings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    prevArrow: (
      <div className={cx("slick-arrow", "slick-prev")}>
        <i className="fas fa-chevron-left"></i>
      </div>
    ),
    nextArrow: (
      <div className={cx("slick-arrow", "slick-next")}>
        <i className="fas fa-chevron-right"></i>
      </div>
    ),
    beforeChange: (oldIndex, newIndex) => {
      setCurrentSlide(newIndex);
    },


  };

  return (
    <div ref={setWidth} className={cx("invoice-container")}>
      <div className={cx("tutorial")}>
        <span>
          Để duyệt qua các hóa đơn, sử dụng nút mũi tên trái/phải trên bàn phím<br />
          Hoặc nhấn nút tải về bên dưới để lưu hóa đơn
        </span>
      </div>
      {data && data.length > 0 && (
        <>
          <Slider {...sliderSettings} ref={sliderRef}>
            {data.map((item, index) => {
              const dientieuthu = item.chisodienmoi - item.chisodiencu;
              const nuoctieuthu =
                item.chisonuoclanhmoi -
                item.chisonuoclanhcu +
                item.chisonuocnongmoi -
                item.chisonuocnongcu;
              const dieukien1 = nuoctieuthu * 20000;
              const dieukien2 = item.songuoikhoang * item.giakhoangnuoc;
              const coastNuoc = item.loainuoc === "chiso" ? dieukien1 : dieukien2;
              const coastDien = dientieuthu > 0 ? dientieuthu * 4000 : 0;
              const total = coastNuoc + coastDien + item.sinhhoatchung + item.GiaPhong;
              const Sophong = String(item.SoPhong).padStart(3, "0");

              return (
                <div
                  key={`bill-${index}`}
                  ref={(el) => (contentRef.current[item.SoPhong] = el)}
                  className={cx("container_billhata")}
                >
                  <div className={cx("header")}>
                    <div className={cx("left")}>
                      <p>
                        <strong>HATA HOME STAY</strong>
                      </p>
                      <p>128/1A Trần Phú</p>
                    </div>
                    <div className={cx("center")}>
                      <p>PHIẾU THU TIỀN TRỌ</p>
                    </div>
                    <div className={cx("right")}>
                      <span>Phòng số :</span>
                      <span className={cx("line", "w-32", "text-center", "customer-text")}>
                        {Sophong}
                      </span>
                    </div>
                  </div>

                  <div className={cx("info")}>
                    <span>Thời gian :</span>
                    <span
                      className={cx(
                        "line",
                        "w-64",
                        "text-center",
                        "customer-text"
                      )}
                    >
                      Tháng {new Date().getMonth() + 1}/2025
                    </span>
                  </div>

                  <table>
                    <thead>
                      <tr>
                        <th>STT</th>
                        <th>Nội dung</th>
                        <th>Chỉ số đầu</th>
                        <th>Chỉ số cuối</th>
                        <th>Số lượng</th>
                        <th>Đơn giá</th>
                        <th>Thành tiền</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className={cx("customer-text")}>
                        <td>1</td>
                        <td>Tiền Phòng</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>{VNDFormatter(item.GiaPhong)}</td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>Tiền Điện</td>
                        <td>{item.chisodiencu}</td>
                        <td>{item.chisodienmoi}</td>
                        <td>{dientieuthu}</td>
                        <td>{VNDFormatter(4000)}</td>
                        <td>{VNDFormatter(coastDien)}</td>
                      </tr>
                      {item.loainuoc === "chiso" ? (
                        <tr>
                          <td>3</td>
                          <td>Tiền Nước</td>
                          <td>{item.chisonuoclanhcu + item.chisonuocnongcu}</td>
                          <td>{item.chisonuoclanhmoi + item.chisonuocnongmoi}</td>
                          <td>{nuoctieuthu}</td>
                          <td>{VNDFormatter(20000)}</td>
                          <td>{VNDFormatter(coastNuoc)}</td>
                        </tr>
                      ) : (
                        <tr>
                          <td>3</td>
                          <td>Tiền Nước</td>
                          <td></td>
                          <td></td>
                          <td>{item.songuoikhoang} người</td>
                          <td>{VNDFormatter(item.giakhoangnuoc)}</td>
                          <td>{VNDFormatter(coastNuoc)}</td>
                        </tr>
                      )}
                      <tr>
                        <td>4</td>
                        <td>Tiền Wifi+Rác+Xe</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>{VNDFormatter(item.sinhhoatchung)}</td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>6</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>7</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>

                      <tr>
                        <td></td>
                        <td>
                          <strong className={cx("total")}>TỔNG CỘNG</strong>
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                          <strong>{VNDFormatter(total)}</strong>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <div className={cx("footer")}>
                    <div className={cx("text")}>
                      <span>Ký nhận</span>
                    </div>
                    <div className={cx("image")}>
                      <img src={publicImages.editIcon} alt="signature" />
                    </div>
                  </div>
                </div>
              );
            })}
          </Slider>
          <div className={cx("download-section")}>
            <button
              className={cx("download-button")}
              onClick={async () => {
                const checked = window.confirm("Bạn có muốn tải hóa đơn này không?");
                if (checked) {
                  showInfo("Hệ thống đang xử lý, vui lòng đợi khoảng 3-5 giây");
                  const download = await handleDownloadAll();
                  if (download) showSuccess("Tải xuống thành công!");
                }
              }}
            >
              <i className="fas fa-download"></i>
              Tải Hóa Đơn
            </button>
            <div className={cx("navigation-info")}>
              <span>Hóa đơn {currentSlide + 1}/{data.length}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default Bill;
