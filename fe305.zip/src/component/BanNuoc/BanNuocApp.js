import React, { useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import classNames from 'classnames/bind';
import styles from './BanNuocApp.module.scss';

// Placeholder cho các trang (Sẽ tạo sau)
import PosPage from './pages/PosPage';
import HistoryPage from './pages/HistoryPage';
import InventoryPage from './pages/InventoryPage';
import ImportPage from './pages/ImportPage';

const cx = classNames.bind(styles);

function BanNuocApp() {
    const location = useLocation();

    const navItems = [
        { name: 'Bán hàng', path: '/ban-nuoc', icon: 'fas fa-cash-register' },
        { name: 'Lịch sử', path: '/ban-nuoc/history', icon: 'fas fa-history' },
        { name: 'Kiểm kê', path: '/ban-nuoc/inventory', icon: 'fas fa-boxes' },
        { name: 'Nhập hàng', path: '/ban-nuoc/import', icon: 'fas fa-truck-loading' }
    ];

    return (
        <div className={cx('bannuoc-container')}>
            <div className={cx('bannuoc-nav')}>
                {navItems.map((item) => (
                    <Link
                        key={item.path}
                        to={item.path}
                        className={cx('nav-item', { active: location.pathname === item.path })}
                    >
                        <i className={item.icon}></i>
                        <span>{item.name}</span>
                    </Link>
                ))}
            </div>

            <div className={cx('bannuoc-content')}>
                <Routes>
                    <Route path="/" element={<PosPage />} />
                    <Route path="/history" element={<HistoryPage />} />
                    <Route path="/inventory" element={<InventoryPage />} />
                    <Route path="/import" element={<ImportPage />} />
                </Routes>
            </div>
        </div>
    );
}

export default BanNuocApp;
