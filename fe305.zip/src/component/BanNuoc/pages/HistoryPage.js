import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './HistoryPage.module.scss';
import { fetchBannuocTransactions, deleteBannuocMultipleTransactions, createBannuocSalesCheckpoint, updateBannuocPayment } from 'api';
import ActionMenu, { MenuItem, MenuDivider } from '../components/ActionMenu';
import DeleteTransactionsModal from '../components/DeleteTransactionsModal';
import SummaryModal from '../components/SummaryModal';
import SummaryDateModal from '../components/SummaryDateModal';
import ChangePaymentModal from '../components/ChangePaymentModal';
import TotalRevenueModal from '../components/TotalRevenueModal';
import { showSuccess, showError } from "utils/toast";

const cx = classNames.bind(styles);

function HistoryPage() {
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [showSummaryModal, setShowSummaryModal] = useState(false);
    const [showSummaryDateModal, setShowSummaryDateModal] = useState(false);
    const [showChangePaymentModal, setShowChangePaymentModal] = useState(false);
    const [showTotalRevenueModal, setShowTotalRevenueModal] = useState(false);

    const [selectedTransaction, setSelectedTransaction] = useState(null);
    const [summaryTransactions, setSummaryTransactions] = useState([]);
    const [summaryDateRange, setSummaryDateRange] = useState({ start: '', end: '' });

    const today = new Date().toISOString().split('T')[0];
    const [startDate, setStartDate] = useState(today);
    const [endDate, setEndDate] = useState(today);

    const fetchTransactionsData = async (page = 1) => {
        setLoading(true);
        try {
            const data = await fetchBannuocTransactions({ startDate, endDate, page, limit: 10 });
            setTransactions(data.transactions || data || []);
            setTotalPages(data.totalPages || 1);
            setCurrentPage(page);
        } catch (error) {
            console.error('Lỗi khi tải lịch sử:', error);
            showError('Không thể tải lịch sử giao dịch');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTransactionsData(1);
    }, []);

    const handleFilter = () => {
        setCurrentPage(1);
        fetchTransactionsData(1);
    };

    const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPages) {
            fetchTransactionsData(newPage);
        }
    };

    const handleDeleteTransactions = async (transactionIds) => {
        try {
            await deleteBannuocMultipleTransactions(transactionIds);
            showSuccess('Xóa giao dịch thành công');
            setShowDeleteModal(false);
            fetchTransactionsData(currentPage);
        } catch (error) {
            showError('Lỗi: ' + error.message);
        }
    };

    const handleCheckpoint = async (checkpointData) => {
        try {
            await createBannuocSalesCheckpoint(checkpointData);
            showSuccess('Chốt tiền thành công');
            setShowSummaryModal(false);
            fetchTransactionsData(currentPage);
        } catch (error) {
            showError('Lỗi: ' + error.message);
        }
    };

    const handleSummaryDateConfirm = async (start, end) => {
        try {
            const data = await fetchBannuocTransactions({ startDate: start, endDate: end, page: 1, limit: 1000 });
            setSummaryTransactions(data.transactions || []);
            setSummaryDateRange({ start, end });
            setShowSummaryDateModal(false);
            setShowSummaryModal(true);
        } catch (error) {
            showError('Không thể tải dữ liệu: ' + error.message);
        }
    };

    const handleChangePayment = async (newPaymentMethod) => {
        if (!selectedTransaction) return;
        try {
            await updateBannuocPayment(selectedTransaction._id, { paymentMethod: newPaymentMethod });
            showSuccess('Đã chuyển hình thức thanh toán');
            setShowChangePaymentModal(false);
            setSelectedTransaction(null);
            fetchTransactionsData(currentPage);
        } catch (error) {
            showError('Lỗi: ' + error.message);
        }
    };

    const getPaymentMethodText = (method) => {
        const methods = { 'tien_mat': 'Tiền mặt', 'chuyen_khoan': 'Chuyển khoản', 'no': 'Ghi nợ' };
        return methods[method] || method;
    };

    return (
        <div className={cx('history-page')}>
            <div className={cx('header-section')}>
                <h1 className={cx('page-title')}>Lịch sử giao dịch</h1>
                <p className={cx('page-subtitle')}>Xem các giao dịch bán hàng trong ngày</p>
            </div>

            <div className={cx('filter-section')}>
                <div className={cx('filter-header')}>
                    <i className="fas fa-calendar-alt"></i>
                    <h3>Lọc theo ngày</h3>
                </div>

                <div className={cx('filter-controls')}>
                    <div className={cx('control-group')}>
                        <label>Từ ngày</label>
                        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                    </div>
                    <div className={cx('control-group')}>
                        <label>Đến ngày</label>
                        <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                    </div>
                    <div className={cx('control-item')}>
                        <button onClick={handleFilter} className={cx('btn-primary')}>
                            <i className="fas fa-filter"></i> Lọc
                        </button>
                    </div>
                    <div className={cx('control-item-end')}>
                        <ActionMenu trigger={<><i className="fas fa-bars"></i> Thao tác</>}>
                            <MenuItem icon={<i className="fas fa-sync-alt"></i>} label="Hôm nay" onClick={() => { setStartDate(today); setEndDate(today); fetchTransactionsData(1); }} />
                            <MenuDivider />
                            <MenuItem icon={<i className="fas fa-chart-bar"></i>} label="Tổng kết" onClick={() => setShowSummaryDateModal(true)} variant="success" />
                            <MenuItem icon={<i className="fas fa-chart-line"></i>} label="Báo cáo tổng" onClick={() => setShowTotalRevenueModal(true)} variant="info" />
                            <MenuDivider />
                            <MenuItem icon={<i className="fas fa-trash-alt"></i>} label="Xóa giao dịch" onClick={() => setShowDeleteModal(true)} variant="danger" />
                        </ActionMenu>
                    </div>
                </div>
            </div>

            <div className={cx('table-container')}>
                {loading ? (
                    <div className={cx('loading')}><div className={cx('spinner')}></div></div>
                ) : transactions.length === 0 ? (
                    <div className={cx('empty')}>Không có giao dịch nào trong khoảng thời gian này</div>
                ) : (
                    <>
                        <div className={cx('table-responsive')}>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Mã GD</th>
                                        <th>Sản phẩm</th>
                                        <th>Số lượng</th>
                                        <th>Tổng tiền</th>
                                        <th>Hình thức</th>
                                        <th>Trạng thái</th>
                                        <th>Chốt tiền</th>
                                        <th>Ngày giờ</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {transactions.map(t => (
                                        <tr key={t._id}>
                                            <td className={cx('text-center')}>#{t._id.slice(-6)}</td>
                                            <td>
                                                {t.items.map((item, idx) => (
                                                    <div key={idx}>{item.productId?.name || 'N/A'}</div>
                                                ))}
                                            </td>
                                            <td className={cx('text-center', 'font-bold')}>
                                                {t.items.map((item, idx) => (
                                                    <div key={idx}>{item.quantity}</div>
                                                ))}
                                            </td>
                                            <td className={cx('text-center', 'text-primary', 'font-bold')}>
                                                {t.totalAmount.toLocaleString('vi-VN')}₫
                                            </td>
                                            <td className={cx('text-center')}>{getPaymentMethodText(t.paymentMethod)}</td>
                                            <td className={cx('text-center')}>
                                                <span className={cx('badge', t.status === 'da_thu' ? 'badge-success' : 'badge-warning')}>
                                                    {t.status === 'da_thu' ? 'Đã thu' : 'Đang nợ'}
                                                </span>
                                            </td>
                                            <td className={cx('text-center')}>
                                                {t.isSalesCheckpointed ? (
                                                    <span className={cx('locked')}><i className="fas fa-lock"></i> Đã chốt</span>
                                                ) : (
                                                    <span className={cx('unlocked')}>Chưa</span>
                                                )}
                                            </td>
                                            <td className={cx('text-center')}>
                                                {new Date(t.createdAt).toLocaleString('vi-VN')}
                                            </td>
                                            <td className={cx('text-center')}>
                                                <button className={cx('btn-action')} onClick={() => { setSelectedTransaction(t); setShowChangePaymentModal(true); }}>
                                                    <i className="fas fa-exchange-alt"></i> Chuyển
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        <div className={cx('pagination')}>
                            <span>Trang {currentPage} / {totalPages}</span>
                            <div className={cx('page-controls')}>
                                <button disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)}>
                                    <i className="fas fa-chevron-left"></i>
                                </button>
                                <button disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)}>
                                    <i className="fas fa-chevron-right"></i>
                                </button>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {showSummaryDateModal && <SummaryDateModal onClose={() => setShowSummaryDateModal(false)} onConfirm={handleSummaryDateConfirm} />}
            {showSummaryModal && <SummaryModal transactions={summaryTransactions} startDate={summaryDateRange.start} endDate={summaryDateRange.end} onClose={() => setShowSummaryModal(false)} onCheckpoint={handleCheckpoint} />}
            {showChangePaymentModal && selectedTransaction && <ChangePaymentModal transaction={selectedTransaction} onClose={() => { setShowChangePaymentModal(false); setSelectedTransaction(null); }} onConfirm={handleChangePayment} />}
            {showDeleteModal && <DeleteTransactionsModal transactions={transactions} onClose={() => setShowDeleteModal(false)} onDelete={handleDeleteTransactions} />}
            {showTotalRevenueModal && <TotalRevenueModal onClose={() => setShowTotalRevenueModal(false)} />}
        </div>
    );
}

export default HistoryPage;
