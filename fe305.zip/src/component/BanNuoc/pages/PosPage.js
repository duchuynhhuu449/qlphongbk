import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './PosPage.module.scss';
import ProductCard from '../components/ProductCard';
import PosModal from '../components/PosModal';
import ConfirmModal from '../components/ConfirmModal';
import { fetchBannuocProducts, deleteBannuocProduct } from 'api';
import { showSuccess, showError, showWarning } from 'utils/toast';

const cx = classNames.bind(styles);

function PosPage() {
    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [productToDelete, setProductToDelete] = useState(null);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');

    const fetchProducts = async () => {
        setLoading(true);
        try {
            const data = await fetchBannuocProducts();
            // Ensure we always have an array even if API returns undefined or null
            setProducts(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error('Lỗi khi tải sản phẩm:', error);
            showError('Không thể tải danh sách sản phẩm');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProducts();
    }, []);

    const handleProductClick = (product) => {
        if (product.currentStock === 0) {
            showWarning('Sản phẩm đã hết hàng!');
            return;
        }
        setSelectedProduct(product);
    };

    const handleDeleteProduct = async () => {
        if (!productToDelete) return;

        try {
            await deleteBannuocProduct(productToDelete._id);
            showSuccess(`Đã xóa sản phẩm "${productToDelete.name}"`);
            setProductToDelete(null);
            fetchProducts();
        } catch (error) {
            showError('Không thể xóa sản phẩm: ' + error.message);
        }
    };

    const handleComplete = () => {
        fetchProducts(); // Refresh products after transaction
    };

    // Safely filter products, ensuring it doesn't crash if products is undefined
    const filteredProducts = (products || []).filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className={cx('pos-page')}>
            {/* Header */}
            <div className={cx('header-section')}>
                <div className={cx('title-row')}>
                    <div>
                        <h1 className={cx('page-title')}>Bán Hàng</h1>
                        <p className={cx('page-subtitle')}>Chọn sản phẩm để bắt đầu</p>
                    </div>
                    <button
                        onClick={fetchProducts}
                        className={cx('btn-refresh')}
                    >
                        <i className="fas fa-sync-alt"></i>
                        <span>Làm mới</span>
                    </button>
                </div>

                {/* Search Bar */}
                <div className={cx('search-container')}>
                    <i className={`fas fa-search ${cx('search-icon')}`}></i>
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Tìm kiếm sản phẩm..."
                        className={cx('search-input')}
                    />
                </div>
            </div>

            {/* Products Grid */}
            {loading ? (
                <div className={cx('loading-container')}>
                    <div className={cx('spinner')}></div>
                </div>
            ) : filteredProducts.length === 0 ? (
                <div className={cx('empty-state')}>
                    <p>
                        {searchQuery ? 'Không tìm thấy sản phẩm nào' : 'Chưa có sản phẩm nào'}
                    </p>
                </div>
            ) : (
                <div className={cx('products-grid')}>
                    {filteredProducts.map((product) => (
                        <ProductCard
                            key={product._id}
                            product={product}
                            onClick={handleProductClick}
                            onDelete={setProductToDelete}
                        />
                    ))}
                </div>
            )}

            {/* Modal */}
            {selectedProduct && (
                <PosModal
                    product={selectedProduct}
                    onClose={() => setSelectedProduct(null)}
                    onComplete={handleComplete}
                />
            )}

            {productToDelete && (
                <ConfirmModal
                    title="Xóa sản phẩm"
                    message={`Bạn có chắc chắn muốn xóa "${productToDelete.name}"?`}
                    onConfirm={handleDeleteProduct}
                    onCancel={() => setProductToDelete(null)}
                    confirmText="Xóa"
                    cancelText="Hủy"
                    type="danger"
                />
            )}
        </div>
    );
}

export default PosPage;
