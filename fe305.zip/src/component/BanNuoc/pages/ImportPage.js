import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './ImportPage.module.scss';
import { fetchBannuocProducts, createBannuocProduct, updateBannuocProduct, fetchBannuocImports, createBannuocImport, deleteBannuocProduct, deleteBannuocImport } from 'api';
import { showSuccess, showError, showWarning } from 'utils/toast';
import EditProductModal from '../components/EditProductModal';
import ImportDetailModal from '../components/ImportDetailModal';
import { useModal } from 'component/Modal/ModalContext';
import ConfirmModal from 'component/Modal/ConfirmModal';
import { publicImages } from 'assets';

const cx = classNames.bind(styles);

function ImportPage() {
    const [products, setProducts] = useState([]);
    const [imports, setImports] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showAddProduct, setShowAddProduct] = useState(false);
    const [showImportModal, setShowImportModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showImportDetail, setShowImportDetail] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [selectedImports, setSelectedImports] = useState([]);
    const { openModal } = useModal();

    const [newProduct, setNewProduct] = useState({ name: '', price: '', imageUrl: '', currentStock: 0 });
    const [importForm, setImportForm] = useState({ quantity: '', manufactureDate: '', expiryDate: '', imageUrl: '' });

    const loadData = async () => {
        setLoading(true);
        try {
            const [prodRes, impRes] = await Promise.all([fetchBannuocProducts(), fetchBannuocImports()]);
            setProducts(Array.isArray(prodRes) ? prodRes : []);
            setImports(Array.isArray(impRes) ? impRes : []);
        } catch (error) {
            console.error('Lỗi khi tải dữ liệu nhập hàng:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const handleAddProduct = async (e) => {
        e.preventDefault();
        if (!newProduct.name || !newProduct.price) {
            showWarning('Vui lòng điền đầy đủ thông tin');
            return;
        }
        try {
            await createBannuocProduct({
                ...newProduct,
                price: parseFloat(newProduct.price),
                currentStock: parseInt(newProduct.currentStock) || 0,
                imageUrl: newProduct.imageUrl || publicImages.hata
            });
            showSuccess('Thêm sản phẩm thành công!');
            setShowAddProduct(false);
            setNewProduct({ name: '', price: '', imageUrl: '', currentStock: 0 });
            loadData();
        } catch (error) {
            showError('Lỗi: ' + error.message);
        }
    };

    const handleDeleteProduct = async (product) => {
        openModal(
            <ConfirmModal
                title="Xóa sản phẩm"
                message={`Bạn có chắc muốn xóa sản phẩm ${product.name}?`}
                onConfirm={async () => {
                    try {
                        await deleteBannuocProduct(product._id);
                        showSuccess('Xóa sản phẩm thành công!');
                        loadData();
                    } catch (error) {
                        showError('Lỗi: ' + error.message);
                    }
                }}
            />
        );
    };

    const handleDeleteImport = async (importId) => {
        openModal(
            <ConfirmModal
                title="Xóa lịch sử nhập hàng"
                message="Bạn có chắc muốn xóa lịch sử nhập hàng này không? Số lượng tồn kho sẽ bị trừ đi tương ứng."
                onConfirm={async () => {
                    try {
                        await deleteBannuocImport(importId);
                        showSuccess('Xóa lịch sử nhập hàng thành công!');
                        loadData();
                    } catch (error) {
                        showError('Lỗi: ' + error.message);
                    }
                }}
            />
        );
    };

    const handleImport = async (e) => {
        e.preventDefault();
        if (!importForm.quantity || parseInt(importForm.quantity) <= 0) return showWarning('Vui lòng nhập số lượng hợp lệ');
        if (!importForm.manufactureDate || !importForm.expiryDate) return showWarning('Vui lòng nhập ngày sản xuất và hết hạn');

        try {
            let finalImageUrl = selectedProduct.imageUrl;
            if (importForm.imageUrl && importForm.imageUrl !== selectedProduct.imageUrl) {
                finalImageUrl = importForm.imageUrl;
                await updateBannuocProduct(selectedProduct._id, { imageUrl: finalImageUrl });
            }

            await createBannuocImport({
                productId: selectedProduct._id,
                quantity: parseInt(importForm.quantity),
                manufactureDate: importForm.manufactureDate,
                expiryDate: importForm.expiryDate
            });

            showSuccess('Nhập hàng thành công!');
            setImportForm({ quantity: '', manufactureDate: '', expiryDate: '', imageUrl: '' });
            setShowImportModal(false);
            loadData();
        } catch (error) {
            showError('Lỗi: ' + error.message);
        }
    };

    const groupedImports = imports.reduce((acc, imp) => {
        if (!acc[imp.productId?._id || imp.productId]) acc[imp.productId?._id || imp.productId] = [];
        acc[imp.productId?._id || imp.productId].push(imp);
        return acc;
    }, {});

    const handleViewImportDetail = (product) => {
        const productImports = groupedImports[product._id] || [];
        setSelectedProduct(product);
        setSelectedImports(productImports);
        setShowImportDetail(true);
    };

    const getExpiryWarning = (expiryDate) => {
        if (!expiryDate) return null;
        const diffDays = Math.ceil((new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24));

        if (diffDays < 0) return { text: 'Đã hết hạn', class: cx('badge-danger') };
        if (diffDays <= 20) return { text: `Còn ${diffDays} ngày`, class: cx('badge-warning') };
        return null;
    };

    const handleEditProduct = async (updatedData) => {
        try {
            await updateBannuocProduct(selectedProduct._id, updatedData);
            showSuccess('Cập nhật sản phẩm thành công!');
            setShowEditModal(false);
            setSelectedProduct(null);
            loadData();
        } catch (error) {
            showError('Lỗi cập nhật: ' + error.message);
        }
    };

    return (
        <div className={cx('import-page')}>
            <div className={cx('header-section')}>
                <div>
                    <h1 className={cx('page-title')}>Nhập Hàng</h1>
                    <p className={cx('page-subtitle')}>Quản lý nhập kho và sản phẩm</p>
                </div>
                <button className={cx('btn-add-product')} onClick={() => setShowAddProduct(true)}>
                    <i className="fas fa-plus"></i> Thêm Sản Phẩm
                </button>
            </div>

            <div className={cx('table-card')}>
                <div className={cx('card-header')}>
                    <h2>Danh sách sản phẩm</h2>
                </div>
                {loading ? (
                    <div className={cx('loading')}><div className={cx('spinner')}></div></div>
                ) : (
                    <div className={cx('table-responsive')}>
                        <table>
                            <thead>
                                <tr>
                                    <th>Sản phẩm</th>
                                    <th className={cx('text-center')}>Giá bán</th>
                                    <th className={cx('text-center')}>Tồn kho</th>
                                    <th className={cx('text-center')}>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map(product => (
                                    <tr key={product._id}>
                                        <td>
                                            <div className={cx('product-info')}>
                                                <img src={product.imageUrl} alt={product.name} onError={e => e.target.src = publicImages.hata} />
                                                <span className={cx('product-name')}>{product.name}</span>
                                            </div>
                                        </td>
                                        <td className={cx('text-center', 'font-bold', 'text-blue')}>
                                            {product.price.toLocaleString('vi-VN')}₫
                                        </td>
                                        <td className={cx('text-center')}>
                                            <div className={cx('stock-info')}>
                                                <span className={cx('stock-value', product.currentStock < 10 ? 'low-stock' : 'good-stock')}>
                                                    {product.currentStock}
                                                </span>
                                                {groupedImports[product._id] && (
                                                    <span className={cx('import-count')}>({groupedImports[product._id].length} lần nhập)</span>
                                                )}
                                            </div>
                                        </td>
                                        <td className={cx('text-center')}>
                                            <div className={cx('action-btns')}>
                                                {groupedImports[product._id]?.length > 0 && (
                                                    <button className={cx('btn-outline-purple')} onClick={() => handleViewImportDetail(product)}>
                                                        <i className="fas fa-eye"></i> Chi tiết
                                                    </button>
                                                )}
                                                <button className={cx('btn-primary')} onClick={() => { setSelectedProduct(product); setShowImportModal(true); }}>
                                                    Nhập hàng
                                                </button>
                                                <button className={cx('btn-warning')} onClick={() => { setSelectedProduct(product); setShowEditModal(true); }}>
                                                    <i className="fas fa-edit"></i>
                                                </button>
                                                <button className={cx('btn-danger')} onClick={() => handleDeleteProduct(product)}>
                                                    <i className="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            <div className={cx('table-card')}>
                <div className={cx('card-header')}>
                    <h2>Lịch sử nhập hàng</h2>
                </div>
                <div className={cx('table-responsive')}>
                    <table>
                        <thead>
                            <tr>
                                <th>Sản phẩm</th>
                                <th className={cx('text-center')}>Số lượng</th>
                                <th className={cx('text-center')}>NSX</th>
                                <th className={cx('text-center')}>HSD</th>
                                <th className={cx('text-center')}>Cảnh báo</th>
                                <th className={cx('text-center')}>Ngày nhập</th>
                                <th className={cx('text-center')}>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            {imports.map(imp => {
                                const warning = getExpiryWarning(imp.expiryDate);
                                const prodName = imp.productId?.name || products.find(p => p._id === imp.productId)?.name || 'N/A';
                                return (
                                    <tr key={imp._id}>
                                        <td className={cx('font-medium')}>{prodName}</td>
                                        <td className={cx('text-center', 'font-bold')}>{imp.quantity}</td>
                                        <td className={cx('text-center')}>{imp.manufactureDate ? new Date(imp.manufactureDate).toLocaleDateString('vi-VN') : '-'}</td>
                                        <td className={cx('text-center')}>{imp.expiryDate ? new Date(imp.expiryDate).toLocaleDateString('vi-VN') : '-'}</td>
                                        <td className={cx('text-center')}>
                                            {warning && <span className={cx('badge', warning.class)}><i className="fas fa-exclamation-triangle"></i> {warning.text}</span>}
                                        </td>
                                        <td className={cx('text-center')}>{new Date(imp.createdAt).toLocaleDateString('vi-VN')}</td>
                                        <td className={cx('text-center')}>
                                            <button className={cx('btn-danger', 'btn-sm')} style={{ padding: '4px 8px', fontSize: '12px' }} onClick={() => handleDeleteImport(imp._id)}>
                                                <i className="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>

            {showAddProduct && (
                <div className={cx('modal-overlay')}>
                    <div className={cx('modal-container')}>
                        <div className={cx('modal-header')}>
                            <h2>Thêm Sản Phẩm Mới</h2>
                            <button onClick={() => setShowAddProduct(false)}><i className="fas fa-times"></i></button>
                        </div>
                        <form onSubmit={handleAddProduct} className={cx('modal-body')}>
                            <div className={cx('form-group')}>
                                <label>Tên sản phẩm *</label>
                                <input type="text" value={newProduct.name} onChange={e => setNewProduct({ ...newProduct, name: e.target.value })} required />
                            </div>
                            <div className={cx('form-group')}>
                                <label>Giá bán *</label>
                                <input type="number" value={newProduct.price} onChange={e => setNewProduct({ ...newProduct, price: e.target.value })} required />
                            </div>
                            <div className={cx('form-group')}>
                                <label>URL hình ảnh</label>
                                <input type="text" value={newProduct.imageUrl} onChange={e => setNewProduct({ ...newProduct, imageUrl: e.target.value })} placeholder="https://..." />
                            </div>
                            <div className={cx('modal-footer')}>
                                <button type="button" className={cx('btn-secondary')} onClick={() => setShowAddProduct(false)}>Hủy</button>
                                <button type="submit" className={cx('btn-success')}>Thêm</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {showImportModal && selectedProduct && (
                <div className={cx('modal-overlay')}>
                    <div className={cx('modal-container')}>
                        <div className={cx('modal-header')}>
                            <h2>Nhập Hàng</h2>
                            <button onClick={() => setShowImportModal(false)}><i className="fas fa-times"></i></button>
                        </div>
                        <div className={cx('modal-body')}>
                            <div className={cx('product-banner')}>
                                <p>Sản phẩm</p>
                                <h3>{selectedProduct.name}</h3>
                            </div>
                            <form onSubmit={handleImport}>
                                <div className={cx('form-group')}>
                                    <label>Số lượng *</label>
                                    <input type="number" min="1" value={importForm.quantity} onChange={e => setImportForm({ ...importForm, quantity: e.target.value })} required />
                                </div>
                                <div className={cx('form-group')}>
                                    <label>Ngày sản xuất *</label>
                                    <input type="date" value={importForm.manufactureDate} onChange={e => setImportForm({ ...importForm, manufactureDate: e.target.value })} required />
                                </div>
                                <div className={cx('form-group')}>
                                    <label>Ngày hết hạn *</label>
                                    <input type="date" value={importForm.expiryDate} onChange={e => setImportForm({ ...importForm, expiryDate: e.target.value })} required />
                                </div>
                                <div className={cx('form-group')}>
                                    <label>URL hình ảnh (tùy chọn)</label>
                                    <input type="text" value={importForm.imageUrl} onChange={e => setImportForm({ ...importForm, imageUrl: e.target.value })} placeholder={selectedProduct.imageUrl || "https://..."} />
                                    <small>Để trống nếu không muốn thay đổi hình ảnh</small>
                                </div>
                                <div className={cx('modal-footer')}>
                                    <button type="button" className={cx('btn-secondary')} onClick={() => setShowImportModal(false)}>Hủy</button>
                                    <button type="submit" className={cx('btn-primary')}>Nhập hàng</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}

            {showEditModal && selectedProduct && <EditProductModal product={selectedProduct} onClose={() => { setShowEditModal(false); setSelectedProduct(null); }} onSave={handleEditProduct} />}
            <ImportDetailModal isOpen={showImportDetail} onClose={() => { setShowImportDetail(false); setSelectedProduct(null); setSelectedImports([]); }} imports={selectedImports} productName={selectedProduct?.name || ''} />
        </div>
    );
}

export default ImportPage;
