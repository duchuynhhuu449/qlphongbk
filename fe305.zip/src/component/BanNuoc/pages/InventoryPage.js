import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './InventoryPage.module.scss';
import { fetchBannuocLastCheckpoint, fetchBannuocAudit, confirmBannuocAudit, deleteBannuocCheckpoint } from 'api';
import ConfirmModal from '../components/ConfirmModal';
import PrintInventory from '../components/PrintInventory';
import CheckpointListModal from '../components/CheckpointListModal';
import { showSuccess, showError, showWarning } from 'utils/toast';

const cx = classNames.bind(styles);

function InventoryPage() {
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [inventoryData, setInventoryData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [hasData, setHasData] = useState(false);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [showCheckpointList, setShowCheckpointList] = useState(false);
    const [lastCheckpointInfo, setLastCheckpointInfo] = useState(null);
    const [errorDetails, setErrorDetails] = useState(null);
    const [auditWarning, setAuditWarning] = useState(null);

    const loadLastCheckpoint = async () => {
        try {
            const data = await fetchBannuocLastCheckpoint();
            setLastCheckpointInfo(data);
        } catch (error) {
            console.error('Lỗi khi tải checkpoint:', error);
        }
    };

    useEffect(() => {
        loadLastCheckpoint();
    }, []);

    useEffect(() => {
        if (lastCheckpointInfo && lastCheckpointInfo.hasCheckpoint) {
            const checkpointDate = new Date(lastCheckpointInfo.checkpoint.checkpointDate);
            const now = new Date();
            const daysDiff = Math.floor((now - checkpointDate) / (1000 * 60 * 60 * 24));

            if (daysDiff >= 7) {
                setAuditWarning({
                    daysOverdue: daysDiff - 7,
                    checkpointDate: checkpointDate,
                    message: `Đã ${daysDiff} ngày kể từ lần kiểm kê cuối! Bạn nên kiểm kê lại.`
                });
            } else if (daysDiff >= 5) {
                setAuditWarning({
                    daysRemaining: 7 - daysDiff,
                    checkpointDate: checkpointDate,
                    message: `Còn ${7 - daysDiff} ngày nữa đến hạn kiểm kê.`
                });
            } else {
                setAuditWarning(null);
            }
        }
    }, [lastCheckpointInfo]);

    const handleAudit = async () => {
        if (!startDate || !endDate) {
            showWarning('Vui lòng chọn khoảng thời gian');
            return;
        }
        const start = new Date(startDate);
        const end = new Date(endDate);
        const diffDays = (end - start) / (1000 * 60 * 60 * 24);

        if (diffDays > 30) return showWarning('Khoảng thời gian kiểm kê tối đa 30 ngày');
        if (diffDays < 0) return showWarning('Ngày kết thúc phải sau ngày bắt đầu');

        setLoading(true);
        setErrorDetails(null);
        try {
            const data = await fetchBannuocAudit({ startDate, endDate });
            setInventoryData(data);
            setHasData(true);
            setErrorDetails(null);
        } catch (error) {
            if (error.overlappingCheckpoint) {
                setErrorDetails(error);
            }
            showError('Lỗi: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleConfirmAudit = async () => {
        if (!hasData) return showWarning('Vui lòng thực hiện kiểm kê trước');
        try {
            const auditData = inventoryData.map(item => ({
                productId: item.productId,
                productName: item.productName,
                openingStock: item.openingStock,
                imported: item.imported,
                sold: item.sold,
                theoreticalStock: item.theoreticalStock,
                confirmedQuantity: item.theoreticalStock,
                note: ''
            }));

            await confirmBannuocAudit({ startDate, endDate, auditData });
            showSuccess('Chốt kiểm kê thành công!');
            setShowConfirmModal(false);

            await loadLastCheckpoint();
            setInventoryData([]);
            setHasData(false);
            setStartDate('');
            setEndDate('');
            setErrorDetails(null);
        } catch (error) {
            showError('Lỗi: ' + error.message);
        }
    };

    return (
        <div className={cx('inventory-page')}>
            <div className={cx('header-section')}>
                <h1 className={cx('page-title')}>Kiểm Kê Hàng Hóa</h1>
                <p className={cx('page-subtitle')}>Theo dõi tồn kho theo kỳ (tối đa 30 ngày)</p>
            </div>

            {auditWarning && (
                <div className={cx('alert-box', auditWarning.daysOverdue ? 'alert-danger' : 'alert-warning')}>
                    <i className={cx('fas fa-exclamation-circle', 'alert-icon')}></i>
                    <div>
                        <h3>{auditWarning.daysOverdue ? '⚠️ QUÁ HẠN KIỂM KÊ!' : '⏰ SẮP ĐẾN HẠN KIỂM KÊ'}</h3>
                        <p>{auditWarning.message}</p>
                        <p className={cx('text-small')}>Checkpoint cuối: {auditWarning.checkpointDate.toLocaleString('vi-VN')}</p>
                    </div>
                </div>
            )}

            {lastCheckpointInfo?.hasCheckpoint && (
                <div className={cx('alert-box', 'alert-info')}>
                    <i className={cx('fas fa-info-circle', 'alert-icon')}></i>
                    <div>
                        <h3>Thông tin Checkpoint gần nhất</h3>
                        <p>
                            <strong>Kỳ đã chốt:</strong> {new Date(lastCheckpointInfo.checkpoint.startDate).toLocaleDateString('vi-VN')}
                            {' → '}
                            {new Date(lastCheckpointInfo.checkpoint.endDate).toLocaleDateString('vi-VN')}
                        </p>
                        <p className={cx('highlight')}>⏰ Chốt lúc: {lastCheckpointInfo.checkpoint.checkpointTime}</p>
                        <p className={cx('text-success')}><i className="fas fa-check-circle"></i> {lastCheckpointInfo.suggestion.message}</p>

                        <button
                            onClick={() => {
                                setStartDate(lastCheckpointInfo.suggestion.suggestedStartDate);
                                setEndDate(new Date().toISOString().split('T')[0]);
                            }}
                            className={cx('btn-small')}
                        >
                            Áp dụng gợi ý
                        </button>
                    </div>
                </div>
            )}

            {errorDetails && (
                <div className={cx('alert-box', 'alert-danger')}>
                    <i className={cx('fas fa-times-circle', 'alert-icon')}></i>
                    <div>
                        <h3>⛔ Không thể kiểm kê</h3>
                        <p>{errorDetails.message}</p>
                        {errorDetails.suggestion && (
                            <div className={cx('suggestion-box')}>
                                <p><strong>💡 Gợi ý:</strong> {errorDetails.suggestion.message}</p>
                                <button
                                    onClick={() => {
                                        setStartDate(errorDetails.suggestion.suggestedStartDate);
                                        setEndDate(new Date().toISOString().split('T')[0]);
                                        setErrorDetails(null);
                                    }}
                                    className={cx('btn-small', 'btn-success')}
                                >
                                    Áp dụng gợi ý này
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            )}

            <div className={cx('controls-card')}>
                <div className={cx('controls-header')}>
                    <i className="fas fa-calendar-alt"></i> Chọn khoảng thời gian kiểm kê
                </div>
                <div className={cx('controls-grid')}>
                    <div className={cx('input-group')}>
                        <label>Từ ngày</label>
                        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                    </div>
                    <div className={cx('input-group')}>
                        <label>Đến ngày</label>
                        <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                    </div>
                    <div className={cx('btn-group')}>
                        <button
                            onClick={() => {
                                const today = new Date();
                                const sevenDaysAgo = new Date(today);
                                sevenDaysAgo.setDate(today.getDate() - 7);
                                setStartDate(sevenDaysAgo.toISOString().split('T')[0]);
                                setEndDate(today.toISOString().split('T')[0]);
                            }}
                            className={cx('btn-secondary')}
                        >
                            7 ngày
                        </button>
                    </div>
                    <div className={cx('btn-group')}>
                        <button onClick={handleAudit} disabled={loading} className={cx('btn-primary')}>
                            <i className="fas fa-file-signature"></i> Kiểm kê
                        </button>
                    </div>
                    <div className={cx('btn-group')}>
                        <button onClick={() => setShowCheckpointList(true)} className={cx('btn-purple')}>
                            <i className="fas fa-history"></i> Lịch sử
                        </button>
                    </div>
                    {hasData && (
                        <>
                            <div className={cx('btn-group')}>
                                <PrintInventory inventoryData={inventoryData} startDate={startDate} endDate={endDate} />
                            </div>
                            <div className={cx('btn-group')}>
                                <button onClick={() => setShowConfirmModal(true)} className={cx('btn-success')}>
                                    <i className="fas fa-save"></i> Chốt
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>

            <div className={cx('table-card')}>
                {loading ? (
                    <div className={cx('state-container')}>Đang tải...</div>
                ) : !hasData ? (
                    <div className={cx('state-container')}>
                        <i className="fas fa-exclamation-circle fa-3x"></i>
                        <p>Chọn khoảng thời gian và nhấn "Kiểm kê" để xem báo cáo</p>
                    </div>
                ) : inventoryData.length === 0 ? (
                    <div className={cx('state-container')}>Không có dữ liệu trong khoảng thời gian này</div>
                ) : (
                    <div className={cx('table-responsive')}>
                        <table>
                            <thead>
                                <tr>
                                    <th>Sản phẩm</th>
                                    <th className={cx('text-center')}>Tồn đầu kỳ</th>
                                    <th className={cx('text-center')}>Nhập trong kỳ</th>
                                    <th className={cx('text-center')}>Đã bán</th>
                                    <th className={cx('text-center')}>Tồn cuối kỳ</th>
                                </tr>
                            </thead>
                            <tbody>
                                {inventoryData.map(item => (
                                    <tr key={item.productId}>
                                        <td>
                                            <div className={cx('product-name')}>{item.productName}</div>
                                            {item.lastAuditDate && (
                                                <div className={cx('last-audit')}>
                                                    Kiểm kê gần nhất: {new Date(item.lastAuditDate).toLocaleDateString('vi-VN')}
                                                </div>
                                            )}
                                        </td>
                                        <td className={cx('text-center', 'font-large', 'font-bold')}>{item.openingStock}</td>
                                        <td className={cx('text-center')}>
                                            <span className={cx('badge', 'badge-blue')}>+{item.imported}</span>
                                        </td>
                                        <td className={cx('text-center')}>
                                            <span className={cx('badge', 'badge-red')}>-{item.sold}</span>
                                        </td>
                                        <td className={cx('text-center', 'font-xlite', 'font-bold', 'text-success')}>
                                            {item.theoreticalStock}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <div className={cx('summary-row')}>
                            <span>Tổng số sản phẩm:</span>
                            <span className={cx('font-bold', 'font-large')}>{inventoryData.length}</span>
                        </div>
                    </div>
                )}
            </div>

            {showConfirmModal && (
                <ConfirmModal
                    title="Xác nhận chốt kiểm kê"
                    message={`Bạn có chắc chắn muốn chốt kiểm kê cho khoảng thời gian từ ${new Date(startDate).toLocaleDateString('vi-VN')} đến ${new Date(endDate).toLocaleDateString('vi-VN')}? Hành động này sẽ lưu tồn cuối kỳ và tạo checkpoint cho lần kiểm kê tiếp theo.`}
                    onConfirm={handleConfirmAudit}
                    onCancel={() => setShowConfirmModal(false)}
                    confirmText="Chốt kiểm kê"
                    cancelText="Hủy"
                    type="warning"
                />
            )}

            {showCheckpointList && (
                <CheckpointListModal
                    onClose={() => setShowCheckpointList(false)}
                    onDelete={async (id) => {
                        try {
                            await deleteBannuocCheckpoint(id);
                            if (hasData) handleAudit();
                            loadLastCheckpoint();
                        } catch (err) {
                            showError('Lỗi: ' + err.message);
                        }
                    }}
                />
            )}
        </div>
    );
}

export default InventoryPage;
