import React from 'react';
import classNames from 'classnames/bind';
import styles from './SummaryModal.module.scss'; // Sẽ tạo

const cx = classNames.bind(styles);

export default function SummaryModal({ transactions, startDate, endDate, onClose, onCheckpoint }) {

    const uncheckpointed = transactions.filter(t => !t.isSalesCheckpointed);
    const totalAmount = uncheckpointed.reduce((sum, t) => sum + t.totalAmount, 0);

    const checkPointData = {
        date: startDate === endDate ? startDate : `${startDate} đến ${endDate}`,
        totalRevenue: totalAmount,
        transactionCount: uncheckpointed.length,
        transactionIds: uncheckpointed.map(t => t._id)
    };

    const paymentMethods = {
        tien_mat: uncheckpointed.filter(t => t.paymentMethod === 'tien_mat').reduce((sum, t) => sum + t.totalAmount, 0),
        chuyen_khoan: uncheckpointed.filter(t => t.paymentMethod === 'chuyen_khoan').reduce((sum, t) => sum + t.totalAmount, 0),
        no: uncheckpointed.filter(t => t.paymentMethod === 'no').reduce((sum, t) => sum + t.totalAmount, 0)
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Tổng kết bán hàng {startDate === endDate ? `(${startDate})` : `(${startDate} - ${endDate})`}</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <div className={cx('modal-body')}>
                    <div className={cx('summary-cards')}>
                        <div className={cx('card', 'card-total')}>
                            <span className={cx('card-title')}>Cần chốt</span>
                            <span className={cx('card-value')}>{totalAmount.toLocaleString('vi-VN')} đ</span>
                            <span className={cx('card-desc')}>{uncheckpointed.length} giao dịch</span>
                        </div>
                    </div>

                    <h3 className={cx('section-title')}>Chi tiết thanh toán</h3>
                    <div className={cx('payment-details')}>
                        <div className={cx('payment-row')}>
                            <span><i className="fas fa-money-bill-wave"></i> Tiền mặt</span>
                            <strong>{paymentMethods.tien_mat.toLocaleString('vi-VN')} đ</strong>
                        </div>
                        <div className={cx('payment-row')}>
                            <span><i className="fas fa-exchange-alt"></i> Chuyển khoản</span>
                            <strong>{paymentMethods.chuyen_khoan.toLocaleString('vi-VN')} đ</strong>
                        </div>
                        <div className={cx('payment-row', 'debt')}>
                            <span><i className="fas fa-book"></i> Ghi nợ</span>
                            <strong>{paymentMethods.no.toLocaleString('vi-VN')} đ</strong>
                        </div>
                    </div>

                    <div className={cx('warning-box')}>
                        <i className="fas fa-info-circle"></i>
                        <p>Hành động "Chốt tiền" sẽ khóa các giao dịch này lại. Bạn sẽ không thể sửa đổi hoặc xóa các giao dịch đã chốt.</p>
                    </div>
                </div>
                <div className={cx('modal-footer')}>
                    <button className={cx('btn-secondary')} onClick={onClose}>Đóng</button>
                    <button
                        className={cx('btn-success')}
                        disabled={uncheckpointed.length === 0}
                        onClick={() => onCheckpoint(checkPointData)}
                    >
                        <i className="fas fa-check-circle"></i> Chốt tiền ({uncheckpointed.length})
                    </button>
                </div>
            </div>
        </div>
    );
}
