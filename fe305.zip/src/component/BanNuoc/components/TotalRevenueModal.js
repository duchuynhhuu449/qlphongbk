import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './TotalRevenueModal.module.scss'; // Sẽ tạo
import { fetchBannuocSalesCheckpoints } from 'api';

const cx = classNames.bind(styles);

export default function TotalRevenueModal({ onClose }) {
    const [checkpoints, setCheckpoints] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadCheckpoints = async () => {
            try {
                const data = await fetchBannuocSalesCheckpoints();
                setCheckpoints(data || []);
            } catch (error) {
                console.error('Lỗi khi tải lịch sử chốt tiền:', error);
            } finally {
                setLoading(false);
            }
        };
        loadCheckpoints();
    }, []);

    const totalAllTime = checkpoints.reduce((sum, cp) => sum + (cp.totalRevenue || 0), 0);

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Báo cáo tổng doanh thu</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <div className={cx('modal-body')}>
                    <div className={cx('summary-card')}>
                        <div className={cx('total-label')}>Tổng doanh thu (Tất cả chốt)</div>
                        <div className={cx('total-value')}>{totalAllTime.toLocaleString('vi-VN')} đ</div>
                        <div className={cx('total-desc')}>Từ {checkpoints.length} lần chốt tiền</div>
                    </div>

                    <h3 className={cx('section-title')}>Lịch sử chốt tiền gần đây</h3>

                    {loading ? (
                        <div className={cx('loading')}>Đang tải...</div>
                    ) : checkpoints.length === 0 ? (
                        <div className={cx('empty')}>Chưa có lịch sử chốt tiền nào.</div>
                    ) : (
                        <div className={cx('table-responsive')}>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Thời điểm chốt</th>
                                        <th>Khoảng TG</th>
                                        <th className={cx('text-center')}>Số GD</th>
                                        <th className={cx('text-right')}>Doanh thu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {checkpoints.map(cp => (
                                        <tr key={cp._id}>
                                            <td>{new Date(cp.createdAt).toLocaleString('vi-VN')}</td>
                                            <td>{cp.date}</td>
                                            <td className={cx('text-center')}>{cp.transactionCount}</td>
                                            <td className={cx('text-right', 'font-bold', 'text-success')}>
                                                {cp.totalRevenue.toLocaleString('vi-VN')} đ
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
                <div className={cx('modal-footer')}>
                    <button className={cx('btn-primary')} onClick={onClose}>Đóng</button>
                </div>
            </div>
        </div>
    );
}
