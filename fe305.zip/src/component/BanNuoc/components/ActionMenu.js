import React, { useState, useRef, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './ActionMenu.module.scss';

const cx = classNames.bind(styles);

export function MenuItem({ icon, label, onClick, variant = 'default' }) {
    return (
        <button className={cx('menu-item', `variant-${variant}`)} onClick={onClick}>
            <span className={cx('icon')}>{icon}</span>
            <span className={cx('label')}>{label}</span>
        </button>
    );
}

export function MenuDivider() {
    return <div className={cx('menu-divider')}></div>;
}

export default function ActionMenu({ trigger, children }) {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef(null);

    useEffect(() => {
        function handleClickOutside(event) {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    return (
        <div className={cx('action-menu-container')} ref={menuRef}>
            <button className={cx('trigger-btn')} onClick={() => setIsOpen(!isOpen)}>
                {trigger}
            </button>

            {isOpen && (
                <div className={cx('dropdown-menu')}>
                    {React.Children.map(children, child => {
                        if (React.isValidElement(child)) {
                            // Close menu when a menu item is clicked
                            return React.cloneElement(child, {
                                onClick: (e) => {
                                    if (child.props.onClick) child.props.onClick(e);
                                    setIsOpen(false);
                                }
                            });
                        }
                        return child;
                    })}
                </div>
            )}
        </div>
    );
}
