import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './CheckpointListModal.module.scss'; // Sẽ tạo
import { fetchBannuocCheckpoints } from 'api';

const cx = classNames.bind(styles);

export default function CheckpointListModal({ onClose, onDelete }) {
    const [checkpoints, setCheckpoints] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadCheckpoints = async () => {
        setLoading(true);
        try {
            const data = await fetchBannuocCheckpoints();
            setCheckpoints(data || []);
        } catch (error) {
            console.error('Lỗi khi tải lịch sử kiểm kê:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadCheckpoints();
    }, []);

    const handleDelete = async (id) => {
        if (window.confirm('Bạn có chắc muốn xóa bản ghi kiểm kê này?')) {
            if (onDelete) {
                await onDelete(id);
                loadCheckpoints();
            }
        }
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Lịch sử kiểm kê kho</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <div className={cx('modal-body')}>
                    {loading ? (
                        <div className={cx('loading')}>Đang tải...</div>
                    ) : checkpoints.length === 0 ? (
                        <div className={cx('empty')}>
                            Chưa có lịch sử kiểm kê kho nào.
                        </div>
                    ) : (
                        <div className={cx('table-responsive')}>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Ngày kiểm kê</th>
                                        <th>Loại</th>
                                        <th>Ghi chú</th>
                                        <th className={cx('text-center')}>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {checkpoints.map((cp) => (
                                        <tr key={cp._id}>
                                            <td>{new Date(cp.createdAt).toLocaleString('vi-VN')}</td>
                                            <td>
                                                <span className={cx('badge', cp.type === 'audit' ? 'badge-primary' : 'badge-secondary')}>
                                                    {cp.type === 'audit' ? 'Kiểm kê thực tế' : 'Chốt hệ thống'}
                                                </span>
                                            </td>
                                            <td className={cx('notes-cell')}>{cp.notes || '-'}</td>
                                            <td className={cx('text-center')}>
                                                <button
                                                    className={cx('btn-danger', 'btn-sm')}
                                                    onClick={() => handleDelete(cp._id)}
                                                    title="Xóa kiểm kê"
                                                >
                                                    <i className="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
