import React, { useState } from 'react';
import classNames from 'classnames/bind';
import styles from './DeleteTransactionsModal.module.scss';
import ConfirmModal from '../../Modal/ConfirmModal';

const cx = classNames.bind(styles);

export default function DeleteTransactionsModal({ transactions, onClose, onDelete }) {
    const [selectedIds, setSelectedIds] = useState([]);
    const [showConfirm, setShowConfirm] = useState(false);

    const toggleSelect = (id) => {
        setSelectedIds(prev =>
            prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
        );
    };

    const handleDelete = () => {
        if (selectedIds.length === 0) return;
        setShowConfirm(true);
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Xóa giao dịch</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <div className={cx('modal-body')}>
                    <p className={cx('warning-text')}>
                        <i className="fas fa-exclamation-triangle"></i> Chọn các giao dịch bị sai để xóa. Khi xóa, số lượng sản phẩm sẽ được tự động cộng lại vào kho.
                    </p>
                    <div className={cx('transactions-list')}>
                        {transactions.length === 0 ? (
                            <p>Không có giao dịch nào.</p>
                        ) : (
                            transactions.map(t => (
                                <div key={t._id} className={cx('transaction-item')} onClick={() => toggleSelect(t._id)}>
                                    <input type="checkbox" checked={selectedIds.includes(t._id)} readOnly />
                                    <div className={cx('t-info')}>
                                        <strong>Mã: #{t._id.slice(-6)}</strong> | {new Date(t.createdAt).toLocaleString('vi-VN')}
                                        <div className={cx('t-details')}>
                                            {t.items.map((i, idx) => (
                                                <span key={idx}>{i.quantity}x {i.productName || i.productId?.name}</span>
                                            )).reduce((prev, curr) => [prev, ', ', curr])}
                                        </div>
                                        <div className={cx('t-total')}>{t.totalAmount.toLocaleString('vi-VN')} đ</div>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
                <div className={cx('modal-footer')}>
                    <button className={cx('btn-secondary')} onClick={onClose}>Hủy</button>
                    <button className={cx('btn-danger')} disabled={selectedIds.length === 0} onClick={handleDelete}>
                        <i className="fas fa-trash"></i> Xóa {selectedIds.length > 0 ? `(${selectedIds.length})` : ''}
                    </button>
                </div>
            </div>
            {showConfirm && (
                <ConfirmModal
                    title="Xác nhận xóa"
                    message={`Bạn có chắc muốn xóa ${selectedIds.length} giao dịch này? Số lượng tồn kho sẽ được hoàn lại tương ứng.`}
                    onConfirm={() => onDelete(selectedIds)}
                    onCloseOverride={() => setShowConfirm(false)}
                />
            )}
        </div>
    );
}
