import React from 'react';
import classNames from 'classnames/bind';
import styles from './ImportDetailModal.module.scss'; // Sẽ tạo

const cx = classNames.bind(styles);

export default function ImportDetailModal({ isOpen, onClose, imports, productName }) {
    if (!isOpen) return null;

    const getExpiryWarning = (expiryDate) => {
        if (!expiryDate) return null;
        const diffDays = Math.ceil((new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24));

        if (diffDays < 0) return { text: 'Đã hết hạn', class: cx('badge-danger') };
        if (diffDays <= 20) return { text: `Còn ${diffDays} ngày`, class: cx('badge-warning') };
        return { text: 'Còn hạn', class: cx('badge-success') };
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Lịch sử nhập hàng: {productName}</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <div className={cx('modal-body')}>
                    <div className={cx('table-responsive')}>
                        <table>
                            <thead>
                                <tr>
                                    <th>Ngày nhập</th>
                                    <th className={cx('text-center')}>Số lượng</th>
                                    <th className={cx('text-center')}>NSX</th>
                                    <th className={cx('text-center')}>HSD</th>
                                    <th className={cx('text-center')}>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                {imports.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" className={cx('text-center')}>Chưa có lịch sử nhập hàng cho sản phẩm này.</td>
                                    </tr>
                                ) : (
                                    imports.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((imp, idx) => {
                                        const warning = getExpiryWarning(imp.expiryDate);
                                        return (
                                            <tr key={idx}>
                                                <td>{new Date(imp.createdAt).toLocaleDateString('vi-VN')} {new Date(imp.createdAt).toLocaleTimeString('vi-VN')}</td>
                                                <td className={cx('text-center', 'font-bold')}>{imp.quantity}</td>
                                                <td className={cx('text-center')}>{imp.manufactureDate ? new Date(imp.manufactureDate).toLocaleDateString('vi-VN') : '-'}</td>
                                                <td className={cx('text-center')}>{imp.expiryDate ? new Date(imp.expiryDate).toLocaleDateString('vi-VN') : '-'}</td>
                                                <td className={cx('text-center')}>
                                                    {warning && <span className={cx('badge', warning.class)}>{warning.text}</span>}
                                                </td>
                                            </tr>
                                        );
                                    })
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
