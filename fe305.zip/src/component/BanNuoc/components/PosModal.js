import React, { useState } from 'react';
import classNames from 'classnames/bind';
import styles from './PosModal.module.scss';
import { publicImages } from 'assets';
import { createBannuocTransaction } from 'api';
import { VNDFormatter } from 'component/VNDFormatter';
import { showSuccess, showError } from 'utils/toast';

const cx = classNames.bind(styles);

function PosModal({ product, onClose, onComplete }) {
    const [quantity, setQuantity] = useState(1);
    const [showPayment, setShowPayment] = useState(false);
    const [loading, setLoading] = useState(false);

    const totalAmount = product.price * quantity;

    const handleIncrease = () => {
        if (quantity < product.currentStock) {
            setQuantity(quantity + 1);
        }
    };

    const handleDecrease = () => {
        if (quantity > 1) {
            setQuantity(quantity - 1);
        }
    };

    const handlePayment = async (paymentMethod) => {
        setLoading(true);
        try {
            await createBannuocTransaction({
                items: [{
                    productId: product._id,
                    quantity: quantity
                }],
                paymentMethod: paymentMethod
            });
            showSuccess('Thanh toán thành công!');
            onComplete();
            onClose();
        } catch (error) {
            showError('Lỗi: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2 className={cx('title')}>Chi tiết sản phẩm</h2>
                    <button onClick={onClose} className={cx('close-btn')}>
                        <i className="fas fa-times"></i>
                    </button>
                </div>

                <div className={cx('modal-content')}>
                    {!showPayment ? (
                        <div className={cx('product-details-grid')}>
                            <div className={cx('image-container')}>
                                <img
                                    src={product.imageUrl}
                                    alt={product.name}
                                    className={cx('product-image')}
                                    onError={(e) => {
                                        e.target.src = publicImages.hata;
                                    }}
                                />
                            </div>

                            <div className={cx('details-container')}>
                                <div className={cx('name-price-group')}>
                                    <h3 className={cx('product-name')}>{product.name}</h3>
                                    <p className={cx('product-price')}>{VNDFormatter(product.price)}₫</p>
                                </div>

                                <div className={cx('stock-info')}>
                                    <p className={cx('label')}>Tồn kho hiện tại</p>
                                    <p className={cx('value')}>{product.currentStock} sản phẩm</p>
                                </div>

                                <div className={cx('quantity-selector')}>
                                    <label className={cx('label')}>Số lượng</label>
                                    <div className={cx('controls')}>
                                        <button
                                            onClick={handleDecrease}
                                            disabled={quantity <= 1}
                                            className={cx('btn-adjust')}
                                        >
                                            <i className="fas fa-minus"></i>
                                        </button>

                                        <input
                                            type="number"
                                            value={quantity}
                                            onChange={(e) => {
                                                const val = parseInt(e.target.value) || 1;
                                                if (val >= 1 && val <= product.currentStock) {
                                                    setQuantity(val);
                                                }
                                            }}
                                            className={cx('input-quantity')}
                                        />

                                        <button
                                            onClick={handleIncrease}
                                            disabled={quantity >= product.currentStock}
                                            className={cx('btn-adjust', 'btn-add')}
                                        >
                                            <i className="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>

                                <div className={cx('total-info')}>
                                    <p className={cx('label')}>Tổng tiền</p>
                                    <p className={cx('value')}>{VNDFormatter(totalAmount)}₫</p>
                                </div>

                                <button
                                    onClick={() => setShowPayment(true)}
                                    className={cx('btn-checkout')}
                                >
                                    Thanh toán
                                </button>
                            </div>
                        </div>
                    ) : (
                        <div className={cx('payment-methods')}>
                            <h3 className={cx('title')}>Chọn hình thức thanh toán</h3>

                            <div className={cx('methods-list')}>
                                <PaymentButton
                                    icon="fas fa-money-bill-wave"
                                    title="Tiền mặt"
                                    description="Thanh toán bằng tiền mặt"
                                    colorClass="btn-green"
                                    onClick={() => handlePayment('tien_mat')}
                                    disabled={loading}
                                />
                                <PaymentButton
                                    icon="fas fa-credit-card"
                                    title="Chuyển khoản"
                                    description="Thanh toán qua ngân hàng"
                                    colorClass="btn-blue"
                                    onClick={() => handlePayment('chuyen_khoan')}
                                    disabled={loading}
                                />
                                <PaymentButton
                                    icon="fas fa-file-invoice-dollar"
                                    title="Ghi nợ"
                                    description="Thanh toán sau"
                                    colorClass="btn-yellow"
                                    onClick={() => handlePayment('no')}
                                    disabled={loading}
                                />
                            </div>

                            <button
                                onClick={() => setShowPayment(false)}
                                className={cx('btn-back')}
                                disabled={loading}
                            >
                                Quay lại
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

function PaymentButton({ icon, title, description, colorClass, onClick, disabled }) {
    return (
        <button
            onClick={onClick}
            disabled={disabled}
            className={cx('payment-btn', colorClass)}
        >
            <div className={cx('btn-content')}>
                <div className={cx('icon-wrapper')}>
                    <i className={icon}></i>
                </div>
                <div className={cx('text-wrapper')}>
                    <p className={cx('btn-title')}>{title}</p>
                    <p className={cx('btn-desc')}>{description}</p>
                </div>
            </div>
        </button>
    );
}

export default PosModal;
