import React, { useState } from 'react';
import classNames from 'classnames/bind';
import styles from './ChangePaymentModal.module.scss'; // Sẽ tạo

const cx = classNames.bind(styles);

export default function ChangePaymentModal({ transaction, onClose, onConfirm }) {
    const [method, setMethod] = useState(transaction?.paymentMethod || 'tien_mat');

    const handleSubmit = (e) => {
        e.preventDefault();
        onConfirm(method);
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Đổi phương thức thanh toán</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <form onSubmit={handleSubmit} className={cx('modal-body')}>
                    <p className={cx('info-text')}>
                        Giao dịch: <strong>#{transaction?._id?.slice(-6)}</strong>
                    </p>
                    <div className={cx('form-group')}>
                        <label>Chọn phương thức mới:</label>
                        <select
                            value={method}
                            onChange={(e) => setMethod(e.target.value)}
                            className={cx('payment-select')}
                        >
                            <option value="tien_mat">Tiền mặt</option>
                            <option value="chuyen_khoan">Chuyển khoản</option>
                            <option value="no">Ghi nợ</option>
                        </select>
                    </div>

                    <div className={cx('modal-footer')}>
                        <button type="button" className={cx('btn-secondary')} onClick={onClose}>Hủy</button>
                        <button type="submit" className={cx('btn-primary')}>Xác nhận</button>
                    </div>
                </form>
            </div>
        </div>
    );
}
