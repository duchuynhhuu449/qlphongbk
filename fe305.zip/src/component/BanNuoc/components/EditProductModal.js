import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './EditProductModal.module.scss';
import { publicImages } from 'assets';
import { showWarning } from 'utils/toast';

const cx = classNames.bind(styles);

export default function EditProductModal({ product, onClose, onSave }) {
    const [formData, setFormData] = useState({
        name: '',
        price: '',
        imageUrl: '',
        currentStock: 0
    });

    useEffect(() => {
        if (product) {
            setFormData({
                name: product.name || '',
                price: product.price || '',
                imageUrl: product.imageUrl || '',
                currentStock: product.currentStock || 0
            });
        }
    }, [product]);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.name || !formData.price) {
            showWarning('Vui lòng điền tên và giá sản phẩm');
            return;
        }

        onSave({
            ...formData,
            price: parseFloat(formData.price),
            currentStock: parseInt(formData.currentStock) || 0
        });
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Chỉnh sửa sản phẩm</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <form onSubmit={handleSubmit} className={cx('modal-body')}>
                    <div className={cx('form-group')}>
                        <label>Tên sản phẩm *</label>
                        <input
                            type="text"
                            value={formData.name}
                            onChange={e => setFormData({ ...formData, name: e.target.value })}
                            required
                        />
                    </div>
                    <div className={cx('form-group')}>
                        <label>Giá bán (VNĐ) *</label>
                        <input
                            type="number"
                            value={formData.price}
                            onChange={e => setFormData({ ...formData, price: e.target.value })}
                            required
                        />
                    </div>
                    <div className={cx('form-group')}>
                        <label>Số lượng tồn kho</label>
                        <input
                            type="number"
                            value={formData.currentStock}
                            onChange={e => setFormData({ ...formData, currentStock: e.target.value })}
                        />
                    </div>
                    <div className={cx('form-group')}>
                        <label>URL hình ảnh</label>
                        <input
                            type="text"
                            value={formData.imageUrl}
                            onChange={e => setFormData({ ...formData, imageUrl: e.target.value })}
                            placeholder="https://..."
                        />
                        {formData.imageUrl && (
                            <img src={formData.imageUrl} alt="Preview" className={cx('image-preview')} onError={(e) => e.target.src = publicImages.hata} />
                        )}
                    </div>

                    <div className={cx('modal-footer')}>
                        <button type="button" className={cx('btn-secondary')} onClick={onClose}>Hủy</button>
                        <button type="submit" className={cx('btn-primary')}>Lưu thay đổi</button>
                    </div>
                </form>
            </div>
        </div>
    );
}
