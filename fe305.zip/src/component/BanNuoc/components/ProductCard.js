import React from 'react';
import classNames from 'classnames/bind';
import styles from './ProductCard.module.scss';
import { publicImages } from 'assets';
import { VNDFormatter } from 'component/VNDFormatter';

const cx = classNames.bind(styles);

function ProductCard({ product, onClick, onDelete }) {
    const handleDelete = (e) => {
        e.stopPropagation();
        if (onDelete) {
            onDelete(product);
        }
    };

    return (
        <div className={cx('product-card')} onClick={() => onClick(product)}>
            {onDelete && (
                <button
                    onClick={handleDelete}
                    className={cx('delete-btn')}
                    title="Xóa sản phẩm"
                >
                    <i className="fas fa-trash-alt"></i>
                </button>
            )}

            <div className={cx('image-container')}>
                <img
                    src={product.imageUrl}
                    alt={product.name}
                    className={cx('product-image')}
                    onError={(e) => {
                        e.target.src = publicImages.hata;
                    }}
                />
                {product.currentStock < 10 && (
                    <div className={cx('low-stock-badge')}>
                        Sắp hết
                    </div>
                )}
            </div>

            <div className={cx('content')}>
                <h3 className={cx('name')} title={product.name}>
                    {product.name}
                </h3>

                <div className={cx('footer')}>
                    <div className={cx('price-section')}>
                        <span className={cx('label')}>Giá bán</span>
                        <p className={cx('price')}>
                            {VNDFormatter(product.price)}₫
                        </p>
                    </div>

                    <div className={cx('stock-section')}>
                        <div className={cx('stock-label')}>
                            <i className="fas fa-box"></i>
                            <span>Tồn kho:</span>
                        </div>
                        <span className={cx('stock-value', { 'text-danger': product.currentStock < 10, 'text-success': product.currentStock >= 10 })}>
                            {product.currentStock}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProductCard;
