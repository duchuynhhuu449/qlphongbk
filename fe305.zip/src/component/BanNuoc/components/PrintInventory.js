import React from 'react';
import { showInfo } from 'utils/toast';

export default function PrintInventory({ inventoryData, startDate, endDate }) {
    return (
        <button className="btn-placeholder" onClick={() => showInfo('Chức năng in đang được phát triển...')}>
            <i className="fas fa-print"></i> In báo cáo
        </button>
    );
}
