import React from 'react';
import classNames from 'classnames/bind';
import styles from './ConfirmModal.module.scss';

const cx = classNames.bind(styles);

function ConfirmModal({ title, message, onConfirm, onCancel, confirmText = 'Xác nhận', cancelText = 'Hủy', type = 'danger' }) {
    const isDanger = type === 'danger';

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container', 'animate-scaleIn')}>
                <div className={cx('modal-header')}>
                    <h2 className={cx('title')}>{title}</h2>
                    <button onClick={onCancel} className={cx('close-btn')}>
                        <i className="fas fa-times"></i>
                    </button>
                </div>

                <div className={cx('modal-content')}>
                    <div className={cx('icon-container')}>
                        <i className={`fas fa-exclamation-triangle ${cx(isDanger ? 'icon-danger' : 'icon-warning')}`}></i>
                    </div>
                    <p className={cx('message')}>{message}</p>
                </div>

                <div className={cx('modal-actions')}>
                    <button onClick={onCancel} className={cx('btn-cancel')}>
                        {cancelText}
                    </button>
                    <button onClick={onConfirm} className={cx('btn-confirm', isDanger ? 'bg-danger' : 'bg-warning')}>
                        {confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
}

export default ConfirmModal;
