import React, { useState } from 'react';
import classNames from 'classnames/bind';
import styles from './SummaryDateModal.module.scss'; // Sẽ tạo

const cx = classNames.bind(styles);

export default function SummaryDateModal({ onClose, onConfirm }) {
    const today = new Date().toISOString().split('T')[0];
    const [startDate, setStartDate] = useState(today);
    const [endDate, setEndDate] = useState(today);

    const handleSubmit = (e) => {
        e.preventDefault();
        onConfirm(startDate, endDate);
    };

    return (
        <div className={cx('modal-overlay')}>
            <div className={cx('modal-container')}>
                <div className={cx('modal-header')}>
                    <h2>Chọn ngày tổng kết</h2>
                    <button onClick={onClose} className={cx('close-btn')}><i className="fas fa-times"></i></button>
                </div>
                <form onSubmit={handleSubmit} className={cx('modal-body')}>
                    <p className={cx('info-text')}>
                        Chọn khoảng thời gian để xem các giao dịch chưa chốt và thực hiện chốt doanh thu.
                    </p>
                    <div className={cx('date-inputs')}>
                        <div className={cx('form-group')}>
                            <label>Từ ngày:</label>
                            <input
                                type="date"
                                value={startDate}
                                onChange={(e) => setStartDate(e.target.value)}
                                required
                            />
                        </div>
                        <div className={cx('form-group')}>
                            <label>Đến ngày:</label>
                            <input
                                type="date"
                                value={endDate}
                                onChange={(e) => setEndDate(e.target.value)}
                                required
                            />
                        </div>
                    </div>

                    <div className={cx('modal-footer')}>
                        <button type="button" className={cx('btn-secondary')} onClick={onClose}>Hủy</button>
                        <button type="submit" className={cx('btn-primary')}>Xem tổng kết</button>
                    </div>
                </form>
            </div>
        </div>
    );
}
