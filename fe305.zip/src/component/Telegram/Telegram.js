import React, { useState, useEffect } from "react";
import styles from "./Telegram.module.scss";
import classNames from "classnames/bind";
import Loading from "../Loading";
import { useLoading } from "../../hooks/useLoading";
import { GetAllRoomsMonth } from "api";
import { publicImages } from '../../assets';

const cx = classNames.bind(styles);

const Form2 = () => {
  return (
    <>
      <div className={cx("container")}>
      <div className={cx("image-wrapper")}>
        <img
          src={publicImages.telegramPng}
          alt="Mã QR Telegram"
          className={cx("image")}
        />
      </div>
        <span className={cx("header")}>
          📲{" "}
          <strong>
            Chào mừng bạn đến với bot tính tiền phòng HataHomeStay trên Telegram!
          </strong>
        </span>

        <span className={cx("instruction")}>
          Bot này được tạo ra để giúp bạn gửi chỉ số điện, nước hàng tháng một
          cách <strong>nhanh chóng</strong> và <strong>chính xác</strong>. Dưới
          đây là hướng dẫn chi tiết:
        </span>

        <span className={cx("step")}>
          🔹 <strong>Bước 1:</strong> Mở ứng dụng <em>Quét mã QR</em> trên điện
          thoại của bạn.
        </span>

        <span className={cx("step")}>
          🔹 <strong>Bước 2:</strong> Quét mã QR hiển thị trên màn hình hoặc tờ
          hướng dẫn. Telegram sẽ tự động mở bot có tên <em>HATAHOMESTAY_BOT</em>
          .
        </span>

        <span className={cx("step")}>
          🔹 <strong>Bước 3:</strong> Nhấn nút <code>Start</code> để bắt đầu sử
          dụng bot.
        </span>

        <span className={cx("instruction")}>
          Sau khi khởi động bot, bạn có thể nhập số phòng bằng cách gửi
          lệnh theo mẫu:
        </span>

        <span className={cx("example")}>
          <code>/001</code>
        </span>

        <span className={cx("detail")}>
          Trong đó <code>001</code> là số phòng. Khi bạn gửi lệnh này:
          <br />– Bot sẽ kiểm tra xem phòng đó có tồn tại hay không.
          <br />– Nếu phòng <strong>chưa có thời gian check-in</strong>, bot sẽ
          tự động cập nhật thời gian và thông báo cho bạn và chỉ cần gửi lại lệnh cũ hệ thống sẽ tự động tính toán cho bạn.
          <br />– Nếu phòng <strong>đã có thời gian</strong>, bot sẽ tự động
          tính tiền dựa trên số liệu đã có trong danh sách và gửi lại thông tin thanh toán chính xác.
          <br />– Nếu muốn reset thời gian nhận phòng chỉ cần gửi lệnh <strong>/sophong r, ví dụ: /001 r</strong>, lệnh này hệ thống sẽ tự động xóa thời gian checkin và sẵn sàng chờ lệnh tiếp theo.
        </span>

        <span className={cx("footer")}>
        Bot HataHomeStay được phát triển bởi <strong>Hữu Đức</strong>. Cảm ơn
        bạn đã sử dụng!
      </span>
      </div>
    </>
  );
};

const Form1 = () => {
  return (
    <div className={cx("container")}>
      <div className={cx("image-wrapper")}>
        <img
          src={publicImages.telegramPng}
          alt="Mã QR Telegram"
          className={cx("image")}
        />
      </div>

      <span className={cx("header")}>
        📲{" "}
        <strong>
          Chào mừng bạn đến với bot điện nước HataHomeStay trên Telegram!
        </strong>
      </span>

      <span className={cx("intro")}>
        Bot này giúp bạn gửi chỉ số điện, nước hàng tháng dễ dàng và chính xác.
        Dưới đây là hướng dẫn chi tiết nhé!
      </span>

      <span className={cx("spacer")} />

      <span className={cx("step")}>
        <strong>Bước 1:</strong> Dùng điện thoại mở ứng dụng{" "}
        <strong>Quét mã QR</strong>.
      </span>

      <span className={cx("step")}>
        <strong>Bước 2:</strong> Quét mã QR hiển thị trên màn hình hoặc tờ hướng
        dẫn.
      </span>

      <span className={cx("instruction")}>
        Sau khi quét xong, Telegram sẽ mở ra bot có tên{" "}
        <em>HATAHOMESTAY_BOT</em>.
      </span>

      <span className={cx("step")}>
        <strong>Bước 3:</strong> Nhấn nút <code>Start</code> để bắt đầu sử dụng
        bot.
      </span>

      <span className={cx("instruction")}>
        Sau khi nhấn Start, bạn có thể bắt đầu nhập chỉ số điện nước mỗi tháng.
      </span>

      <span className={cx("step")}>
        <strong>Bước 4:</strong> Gửi thông tin theo đúng mẫu sau:
      </span>

      <span className={cx("example")}>
        <code>001 15 223 1523</code>
      </span>

      <span className={cx("note")}>📝 Giải thích:</span>
      <span className={cx("detail")}>
        - <code>001</code>: Số phòng
        <br />- <code>15</code>: Số nước nóng mới
        <br />- <code>223</code>: Số nước lạnh mới
        <br />- <code>1523</code>: Số điện mới
      </span>
      <span className={cx("step")}>
        ✅ Bạn có thể gửi nhiều phòng cùng lúc bằng cách xuống dòng, ví dụ:
      </span>

      <span className={cx("example")}>
        <code>001 15 223 1523</code>
        <br />
        <code>002 14 210 1490</code>
        <br />
        <code>003 12 190 1400</code>
      </span>

      <span className={cx("instruction")}>
        Mỗi dòng là thông tin của 1 phòng. Nhớ nhập đúng thứ tự nhé!
      </span>

      <span className={cx("response")}>
        Sau khi gửi, bot sẽ phản hồi như: <em>"Đã cập nhật cho phòng 001"</em>,
        "phòng 002", v.v...
      </span>

      <span className={cx("instruction")}>
        Bot sẽ tự động lưu lại. Bạn không cần nhập lại hay lo quên!
      </span>

      <span className={cx("step")}>
        <strong>Bước 5:</strong> Quay lại trang danh sách phòng trên hệ thống.
      </span>

      <span className={cx("instruction")}>
        Các chỉ số vừa nhập sẽ được cập nhật tự động. Bạn có thể kiểm tra lại và
        tạo hóa đơn ngay.
      </span>

      <span className={cx("spacer")} />

      <span className={cx("footer")}>
        Bot HataHomeStay được phát triển bởi <strong>Hữu Đức</strong>. Cảm ơn
        bạn đã sử dụng!
      </span>
    </div>
  );
};

function Telegram({ props }) {
  const [data, setData] = useState([]);
  const { loading, withLoading } = useLoading();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await withLoading(GetAllRoomsMonth());
        if (response) {
          setData(response.data);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return <Loading text="Đang tải dữ liệu..." />;
  }

  return (
    <>
      {props === 1 && <Form1 />}
      {props === 2 && <Form2 />}
      {props === "all" && (
        <>
          <Form1 />
          <Form2 />
        </>
      )}
    </>
  );
}

export default Telegram;
