import React from 'react';
import styles from './Copyright.module.scss';
import classNames from 'classnames/bind';

const cx = classNames.bind(styles);

const Copyright = ({ isOpen, onClose }) => {

  if (!isOpen) return null;

  return (
    <div className={cx('modal-overlay')}>
      <div className={cx('modal-content')}>
        <div className={cx('modal-header')}>
          <h2>Thông tin bản quyền</h2>
          <button className={cx('close-button')} onClick={onClose}>×</button>
        </div>

        <div className={cx('modal-body')}>
          <div className={cx('info-section')}>
            <h3>Thông tin ứng dụng</h3>
            <p>Phiên bản: 1.0.0</p>
            <p>Người phát triển: Hữu Đức</p>
            <p>Ngày phát triển: 01/03/2025</p>
            <p>Ngày phát hành: {new Date().toLocaleDateString()}</p>
          </div>

          <div className={cx('info-section')}>
            <h3>Thông tin bản quyền</h3>
            <p>© 2025 Hữu Đức. Tất cả các quyền được bảo lưu.</p>
            <p>Mã kích hoạt: ducdeptroai</p>
          </div>

          <div className={cx('info-section')}>
            <h3>Điều khoản sử dụng</h3>
            <p>Ứng dụng này được phát triển bởi Hữu Đức.</p>
            <p>Việc sử dụng ứng dụng phải tuân theo các điều khoản và điều kiện được quy định.</p>
            <p>Ngày phát triển: 01/03/2025.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Copyright; 