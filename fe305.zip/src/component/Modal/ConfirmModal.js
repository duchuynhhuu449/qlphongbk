import React from 'react';
import classNames from 'classnames/bind';
import styles from './modal.module.scss';
import { useModal } from './ModalContext';

const cx = classNames.bind(styles);

const ConfirmModal = ({ title, message, onConfirm, confirmText = "Xác nhận", cancelText = "Hủy", onCloseOverride }) => {
    const { closeModal } = useModal();

    const handleClose = () => {
        if (onCloseOverride) {
            onCloseOverride();
        } else {
            closeModal();
        }
    };

    const handleConfirm = () => {
        onConfirm();
        handleClose();
    };

    return (
        <div className={cx('modal-container')} onClick={(e) => e.stopPropagation()}>
            <div className={cx('modal-header')}>
                <h2>{title || "Xác nhận"}</h2>
                <button className={cx('close-btn')} onClick={handleClose}>&times;</button>
            </div>

            <div className={cx('modal-body')} style={{ padding: '20px 24px', fontSize: '15px', color: 'var(--text-color)' }}>
                {message}
            </div>

            <div className={cx('modal-footer')} style={{ display: 'flex', gap: '10px', padding: '16px 24px', borderTop: '1px solid var(--border-color)', justifyContent: 'flex-end' }}>
                <button
                    onClick={handleClose}
                    style={{ padding: '8px 16px', borderRadius: '8px', border: '1px solid var(--border-color)', background: 'var(--surface-color)', cursor: 'pointer', fontWeight: 600 }}
                >
                    {cancelText}
                </button>
                <button
                    onClick={handleConfirm}
                    style={{ padding: '8px 16px', borderRadius: '8px', border: 'none', background: '#e11d48', color: 'white', cursor: 'pointer', fontWeight: 600 }}
                >
                    {confirmText}
                </button>
            </div>
        </div>
    );
};

export default ConfirmModal;
