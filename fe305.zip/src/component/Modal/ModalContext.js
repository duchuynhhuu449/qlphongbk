import React, { createContext, useContext, useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import styles from './modal.module.scss';

const ModalContext = createContext();

export const ModalProvider = ({ children }) => {
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState(null);
  const [history, setHistory] = useState([]);

  const openModal = (content) => {
    if (modalContent) {
      setHistory(prev => [...prev, modalContent]);
    }
    setModalContent(content);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setModalContent(null);
    setHistory([]);
  };

  const goBack = () => {
    if (history.length > 0) {
      const previousContent = history[history.length - 1];
      setHistory(prev => prev.slice(0, -1));
      setModalContent(previousContent);
    }
  };

  useEffect(() => {
    // Allow the modal-wrapper to scroll itself, so the body stays unlocked
    // (we already hide the wrapper scrollbar via CSS)
    return () => { };
  }, [showModal]);

  return (
    <ModalContext.Provider value={{ showModal, modalContent, openModal, closeModal, goBack, canGoBack: history.length > 0 }}>
      {children}
      {showModal && typeof document !== 'undefined' && ReactDOM.createPortal(
        <>
          <div className={styles.overlay} onClick={closeModal}></div>
          <div className={styles['modal-wrapper']} onClick={closeModal}>
            <div className={styles['modal-parent']} onClick={(e) => e.stopPropagation()}>
              {history.length > 0 && (
                <button className={styles['back-button']} onClick={goBack}>
                  ← Quay lại
                </button>
              )}
              <div className={styles['modal-content']}>
                {modalContent}
              </div>
            </div>
          </div>
        </>,
        document.body
      )}
    </ModalContext.Provider>
  );
};

export const useModal = () => useContext(ModalContext);
