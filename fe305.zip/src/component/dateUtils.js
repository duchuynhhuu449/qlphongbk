// Hàm lấy giờ Việt Nam
export function getVietnamTime() {
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utc + 7 * 3600000);
}

// Hàm định dạng ngày theo múi giờ Việt Nam
export function formatVietnamDate(dateObj) {
  console.log("du lieu nhan duoc", dateObj);
  const day = String(dateObj.getDate()).padStart(2, "0");
  const month = String(dateObj.getMonth() + 1).padStart(2, "0");
  const year = dateObj.getFullYear();
  return `${year}-${month}-${day}`;
}

export function convertToISODate(dateStr) {
  if (!dateStr) return "";
  // Thay thế toàn bộ dấu / thành - để tương thích với toLocaleDateString('vi-VN')
  const normalized = dateStr.replace(/\//g, "-");

  // Hỗ trợ cả định dạng mm-dd-yyyy hoặc d-m-yyyy
  const parts = normalized.split("-");
  if (parts.length !== 3) return "";

  const day = parts[0].padStart(2, "0");
  const month = parts[1].padStart(2, "0");
  const year = parts[2];

  return `${year}-${month}-${day}`;
}

export const convertToStandardDateFormat = (dateStr, timeStr) => {
  // Tách ngày thành ngày, tháng, năm
  const [day, month, year] = dateStr.split("/");

  // Chuyển đổi thành định dạng yyyy-mm-dd
  const formattedDate = `${day.padStart(2, "0")}-${month.padStart(
    2,
    "0"
  )}-${year}`;

  let formattedDateTime;
  // Kết hợp ngày với giờ
  if (timeStr) {
    formattedDateTime = `${formattedDate} ${timeStr}`;
  } else {
    formattedDateTime = `${formattedDate}`;
  }

  return formattedDateTime;
};

export const formatDateValue = (datetime) => {
  if (!datetime) return "";
  const [year, date, day] = datetime.split(" ")[0].split("-"); // Chia chuỗi theo dấu "-"

  return day + "-" + date + "-" + year; // Định dạng lại thành d-m-Y
};

// Lấy giờ định dạng hh:mm
export const formatTimeValue = (datetime) => {
  if (!datetime) return "";
  const [, time] = datetime.split(" ");
  return time?.substring(0, 5) || "";
};

// Format date to DD/MM/YYYY
export const CurrentDate = () => {
  const today = new Date();
  const day = String(today.getDate()).padStart(2, '0');
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const year = today.getFullYear();
  return `${day}/${month}/${year}`;
};

// Format birth date from YYYY-MM-DD to DD/MM/YYYY
export const formatBirthDate = (dateStr) => {
  if (!dateStr) return "";
  const [year, month, day] = dateStr.split("-");
  return `${day}/${month}/${year}`;
};

// Calculate end date based on months
export const CalculateEndDate = (months) => {
  const today = new Date();
  const endDate = new Date(today);
  endDate.setMonth(today.getMonth() + parseInt(months));

  const day = String(endDate.getDate()).padStart(2, '0');
  const month = String(endDate.getMonth() + 1).padStart(2, '0');
  const year = endDate.getFullYear();

  return `${day}/${month}/${year}`;
};

// Format floor number to remove decimal points and add leading zero
export const formatFloorNumber = (floor) => {
  const floorNumber = Math.floor(floor || 0);
  return String(floorNumber).padStart(2, '0');
};

// Format number with leading zeros
export const formatNumberWithLeadingZeros = (number, length = 2) => {
  return String(number).padStart(length, '0');
};
