import React, { useState, useRef, useEffect } from 'react';
import styles from './Menu.module.scss';
import classNames from 'classnames/bind';

const cx = classNames.bind(styles);

const Menu = ({ items }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={cx('menu-container')} ref={menuRef}>
      <button 
        className={cx('menu-button')}
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className={cx('menu-icon')}>☰</span>
        Menu
      </button>

      {isOpen && (
        <div className={cx('menu-dropdown')}>
          {items.map((item, index) => (
            <button
              key={index}
              className={cx('menu-item')}
              onClick={() => {
                item.onClick();
                setIsOpen(false);
              }}
            >
              {item.icon && <span className={cx('item-icon')}>{item.icon}</span>}
              {item.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default Menu; 