import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { CurrentDate } from "component/dateUtils";


const generateContract = async (data) => {
  try {
    // Tải file template
    const response = await fetch(`/contract.docx`);
    if (!response.ok) {
      console.error(
        "Không thể tải file template:",
        response.status,
        response.statusText
      );
      throw new Error("Không thể tải file template hợp đồng");
    }

    const blob = await response.blob();
    const arrayBuffer = await blob.arrayBuffer();

    // Kiểm tra file
    if (arrayBuffer.byteLength === 0) {
      throw new Error("File template hợp đồng bị hỏng hoặc rỗng");
    }

    // Tạo document từ template
    const zip = new PizZip(arrayBuffer);
    const doc = new Docxtemplater(zip, {
      paragraphLoop: true,
      linebreaks: true,
      delimiters: {
        start: "{{",
        end: "}}",
      },
    });

    // Nếu NOITHAT là mảng 1 chiều, chuyển sang mảng cặp
    const NOITHAT_PAIR = [];
    for (let i = 0; i < data.NOITHAT.length; i += 2) {
      NOITHAT_PAIR.push({
        left: `01.${data.NOITHAT[i]}`,
        right: `01.${data.NOITHAT[i + 1]}` || "",
      });
    }

    // Chuẩn bị dữ liệu chính xác theo template
    const time = CurrentDate().split("/");
    const contractData = {
      HOVATEN: data.HOVATEN || "",
      NAMSINH: data.NAMSINH || "",
      MASOCCCD: data.MASOCCCD || "",
      NGAYCAP: new Date().toLocaleDateString("vi-VN"),
      THUONGTRU: data.THUONGTRU || "",
      SODIENTHOAI: data.SODIENTHOAI || "",
      FLOOR: data.FLOOR || "",
      SOPHONG: data.SOPHONG || "",
      DANHSACHNGUOITHUE: data.DANHSACHNGUOITHUE || "",
      SOTHANGTHUE: data.SOTHANGTHUE || "",
      BATDAU: data.BATDAU || new Date().toLocaleDateString("vi-VN"),
      KETTHUC: data.KETTHUC || new Date().toLocaleDateString("vi-VN"),
      GIAPHONG: data.GIAPHONG || "0",
      GIABANGCHU: data.GIABANGCHU || "0",
      CHISODIENBANGIAO: data.CHISODIENBANGIAO || 0,
      CHISONUOCBANGIAO: data.CHISONUOCBANGIAO || 0,
      DAY: time[0],
      MONTH: time[1],
      YEAR: time[2],
      NOITHAT: NOITHAT_PAIR,

    };

    console.log("Dữ liệu hợp đồng:", contractData);

    try {
      // Render document với dữ liệu
      doc.setData(contractData);
      doc.render();
    } catch (error) {
      console.error("Lỗi khi render template:", error);
      if (error.properties && error.properties.errors) {
        console.error("Chi tiết lỗi template:", error.properties.errors);
      }
      throw new Error("Lỗi khi tạo hợp đồng: " + error.message);
    }

    try {
      // Tạo file và tải xuống
      const out = doc.getZip().generate({
        type: "blob",
        mimeType:
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      });

      // Tạo link tải xuống
      const url = window.URL.createObjectURL(out);
      const link = document.createElement("a");
      link.href = url;
      link.download = `HopDong_${data.SOPHONG}_${data.HOVATEN}.docx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      return true;
    } catch (error) {
      console.error("Lỗi khi tạo file:", error);
      throw new Error("Không thể tạo file hợp đồng: " + error.message);
    }
  } catch (error) {
    console.error("Lỗi khi tạo hợp đồng:", error);
    throw error;
  }
};

export default generateContract;
