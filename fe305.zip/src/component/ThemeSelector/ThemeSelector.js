import React, { useEffect, useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import styles from './ThemeSelector.module.scss';

const ThemeSelector = () => {
  const { theme, toggleTheme, themes } = useTheme();
  const [isVisible, setIsVisible] = useState(false);

  // Ensure basic theme is set as default
  useEffect(() => {
    if (!localStorage.getItem('theme')) {
      toggleTheme('basic');
    }
  }, []);

  const handleThemeChange = (newTheme) => {
    toggleTheme(newTheme);
  };

  // Filter out duplicate premium theme
  const uniqueThemes = Object.values(themes).filter((t, index, self) => 
    index === self.findIndex((theme) => theme.id === t.id)
  );

  if (!isVisible) {
    return (
      <button 
        className={styles.showButton}
        onClick={() => setIsVisible(true)}
        title="Thay đổi giao diện"
      >
        <i className="fas fa-palette"></i>
      </button>
    );
  }

  return (
    <div className={styles.themeSelector}>
      <div className={styles.themeHeader}>
        <h3>Chọn giao diện</h3>
        <button 
          className={styles.closeButton}
          onClick={() => setIsVisible(false)}
        >
          <i className="fas fa-times"></i>
        </button>
      </div>
      <div className={styles.themeGrid}>
        {uniqueThemes.map((t) => (
          <button
            key={t.id}
            className={`${styles.themeButton} ${theme === t.id ? styles.active : ''}`}
            onClick={() => handleThemeChange(t.id)}
            title={t.description}
          >
            <div className={styles.themePreview} data-theme={t.id} />
            <span className={styles.themeName}>{t.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ThemeSelector; 