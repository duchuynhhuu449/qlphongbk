import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

export const themes = {
    basic: {
        id: 'basic',
        name: 'Cơ bản',
        description: 'Giao diện tối giản, nhẹ nhàng, dịu mắt'
    },
    light: {
        id: 'light',
        name: 'Sáng dịu',
        description: 'Giao diện sáng dịu nhẹ, dễ nhìn'
    },
    dark: {
        id: 'dark',
        name: 'Tối sang trọng',
        description: 'Giao diện tối sang trọng, đẳng cấp'
    },
    premium: {
        id: 'premium',
        name: 'Thượng hạng',
        description: 'Giao diện thượng hạng, sang trọng'
    }
};

export const ThemeProvider = ({ children }) => {
    const [theme, setTheme] = useState(() => {
        const savedTheme = localStorage.getItem('theme');
        return savedTheme || 'basic';
    });

    useEffect(() => {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
    }, [theme]);

    const toggleTheme = (newTheme) => {
        setTheme(newTheme);
    };

    return (
        <ThemeContext.Provider value={{ theme, themes, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
}; 