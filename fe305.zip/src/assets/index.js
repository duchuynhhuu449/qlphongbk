// Import images directly from public folder
import telegramPng from './images/telegram.png';
import telegramJpg from './images/telegram.jpg';
import editIcon from './images/edit.png';
import logo192 from './images/logo192.png';
import logo512 from './images/logo512.png';
import favicon from './images/favicon.ico';
import hata from './images/logohata.jpg'
const nganhang = 'https://img.vietqr.io/image/bidv-61510000600979-compact2.jpg';
const contract = './contract/contract.docx'

export const publicImages = {
  telegramPng,
  telegramJpg,
  editIcon,
  logo192,
  logo512,
  favicon,
  hata,
  nganhang
};


