import React, { useState, useEffect } from 'react';
import classNames from 'classnames/bind';
import styles from './App.module.scss';
import Header from 'layout/Header/Header';
import RoomList from './component/RoomDaily/RoomList';
import { ModalProvider } from './component/Modal/ModalContext';
import GlobalModal from './component/Modal/GlobalModal.js';
import { Route, Routes } from 'react-router-dom';
import Bill from 'component/Bill/Bill';
import BillMonth from 'component/Bill/BillMonth';
import RoomMonthList from './component/RoomMonthUI/RoomMonthList';
import BanNuocApp from './component/BanNuoc/BanNuocApp';
import DebtPage from './component/Debt/DebtPage';
import NotificationPage from './component/Notification/NotificationPage';
import ToastProvider from './component/Toast/ToastProvider';

import { ThemeProvider, useTheme } from './context/ThemeContext';
import ThemeModal from './component/ThemeModal/ThemeModal';
import './styles/themes.css';
import Settings from './component/Settings/Settings';
import { publicImages } from './assets';


const cx = classNames.bind(styles);

const AppContent = () => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { showThemeModal, setShowThemeModal } = useTheme();

  useEffect(() => {
    // Set tiêu đề
    document.title = 'HomeStayHata';

    // Tạo favicon động
    const link = document.createElement('link');
    link.rel = 'icon';
    link.type = 'image/png';
    link.href = publicImages.favicon; // Đường dẫn favicon trong thư mục public
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link); // Dọn dẹp nếu unmount
    };
  }, []);

  return (
    <div className={cx('app-container')}>
      <ModalProvider>
        <ThemeModal isOpen={showThemeModal} onClose={() => setShowThemeModal(false)} />

        <Header />
        <main className={cx("main")}>
          <Routes>
            <Route path="/" element={<RoomList />} />
            <Route path="/hata/:room" element={<Bill />} />
            <Route path="/thue-phong" element={<RoomMonthList />} />
            <Route path="/hoa-don-thang" element={<BillMonth />} />
            <Route path="/ban-nuoc/*" element={<BanNuocApp />} />
            <Route path="/ghi-no" element={<DebtPage />} />
            <Route path="/thong-bao" element={<NotificationPage />} />
          </Routes>
        </main>
        <GlobalModal />
      </ModalProvider>
    </div>
  );
};

function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </ThemeProvider>
  );
}

export default App;
