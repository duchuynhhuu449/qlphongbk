import React, { useState, useEffect } from 'react';
import styles from './Header.module.scss';
import classNames from 'classnames/bind';
import { useNavigate } from 'react-router-dom';
import HistoryRoom from 'component/RoomDaily/History/HistoryRoom';
import ListRoomDetail from 'component/RoomDaily/ListRoomDetail/ListRoomDetail';
import { useModal } from 'component/Modal/ModalContext';
import { getSystemNotifications } from 'api';

import { useTheme } from 'context/ThemeContext';
import ThemeModal from 'component/ThemeModal/ThemeModal';
import QRModal from 'component/QRModal/QRModal';

const cx = classNames.bind(styles);

const Header = () => {
    const { openModal } = useModal();
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const { theme, themes } = useTheme();

    const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
    const [isQRModalOpen, setIsQRModalOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [notiCount, setNotiCount] = useState(0);

    useEffect(() => {
        const fetchNotis = async () => {
            try {
                const res = await getSystemNotifications();
                if (res && res.data) {
                    setNotiCount(res.data.debts.length + res.data.expiringRooms.length);
                }
            } catch (e) { }
        };
        fetchNotis();
        // Optional: Polling every 60s
        const interval = setInterval(fetchNotis, 60000);
        return () => clearInterval(interval);
    }, []);

    const handleOpenHistoryRoom = () => {
        openModal(<HistoryRoom />);
    }

    const handleOpenListRoom = () => {
        openModal(<ListRoomDetail />);
    }

    const handleOpenWaterManager = () => {
        navigate('/ban-nuoc');
        setIsMobileMenuOpen(false);
    }

    const handleOpenListRoomMonth = () => {
        navigate('/thue-phong');
        setIsMobileMenuOpen(false);
    }

    const handleOpenSetTheme = () => {
        setIsThemeModalOpen(true);
    }

    const handleOpenQR = () => {
        setIsQRModalOpen(true);
    }

    const toggleHeader = () => {
        setIsOpen(!isOpen);
    }

    return (
        <header className={cx('header', { 'header--collapsed': !isOpen, 'header--mobile-open': isMobileMenuOpen })}>
            <button className={cx('header__mobileToggle')} onClick={() => setIsMobileMenuOpen(v => !v)}>
                <i className={isMobileMenuOpen ? 'fas fa-times' : 'fas fa-bars'}></i>
            </button>
            <button className={cx('header__toggle')} onClick={toggleHeader}>
                <i className={`fas fa-chevron-${isOpen ? 'left' : 'right'}`}></i>
            </button>
            <nav className={cx('header__nav', { 'header__nav--mobile': isMobileMenuOpen })}>
                <ul className={cx('header__menu')}>
                    <li className={cx('header__item')}>
                        <a href="/" className={cx('header__link')}>
                            <i className="fas fa-home"></i>
                            <span className={cx('header__text')}>Trang chủ</span>
                        </a>
                    </li>
                    <li className={cx('header__item')}>
                        <a className={cx('header__link')} onClick={() => handleOpenHistoryRoom()}>
                            <i className="fas fa-history"></i>
                            <span className={cx('header__text')}>Lịch sử</span>
                        </a>
                    </li>
                    <li className={cx('header__item')}>
                        <a className={cx('header__link')} onClick={() => handleOpenListRoom()}>
                            <i className="fas fa-calendar-day"></i>
                            <span className={cx('header__text')}>Danh sách phòng ngày</span>
                        </a>
                    </li>
                    <li className={cx('header__item')}>
                        <a className={cx('header__link')} onClick={() => handleOpenListRoomMonth()}>
                            <i className="fas fa-calendar-alt"></i>
                            <span className={cx('header__text')}>Danh sách phòng tháng</span>
                        </a>
                    </li>
                    <li className={cx('header__item')}>
                        <a className={cx('header__link')} onClick={() => handleOpenWaterManager()}>
                            <i className="fas fa-store"></i>
                            <span className={cx('header__text')}>Bán nước</span>
                        </a>
                    </li>
                    <li className={cx('header__item')}>
                        <a className={cx('header__link')} onClick={() => { navigate('/ghi-no'); setIsMobileMenuOpen(false); }}>
                            <i className="fas fa-book"></i>
                            <span className={cx('header__text')}>Ghi nợ</span>
                        </a>
                    </li>
                    <li className={cx('header__item')}>
                        <a className={cx('header__link')} onClick={() => { navigate('/thong-bao'); setIsMobileMenuOpen(false); }}>
                            <i className="fas fa-bell"></i>
                            <span className={cx('header__text')}>Thông báo</span>
                            {notiCount > 0 && <span className={cx('noti-badge')} style={{ background: '#ef4444', color: 'white', padding: '2px 6px', borderRadius: '10px', fontSize: '11px', marginLeft: '6px', fontWeight: 'bold' }}>{notiCount}</span>}
                        </a>
                    </li>
                </ul>
            </nav>

        </header>
    );
};

export default Header;