import axios from "axios";

const hostname = window.location.hostname; // tự lấy IP LAN khi truy cập từ mobile

const api = axios.create({
  baseURL: `http://${hostname}`,
  timeout: 10000,
});

// Hàm xử lý promise chung có catch lỗi
const handleRequest = async (promise, errorMessage) => {
  try {
    const res = await promise;
    return res.data;
  } catch (error) {
    const message =
      error.response?.data?.message || errorMessage || "Có lỗi xảy ra!";
    throw new Error(message);
  }
};

// ==================== ROOM APIs ====================

const editRoom = (room, adjust) => {
  return handleRequest(
    api.post("/api/edit-room", {
      roomNumber: room,
      newDetails: adjust,
    }),
    "Lỗi khi chỉnh sửa phòng"
  );
};

const addRoom = (object) => {
  return handleRequest(
    api.post("/api/addroom", {
      roomNumber: object.roomNumber,
      daily: object.dailyprice,
      firstHour: object.firstHour,
      extraHour: object.extraHour,
      checkInDate: "",
      checkOutDate: "",
    }),
    "Lỗi khi thêm phòng"
  );
};

const saveRoomHistory = (room, adjust) => {
  return handleRequest(
    api.post("/api/history", {
      roomNumber: room,
      totalAmount: adjust.totalAmount,
      checkInDate: adjust.checkInDate,
      checkOutDate: adjust.checkOutDate,
      description: adjust.description,
    }),
    "Lỗi khi lưu lịch sử phòng"
  );
};

const deleteRoomData = (room) => {
  return handleRequest(api.get(`/api/reset/${room}`), "Lỗi khi reset phòng");
};

const fetchRoomsList = async () => {
  const data = await handleRequest(
    api.get("/api/rooms"),
    "Lỗi khi lấy danh sách phòng"
  );
  if (data) {
    localStorage.setItem("rooms", JSON.stringify(data));
  }
  return data;
};

const fetchHistory = (type) => {
  const url = type === "all" ? "/api/history/all" : `/api/history/${type}`;
  return handleRequest(api.get(url), "Lỗi khi lấy lịch sử phòng");
};

const deleteHistory = (id) => {
  return handleRequest(api.delete(`/api/history/${id}`), "Lỗi khi xóa lịch sử phòng");
};

// ==================== NOTE WATER (per-room) APIs ====================

const fetchNoteList = () => {
  return handleRequest(api.get("/api/2/all"), "Lỗi khi lấy danh sách nước");
};

const addWaterNote = (object) => {
  return handleRequest(
    api.post(`/api/2/add`, object),
    "Lỗi khi thêm nước"
  );
};

const deleteNoteWater = (room) => {
  return handleRequest(
    api.get(`/api/2/delete/${room}`),
    "Lỗi khi xóa nước phòng"
  );
};

const deleteNoteWaterDetails = (object) => {
  return handleRequest(
    api.post(`/api/2/delete/v2`, {
      room: object.SoPhong,
      drinkName: object.drinkName,
    }),
    "Lỗi khi xóa nước"
  );
};

// ==================== ROOM MONTH APIs ====================

const GetAllRoomsMonth = () => {
  return handleRequest(
    api.get("/api/getallroom/v2"),
    "Lỗi khi tải danh sách phòng tháng"
  );
};

const GetUpdateRoom = (id, object) => {
  return handleRequest(
    api.put(`/api/update/${id}/v2`, object),
    "Lỗi khi cập nhật phòng"
  );
};

const addRoomV2 = (object) => {
  return handleRequest(
    api.post(`/api/addroom/v2`, {
      hovaten: object.hovaten,
      SoPhong: object.SoPhong,
      GiaPhong: object.GiaPhong,
      chisodiencu: object.chisodiencu || 0,
      chisodienmoi: 0,
      chisonuoclanhcu: object.chisonuoclanhcu || 0,
      chisonuoclanhmoi: 0,
      chisonuocnongcu: object.chisonuocnongcu || 0,
      chisonuocnongmoi: 0,
      sinhhoatchung: object.sinhhoatchung || 0,
      ghichu: "Chưa có ghi chú",
      loainuoc: object.loainuoc,
      songuoikhoang: object.nguoi || 0,
      giakhoangnuoc: 90000,
      NgayLap: object.NgayLap || "",
      NgayHetHan: object.NgayHetHan || ""
    }),
    "Lỗi khi thêm phòng mới"
  );
};

const deleteRoomV2 = async (id) => {
  return handleRequest(api.get(`/api/delete/${id}/v2`), "Lỗi khi xóa phòng");
};

const handleAdDataRoomMonth = async (array) => {
  return handleRequest(
    api.post("/api/updateRoom/v2", { data: array }),
    "Lỗi khi cập nhật phòng tháng"
  );
};

// ==================== DEPOSIT APIs ====================

const depositRoom = (data) => {
  return handleRequest(api.post("/api/deposit", data), "Lỗi khi đặt cọc phòng");
};

const checkRoomDeposit = (roomName) => {
  return handleRequest(api.get(`/api/checkdeposit/${roomName}`), "Lỗi khi kiểm tra đặt cọc");
};

const deleteDeposit = (id) => {
  return handleRequest(api.post(`/api/deposit/delete/${id}`), "Lỗi khi xóa đặt cọc");
};

// ==================== SURCHARGE DATE APIs ====================

const fetchSurchargeDates = () => {
  return handleRequest(
    api.get("/api/surcharge-dates"),
    "Lỗi khi lấy danh sách ngày phụ thu"
  );
};

const addSurchargeDateApi = (data) => {
  return handleRequest(
    api.post("/api/surcharge-dates", data),
    "Lỗi khi thêm ngày phụ thu"
  );
};

const deleteSurchargeDateApi = (id) => {
  return handleRequest(
    api.delete(`/api/surcharge-dates/${id}`),
    "Lỗi khi xóa ngày phụ thu"
  );
};

const editSurchargeDateApi = (id, data) => {
  return handleRequest(
    api.put(`/api/surcharge-dates/${id}`, data),
    "Lỗi khi cập nhật ngày phụ thu"
  );
};

// ==================== BAN NUOC POS APIs ====================

const fetchBannuocProducts = () => {
  return handleRequest(api.get("/api/bannuoc/products"), "Lỗi khi lấy sản phẩm");
};

const createBannuocProduct = (data) => {
  return handleRequest(api.post("/api/bannuoc/products", data), "Lỗi khi tạo sản phẩm");
};

const updateBannuocProduct = (id, data) => {
  return handleRequest(api.put(`/api/bannuoc/products/${id}`, data), "Lỗi khi cập nhật sản phẩm");
};

const deleteBannuocProduct = (id) => {
  return handleRequest(api.delete(`/api/bannuoc/products/${id}`), "Lỗi khi xóa sản phẩm");
};

const createBannuocTransaction = (data) => {
  return handleRequest(api.post("/api/bannuoc/transactions", data), "Lỗi khi tạo giao dịch");
};

const fetchBannuocTransactions = (params) => {
  return handleRequest(api.get("/api/bannuoc/transactions", { params }), "Lỗi khi lấy giao dịch");
};

const updateBannuocPayment = (id, data) => {
  return handleRequest(api.patch(`/api/bannuoc/transactions/${id}/payment`, data), "Lỗi khi cập nhật thanh toán");
};

const deleteBannuocTransaction = (id) => {
  return handleRequest(api.delete(`/api/bannuoc/transactions/${id}`), "Lỗi khi xóa giao dịch");
};

const deleteBannuocMultipleTransactions = (ids) => {
  return handleRequest(api.post("/api/bannuoc/transactions/delete-multiple", { transactionIds: ids }), "Lỗi khi xóa giao dịch");
};

const createBannuocSalesCheckpoint = (data) => {
  return handleRequest(api.post("/api/bannuoc/transactions/sales-checkpoint", data), "Lỗi khi chốt tiền");
};

const fetchBannuocSalesCheckpoints = () => {
  return handleRequest(api.get("/api/bannuoc/transactions/sales-checkpoints"), "Lỗi khi lấy danh sách chốt tiền");
};

const createBannuocImport = (data) => {
  return handleRequest(api.post("/api/bannuoc/imports", data), "Lỗi khi nhập hàng");
};

const fetchBannuocImports = (params) => {
  return handleRequest(api.get("/api/bannuoc/imports", { params }), "Lỗi khi lấy lịch sử nhập");
};

const deleteBannuocImport = (id) => {
  return handleRequest(api.delete(`/api/bannuoc/imports/${id}`), "Lỗi khi xóa lịch sử nhập");
};

const fetchBannuocAudit = (params) => {
  return handleRequest(api.get("/api/bannuoc/inventory/audit", { params }), "Lỗi khi kiểm kê");
};

const confirmBannuocAudit = (data) => {
  return handleRequest(api.post("/api/bannuoc/inventory/confirm", data), "Lỗi khi chốt kiểm kê");
};

const fetchBannuocLastCheckpoint = () => {
  return handleRequest(api.get("/api/bannuoc/inventory/last-checkpoint"), "Lỗi khi lấy checkpoint");
};

const fetchBannuocCheckpoints = () => {
  return handleRequest(api.get("/api/bannuoc/inventory/checkpoints"), "Lỗi khi lấy danh sách checkpoint");
};

const deleteBannuocCheckpoint = (id) => {
  return handleRequest(api.delete(`/api/bannuoc/inventory/checkpoints/${id}`), "Lỗi khi xóa checkpoint");
};

const seedBannuocData = () => {
  return handleRequest(api.post("/api/bannuoc/seed"), "Lỗi khi tạo dữ liệu mẫu");
};

// ======================= DEBT & NOTIFICATION APIs =======================
const createDebt = (data) => handleRequest(api.post("/api/debt/create", data), "Lỗi ghi nợ");
const getDebts = () => handleRequest(api.get("/api/debt/list"), "Lỗi tải danh sách nợ");
const updateDebtStatus = (id, data) => handleRequest(api.patch(`/api/debt/status/${id}`, data), "Lỗi cập nhật nợ");
const deleteDebt = (id) => handleRequest(api.delete(`/api/debt/${id}`), "Lỗi xóa nợ");
const getSystemNotifications = () => handleRequest(api.get("/api/debt/notifications"), "Lỗi tải thông báo");

// Xuất toàn bộ
export {
  createDebt,
  getDebts,
  updateDebtStatus,
  deleteDebt,
  getSystemNotifications,
  api,
  editRoom,
  saveRoomHistory,
  deleteRoomData,
  fetchRoomsList,
  fetchHistory,
  deleteHistory,
  addRoom,
  GetAllRoomsMonth,
  GetUpdateRoom,
  addRoomV2,
  deleteRoomV2,
  fetchNoteList,
  addWaterNote,
  deleteNoteWater,
  deleteNoteWaterDetails,
  handleAdDataRoomMonth,
  depositRoom,
  checkRoomDeposit,
  deleteDeposit,
  fetchSurchargeDates,
  addSurchargeDateApi,
  deleteSurchargeDateApi,
  editSurchargeDateApi,
  // BanNuoc POS exports
  fetchBannuocProducts,
  createBannuocProduct,
  updateBannuocProduct,
  deleteBannuocProduct,
  createBannuocTransaction,
  fetchBannuocTransactions,
  updateBannuocPayment,
  deleteBannuocTransaction,
  deleteBannuocMultipleTransactions,
  createBannuocSalesCheckpoint,
  fetchBannuocSalesCheckpoints,
  createBannuocImport,
  fetchBannuocImports,
  deleteBannuocImport,
  fetchBannuocAudit,
  confirmBannuocAudit,
  fetchBannuocLastCheckpoint,
  fetchBannuocCheckpoints,
  deleteBannuocCheckpoint,
  seedBannuocData
};

