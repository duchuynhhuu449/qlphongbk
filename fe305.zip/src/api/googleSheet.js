import axios from "axios";

const urlQuanlyNuoc = `https://script.google.com/macros/s/AKfycbxZA8iCV2oZsn6MadsIsCI-culnN3buiLeira2CVMSKX1stiz9zaPjLWMiocOhM9Og/exec`;

export const quanlynuocsheet = async (data) => {
  try {
    const object = {
      url: urlQuanlyNuoc,
      data: data
    }
    const response = await axios.post("http://localhost:3000/proxy", object);
    console.log(response.data);  // Xử lý kết quả trả về
  } catch (error) {
    if (error.response) {
      // Lỗi phản hồi từ server
      console.error("Lỗi từ server:", error.response.data);
    } else if (error.request) {
      // Lỗi khi gửi yêu cầu
      console.error("Yêu cầu không nhận được phản hồi:", error.request);
    } else {
      // Lỗi khác (cấu hình hoặc lỗi trong mã)
      console.error("Lỗi xảy ra:", error.message);
    }
  }
};


export const saveRoomMonth = async (data) => {
  const object = {
    url: "https://script.google.com/macros/s/AKfycbziOU8us9i575RNv07_ofznjgriDVITyXERz78cEcaLV58TktthX7GolavTE3GVEn7VJQ/exec",
    data: data
  }
  try {
    const response = await axios.post("http://localhost:3000/proxy", object);

    const text = await response.text();
    console.log("Gửi thành công:", text);
  } catch (err) {
    console.error("Gửi lỗi:", err);
  }
};

